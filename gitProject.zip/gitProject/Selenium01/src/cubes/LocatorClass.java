package cubes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LocatorClass {

	public static void main(String[] args) {
		
		WebDriver webDriver = MyWebDriver.getInstance().getDriver("chrome");
		webDriver.get("https://www.google.rs");
		webDriver.manage().window().maximize();
		
		//1WebElement weId = webDriver.findElement(By.id("APjFqb"));
		//weId.sendKeys("Cubes School");
		
		//2WebElement weName = webDriver.findElement(By.name("q"));
		//weName.sendKeys("Cubes School");
		
		//3WebElement weTagName = webDriver.findElement(By.tagName("textarea"));
		//weTagName.sendKeys("Cubes School");
		
		//4WebElement weClassName = webDriver.findElement(By.className("gLFyf"));
		//weClassName.sendKeys("Cubes School");
		//5WebElement weLinkText = webDriver.findElement(By.linkText("srpski"));
		//weLinkText.click();
		//6WebElement wePartialLinkText = webDriver.findElement(By.partialLinkText("Eng"));
		//wePartialLinkText.click();
		//7WebElement weXpath = webDriver.findElement(By.xpath("//textarea[@id='APjFqb']"));
		//weXpath.sendKeys("Cubes School");
		//WebElement weElem = webDriver.findElement(By.xpath("//textarea[text()='Из прве руке']"));
		///ne moze ovo
		//8WebElement weElem = webDriver.findElement(By.cssSelector("textarea"));
		//weElem.sendKeys("Cubes School");
		//8WebElement weEle = webDriver.findElement(By.cssSelector("#APjFqb"));
		//weEle.sendKeys("Cubes School");
		//8WebElement weEl = webDriver.findElement(By.cssSelector(".gLFyf"));
		//weEl.sendKeys("Cubes School");
		//8WebElement weElem = webDriver.findElement(By.cssSelector("textarea[name='q']"));
		//weElem.sendKeys("Cubes School");
		//8WebElement weElem = webDriver.findElement(By.cssSelector("textarea[name]"));
		//weElem.sendKeys("Cubes School");
		//WebElement weElem = webDriver.findElement(By.cssSelector("[name]"));
		//weElem.sendKeys("Cubes School"); ovo ne moze!!
		
		
		
		
		

	}

}
