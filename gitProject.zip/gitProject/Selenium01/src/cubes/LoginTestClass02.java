package cubes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginTestClass02 {

	public static void main(String[] args) {
		
		String urlLoginPage = "https://testblog.kurs-qa.cubes.edu.rs/login";
		WebDriver driver = MyWebDriver.getInstance().getDriver("chrome");
		driver.get(urlLoginPage);
		driver.manage().window().maximize();
		
		WebElement weEmail = driver.findElement(By.xpath("//input[@type='email']"));
		WebElement wePassword =driver.findElement(By.xpath("//input[@type='password']"));
		WebElement weSignIn = driver.findElement(By.xpath("//button[@type='submit']"));
		
		weEmail.sendKeys("");
		wePassword.sendKeys("");
		weSignIn.click();
		
		WebElement weEmailError = driver.findElement(By.xpath("//p[@id='email-error']"));
		WebElement wePasswordError =driver.findElement(By.xpath("//p[@id='password-error']"));
		
		if(!driver.getCurrentUrl().equalsIgnoreCase(urlLoginPage)) {
			System.out.println("Tc not ok-URL problem");
		}
		else if(!weEmailError.isDisplayed()) {
			System.out.println("TC not ok- email error not displayed");
		}
		
		else if(!wePasswordError.isDisplayed()) {
			System.out.println("TC not ok- password error not displayed");
		}
		
		else {
			System.out.println("TC01 ok ");
		}
		
		
		
			
		

	}

}
