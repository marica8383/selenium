package cubes.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cubes.main.URLConst;
import cubes.main.Utils;

public class AddTagPage {    //setujem driver i webelemente
	private WebDriver driver;
	@FindBy(name="name")
	private WebElement weTagName;
	@FindBy(xpath="//*[text()='Save']")
	//@FindBy(xpath="//button[@type='submit']") ovaj prolazi
	private WebElement weSave;
	@FindBy(xpath="//*[text()='Cancel']")
	//@FindBy(xpath="//a[@class='btn']")ovaj ne valja
	//@FindBy(className="btn-outline-secondary")moze ovo
	private WebElement weCancel;
	@FindBy(id="name-error")
	private WebElement weNameError;
	
	public AddTagPage(WebDriver driver,boolean openPage) {  //inic driver pa inic webelemente		this.driver = driver;
		this.driver = driver;
		this.driver.manage().window().maximize();
		if(openPage) {
		this.driver.get(URLConst.TAG_ADD);}
		PageFactory.initElements(driver, this);
	}
	//sve metode
	public void insertTagName(String tagName) {
		weTagName.clear();
		weTagName.sendKeys(tagName);
	}
	public void clickOnSave()  {
		weSave.click();
	}
	public void clickOnCancel() {
		weCancel.click();
	}
	public boolean isNameErrorDisplayed() {
		return weNameError.isDisplayed();
	}
	
	public String getNameErrorText() {
		return weNameError.getText();
	}
	//pazi return get attrib(string name  !!!
	public String getTagNameText() {
		return weTagName.getAttribute("value");
	}
	public void addNewTag(String name) {
		insertTagName(name);
		clickOnSave();
	}
	public String addNewTag() {
		String tempTagName = Utils.getRandomTagName();
		addNewTag(tempTagName);
		return tempTagName;
	}
	//public String getTagNameText() {
	//WebElement inputName = driver.findElement(By.name("name"));
	//return inputName.getText();

	
	
	
	
	
	
	

	

}
