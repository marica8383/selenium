package cubes.pages.tag;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cubes.main.URLConst;
import cubes.main.Utils;

public class ListTagPage {
	private WebDriver driver;
	@FindBy(partialLinkText = "Add new Tag")
	private WebElement weAddNewTag;
	//@FindBy(xpath="//button[@data-name = 'asds']")
	//@FindBy(xpath="//*[@data-id='7300']")
	//private WebElement weBin;
	@FindBy(xpath="//button[text()='Delete']")
	private WebElement weDelete;
    //@FindBy(xpath="//strong[text()='asds']")
   // List<WebElement> weList;
    @FindBy(xpath="//strong[text()='asds']")
	private  WebElement weTag;
	//@FindBy(xpath="//strong[text()='azxcv']")
	//private WebElement weTag;
	@FindBy(xpath="//button[@data-name = 'asds']")//ili data-id oba moze!
	private WebElement weBin;
	@FindBy(xpath="//i[@class = 'far fa-user']")//pazi apostrof pa odmah textizdoma bezspacevaaposuzt
	private WebElement weUser;
	@FindBy(xpath="//a[@class = 'dropdown-item']")
	private WebElement weLogout;
	@FindBy(xpath="//i[@class='fas fa-edit']")
	private WebElement weEdit;
	@FindBy(xpath="//input[@type='text']")
	private WebElement weName;
	@FindBy(xpath="//button[@class='btn btn-primary']")
	private WebElement weSave;
	
	public ListTagPage(WebDriver driver) {
		this.driver = driver;
		//this.driver.manage().window().maximize();
		//this.driver.get(URLConst.TAG_LIST);
		PageFactory.initElements(driver, this);
	}
	public void openPage() {
		this.driver.get(URLConst.TAG_LIST);
	}
	public void clickOnAddNewTag() {
		weAddNewTag.click();
	}
	public int countTagsWithName(String name) {
	  List<WebElement>weTagList=driver.findElements(By.xpath("//strong[text()='"+name+"']"));
	  return weTagList.size();
	}
	public boolean isTagWithNameInList(String name) {
		List<WebElement>weTagList=driver.findElements(By.xpath("//strong[text()='"+name+"']"));
		return weTagList.size()>0;
		//return !weTagList.isEmpty(); ili ovo 
		//
	}
	public List<WebElement>  getTagWithNameList(String name) {
		//List<WebElement>weTagList=driver.findElements(By.xpath("//strong[text()='"+name+"']"));
		return driver.findElements(By.xpath("//strong[text()='"+name+"']"));
		
	}
	
	//DOMACI: Ok
	public void deleteTag(String name) throws InterruptedException {
		//WebElement deleteButton = driver.findElement(By.xpath("//button[@data-name='"+name+"']"));
		//                sve isto=By.xpath(getDeleteButtonLocator(name));
		//deleteButton.click();
		clickOnDeleteTag(name);
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Delete']")));
		clickOnDeleteDialogDelete();
		//WebElement dialogDeleteButton = driver.findElement(By.xpath("//button[text()='Delete']"));
		//dialogDeleteButton.click();
		//Thread.sleep(1000);
		////weBin.click();
		//Thread.sleep(3000);
		//weDelete.click();
	}
	public void doLogout() throws InterruptedException {
		weUser.click();
		Thread.sleep(3000);
		weLogout.click();
	}
	
	public void editName() throws InterruptedException {
		//weEdit.click();
		//weName.clear();
		//weName.sendKeys("tag68");
		//Thread.sleep(3000);
		//weSave.click();;
	}
	public void clickOnDeleteTag(String name) {
		WebElement deleteButton = driver.findElement(By.xpath("//button[@data-name='"+name+"']"));
		
		deleteButton.click();
	}
	private String getDeleteButtonLocator(String name) {
		return "//strong[text()='"+name+"']//ancestor::tr//td[5]//button";
	}
	private String getUpdateButtonLocator(String name) {
		return"//strong[text()='"+name+"']//ancestor::tr//td[5]//a[2]";
	}
	public void clickOnDeleteDialogDelete() {
		WebElement deleteButton = driver.findElement(By.xpath("//button[text()='Delete']"));
		deleteButton.click();
	}
	public void clickOnDeleteDialogCancel() {
		WebElement cancelButton = driver.findElement(By.xpath("//button[text()='Cancel']"));
		cancelButton.click();
	}
	public void clickOnUpdateTag(String name) {
		WebElement updateButton = driver.findElement(By.xpath(getUpdateButtonLocator(name)));
		Utils.scrollToElement(driver, updateButton);
		updateButton.click();
	}
	

	
	
	

}
