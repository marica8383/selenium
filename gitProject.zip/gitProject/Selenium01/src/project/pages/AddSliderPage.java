package project.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import cubes.main.URLConst;
import cubes.main.Utils;

public class AddSliderPage {
     
	private WebDriver driver;
	
	public AddSliderPage(WebDriver driver, boolean openPage) {
		this.driver = driver;
		this.driver.manage().window().maximize();
		if(openPage) {
		this.driver.get(URLConst.SLIDER_ADD);}
		PageFactory.initElements(driver,this);
	} 
	
	 public String getBTPlacText() {
		 return driver.findElement(By.xpath("//input[@name='button_title']")).getAttribute("placeholder");
	 }
	public boolean isPlachBTDisplayed() {
		return driver.findElement(By.xpath("//input[@name='button_title']")).isDisplayed();
	}
	 public String getBURLPlacText() {
		 return driver.findElement(By.xpath("//input[@name='button_url']")).getAttribute("placeholder");
	 }
	public boolean isPlachBURLDisplayed() {
		return driver.findElement(By.xpath("//input[@name='button_url']")).isDisplayed();
	}
	
	
	
	 public boolean isUrlFormatErrorDisplayed() {
		   return driver.findElement(By.xpath("//span[@id='button_url-error']")).isDisplayed();
	   }
	 
	 public boolean isTitleFormatErrorDisplayed() {
		   return driver.findElement(By.xpath("//span[@id='title-error']")).isDisplayed();
	   }
	 public boolean isButtTitleFormatErrorDisplayed() {
		   return driver.findElement(By.xpath("//span[@id='button_title-error']")).isDisplayed();
	   }
	 
	
	   public boolean isTitleLengthErrorDisplayed() {
		   return driver.findElement(By.xpath("//span[@id='title-error']")).isDisplayed();
	   }
	   public boolean isButtTitleLengthErrorDisplayed() {
		   return driver.findElement(By.xpath("//span[@id='button_title-error']")).isDisplayed();
	   }
	  public String getBTitLengthErrorText() {
		  return driver.findElement(By.xpath("//span[@id='button_title-error']")).getText();
	  }
	public void insertTitle(String title) {
		WebElement x = driver.findElement(By.xpath("//input[@name='title']"));
		x.clear();
		x.sendKeys(title);
	}
	
	public void insertButtonTitle(String title) {
		WebElement x = driver.findElement(By.xpath("//input[@name='button_title']"));
		x.clear();
		x.sendKeys(title);
	}
	
	
	
	public void insertButtonUrl(String title) {
		WebElement x = driver.findElement(By.xpath("//input[@name='button_url']"));
		x.clear();
		x.sendKeys(title);
	}
	                                 //choose photo
	public void choosePhoto() {
		WebElement m = driver.findElement(By.xpath("//input[@type='file']"));
		m.sendKeys("D:\\Desktop\\pictures\\Capture9.png");
	}                         
	public void choosePhoto1() {
		WebElement m = driver.findElement(By.xpath("//input[@type='file']"));
		m.sendKeys("D:\\Desktop\\pictures\\1.gif");
	}               
	public void choosePhoto2() {
		WebElement m = driver.findElement(By.xpath("//input[@type='file']"));
		m.sendKeys("D:\\Desktop\\pictures\\2.jpg");
	}              
	public void choosePhoto3() {
		WebElement m = driver.findElement(By.xpath("//input[@type='file']"));
		m.sendKeys("D:\\Desktop\\pictures\\phototxt.txt");
	}              
	public void clickOnHome() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Home']"));
		x.click();		
	}
	
	public void clickOnSliders() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Sliders']"));
		x.click();		
	}
	
	public void clickOnSave() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//button[@type='submit']"));
		Utils.scrollToElement(driver, x);
		Thread.sleep(500);
		x.click();		
	}
	public void clickOnCancel() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Cancel']"));
		x.click();		
	}
	  

	
	public boolean isErrorTitleDisplayed() {
		WebElement x = driver.findElement(By.xpath("//span[@id='title-error']"));
		return x.isDisplayed();
	}
	public boolean isErrorButtTitleDisplayed() {
		WebElement x = driver.findElement(By.xpath("//span[@id='button_title-error']"));
		return x.isDisplayed();
	}
	
	public boolean isErrorButtUrlDisplayed() {
		WebElement x = driver.findElement(By.xpath("//span[@id='button_url-error']"));
		return x.isDisplayed();
	}
	
	public boolean isPhotoErrorDisplayed() {
		WebElement x = driver.findElement(By.xpath("//span[@id='photo-error']"));
		return x.isDisplayed();
	}
	public boolean isUpErrorTitDisplayed() {
		WebElement x = driver.findElement(By.xpath("//label[@id='title-error']"));
		return x.isDisplayed();
	}
	public boolean isUpErrorBTDisplayed() {
		WebElement x = driver.findElement(By.xpath("//label[@id='button_title-error']"));
		return x.isDisplayed();
	}
	public boolean isUpErrorBUrlDisplayed() {
		WebElement x = driver.findElement(By.xpath("//label[@id='button_url-error']"));
		return x.isDisplayed();
	}
	
	
	
	public String getTitleErrorText() {
		WebElement x = driver.findElement(By.xpath("//span[@id='title-error']"));
		return x.getText();
	}
	
	public String getButtTitleErrorText() {
		WebElement x = driver.findElement(By.xpath("//span[@id='button_title-error']"));
		return x.getText();
	}
	
	
	public String getButtUrlErrorText() {
		WebElement x = driver.findElement(By.xpath("//span[@id='button_url-error']"));
		return x.getText();
	}
	
	public String getPhotoErrorText() {
		WebElement x = driver.findElement(By.xpath("//span[@id='photo-error']"));
		return x.getText();
	}
	


	public String getUpTitleErrorText() {
		WebElement x = driver.findElement(By.xpath("//label[@id='title-error']"));
		return x.getText();
	}
	
	public String getUpButtTitleErroText() {
		WebElement x = driver.findElement(By.xpath("//label[@id='button_title-error']"));
		return x.getText();
	}
	
	
	public String getUpButtUrlErrorText() {
		WebElement x = driver.findElement(By.xpath("//label[@id='button_url-error']"));
		return x.getText();
	}
	
	public String getTitleText() {
		WebElement x = driver.findElement(By.xpath("//input[@name='title']"));
	     return x.getAttribute("value");
	}
	
	
	public String getButtTitleText() {
		WebElement x = driver.findElement(By.xpath("//input[@name='button_title']"));
	     return x.getAttribute("value");
	}
	
	public String getButtUrlText() {
		WebElement x = driver.findElement(By.xpath("//input[@name='button_url']"));
	    return x.getAttribute("value");
	}
	
	
	                             // photo for update na addu
	
    
      public boolean isPhotoDisplayed() {
            return driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).isDisplayed();
      }

     public int getPhotoWidth() {
            return driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).getSize().getWidth();	 }


     public int getPhotoHeight() {
            return driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).getSize().getHeight();	 }


    public String getPhotoUrl() {
          return driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).getAttribute("src");	 }

    public String getDescriptionOfPhoto() {
          
           String src = driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).getAttribute("src");
           String y = src.substring(13);
           return y;                                             
     }             
	                                          //plachol
	
		public String getPlacehForButtonTitle() {
			
		    return driver.findElement(By.xpath("//input[@name='button_title']")).getAttribute("placeholder");}
	


        public String getPlacehForButtonUrl() {
	
           return driver.findElement(By.xpath("//input[@name='button_url']")).getAttribute("placeholder");}



        public String getPlacehTitle() {
	
            return driver.findElement(By.xpath("//input[@name='title']")).getAttribute("placeholder");
        }

        
        
        
        
}

















