package project.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cubes.main.URLConst;
import cubes.main.Utils;

public class ListCategoryPage {
     private WebDriver driver;
     
     @FindBy(partialLinkText="Add new Category")//a[@class='btn btn-success']1 od 1
     private WebElement weAddNewCategory;
	 @FindBy(xpath="//button[@data-action='show-order']")
	 private WebElement weChangeOrder;
	
	 
	public ListCategoryPage(WebDriver driver) {
		this.driver = driver;
		//this.driver.manage().window().maximize();
		//this.driver.get(URLConst.CATEGORY_LIST);
		PageFactory.initElements(driver, this);
	}
	
	                                        //M E T O D E 12
	public void openPage() {
		this.driver.get(URLConst.CATEGORY_LIST);
	}
	public void clickOnHome() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Home']"));
		x.click();		
	}
	public void clickOnAddNewCat() {
		weAddNewCategory.click();
	}
	
	public void clickOnChangeOrder() throws InterruptedException {
		weChangeOrder.click();
		Thread.sleep(500);
	}
	
	public void clickOnSaveOrder() throws InterruptedException {
	         WebElement x = driver.findElement(By.xpath("//button[@class='btn btn-outline-success']"));
	         ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
	         Thread.sleep(500);
	          x.click();
		     Thread.sleep(1000);
	}
	
	public void clickOnCancelOrder() {
		WebElement x = driver.findElement(By.xpath("//button[@class='btn btn-outline-danger']"));
		x.click();
	}
	         
                           //prvi ispod dr  
    public void changeOrderByNum(String num,String numSec) {
	  WebElement dragable = driver.findElement(By.xpath("//tr[@data-id='"+num+"']//td[1]//span[1]"));
	  WebElement dropable = driver.findElement(By.xpath("//tr[@data-id='"+numSec+"']//td[1]//span[1]"));
	  Actions act = new Actions(driver);
	  act.dragAndDrop(dragable, dropable).build().perform();
}

    
	 public void changeOrder(String name, String nameSec) throws InterruptedException {
		 Thread.sleep(500);
		 Actions act = new Actions(driver);
		 WebElement dragable = driver.findElement(By.xpath("//strong[text()='"+name+"']//preceding::td[1]//span[1]"));
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", dragable );
		 WebElement dropable = driver.findElement(By.xpath("//strong[text()='"+nameSec+"']//preceding::td[1]//span[1]"));
		 dragable.click();
		 Thread.sleep(1000);
		 act.dragAndDrop(dragable, dropable).build().perform();
		 Thread.sleep(1000);
      }                      
    public boolean isOrderonCurrentPageChanged() {
	   List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//tr"));
	  for(int i = 1;i<x.size()-1;i++) {
	  if( ((Integer.parseInt(x.get(i).getAttribute("data-id")) > ( Integer.parseInt(x.get(i+1).getAttribute("data-id") ))  )) ) {
	  return true;
	
	}}
	   return false;
                                                                 
}	                     
	
	
	public int countCatWithName(String name) {
		List<WebElement>catList=driver.findElements(By.xpath("//strong[text()='"+name+"']"));
		return catList.size();
	}
	public boolean isCatWithNameInList(String name) {
		List<WebElement>catList=driver.findElements(By.xpath("//strong[text()='"+name+"']"));
		return catList.size()>0;
	}
	public List<WebElement> getListWithCatName(String name){
		return driver.findElements(By.xpath("//strong[text()='"+name+"']"));
	}
	                              //NOVEMETODE
	
	
	public void deleteCat(String name) throws InterruptedException {
		clickOnDeleteCat(name);
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Delete']")));
		 Thread.sleep(2000);
		clickOnDeleteDialogDelete();
	}
	
	public void clickOnDeleteCat(String name) throws InterruptedException {
		 ((JavascriptExecutor)driver).executeScript("window.scrollBy(1000,0)");
		WebElement deleteButton = driver.findElement(By.xpath("//button[@data-name='"+name+"']"));
		Thread.sleep(1000);
		deleteButton.click();
	}
	
	public void clickOnDeleteDialogDelete() {
		WebElement deleteButton=driver.findElement(By.xpath("//button[text()='Delete']"));
		deleteButton.click();
	}
	
	public String getDeleteCatLocator(String name) {
		return "//strong[text()='"+name+"']//ancestor::tr//td[6]//button";
		
	}
	
	public void clickOnDeleteDialogCancel() {
		WebElement cancelButton = driver.findElement(By.xpath("//button[text()='Cancel']"));
		cancelButton.click();
	}                              
	
	
	
	private String getUpdateButtonLocator(String name) {
		return"//strong[text()='"+name+"']//ancestor::tr//td[6]//a[2]";
	}
	
	
	public void clickOnUpdateCateg(String name) throws InterruptedException {
		//((JavascriptExecutor)driver).executeScript("window.scrollBy(1000,0)");
		WebElement updateButton = driver.findElement(By.xpath(getUpdateButtonLocator(name)));
		//Utils.scrollToElement(driver,  updateButton);
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", updateButton );
		 
		  Thread.sleep(1000);   //2ex
		updateButton.click();
	}
	
	
       public String getCatName(String num) {
      return driver.findElement(By.xpath("//tr[@data-id='"+num+"']//td[2]//strong")).getText();}
	
       
       public String getCatDes(String num) {
    	      return driver.findElement(By.xpath("//tr[@data-id='"+num+"']//td[3]")).getText();}
    		
    	       
	  public void clickOnEye(String name) {
            driver.findElement(By.xpath("//strong[text()='"+name+"']//ancestor::tr//td[6]//a[1]")).click();
	  }    
	
	
	
	
}
