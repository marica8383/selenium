package project.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;

import cubes.MyWebDriver;
import cubes.main.URLConst;
import cubes.pages.LoginPage;
import project.pages.AddSliderPage;
import project.pages.AddUserPage;
import project.pages.ListUserPage;

class UserTest {
	private static WebDriver driver;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		driver= MyWebDriver.getInstance().getDriver("chrome");
		//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("name")));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		LoginPage loginPage = new LoginPage(driver);
	    loginPage.loginSuccess();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		driver.close();
	}

	@BeforeEach
	void setUp() throws Exception {
		driver.get(URLConst.USER_LIST);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test01() {
			AddUserPage addUserPage = new AddUserPage(driver, true);
			addUserPage.clickOnUsers();
			assertEquals(driver.getCurrentUrl(),URLConst.USER_LIST,"Los URL.");
	}
	
	@Test                                                     
	void tc02() throws InterruptedException {
		String x = "";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.insertNameOfUser(x);
		addUserPage.insertPhone(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"greska nije prikazana.");
		assertEquals(addUserPage.isErrorNameDisplayed(),true,"greska nije prikazana.");
		assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"greska nije prikazana.");
		assertEquals(addUserPage.getEmailErrorText(),"This field is required.","Los text poruke.");
		assertEquals(addUserPage.getNameErrorText(),"This field is required.","Los text poruke.");
		assertEquals(addUserPage.getPhoneErrorText(),"This field is required.","Los text poruke.");
		assertEquals(driver.getCurrentUrl(),URLConst.USER_ADD,"Los url.");
	}
	
	@Test                                                     
	void tc03() throws InterruptedException {
		String x = "";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.insertNameOfUser(x);
		addUserPage.insertPhone(x);
		addUserPage.clickOnCancel();
		assertEquals(driver.getCurrentUrl(),URLConst.USER_LIST,"Los url");
	}
	@Test                                                     
	void tc04() throws InterruptedException {
		String x = "username86@example.com";
		String y = "Loren Chandelier";
		String z = "+381652335670";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.insertNameOfUser(y);
		addUserPage.insertPhone(z);
		addUserPage.choosePhoto();
		addUserPage.clickOnCancel();
		assertEquals(driver.getCurrentUrl(),URLConst.USER_LIST,"Los url.");
		ListUserPage listUserPage = new ListUserPage(driver);
		assertEquals(listUserPage.countUsersWithName(y),0,"Nije dobar broj.");
	}
	@Test                                                     //ubacen val
	void tc05() throws InterruptedException {
		String x = "username86@example.com";
		String y = "Loren Chandelier";
		String z = "+381652335670";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.insertNameOfUser(y);
		addUserPage.insertPhone(z);
		addUserPage.choosePhoto();
		addUserPage.clickOnSave();
		assertEquals(driver.getCurrentUrl(),URLConst.USER_LIST,"Los url.");
		ListUserPage listUserPage = new ListUserPage(driver);
		assertEquals(listUserPage.countUsersWithName(y),1,"User nije u listi.");
	}	
	@Test                                                     
	void tc06() {                                    // okPostoji Email greska@bez@
		String x = "asdymail.com";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska.");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}
	@Test                                            //CaSe        
	void tc07() {
		String x = "SDF@gmail.com";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
		
	}	
	@Test                                                     
	void tc08() {                                       //.
		String x = "miksmail@koma.";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska.");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}		
	@Test                                                     
	void tc09() {                                      
		String x = "miksmail567_@kompas";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
		
		
	}			
	@Test                                                     
	void tc10() {                                             //space
		String x = "miksmai56    8@maps";     
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}				
	@Test                                                     
	void tc11() {                                             //@2
		String x = "miksmai56@@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska.");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}			
	@Test                                                     
	void tc12() {                                    //  (
		String x = "miksmai5(6@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska.");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	@Test                                                     
	void tc13() {
		String x = "miksmai{56@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
		
		
	}	
	@Test                                                     
	void tc14() {
		String x = "miksmai[56@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	@Test                                                     
	void tc15() {
		String x = "miksmai\56@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	
	@Test                                                     
	void tc16() {
		String x = "miksmai'56@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
		
	}	
	@Test                                                     
	void tc17() {
		String x = "miksmai;56@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska.");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	@Test                                                     
	void tc18() {
		String x = "miksmai<>56@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska.");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	@Test                                                     
	void tc19() {
		String x = "miksmai,56@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska.");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	@Test                                                     
	void tc20() {
		String x = "miksmai/?56@maps";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
	}	
	@Test                          //74 exceed                                             
	void tc21() {
		String x = "miksmai@mailmy.comopsomeploytrsomeploytrsomeploytrsomeploytrsomeploytrmittttttyxay";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	
	@Test                                 //after@ signs                                   
	void tc22() {
		String x = "usernamel@$";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	
	
	@Test                                                        
	void tc23() {                       // ..
		String x = "ana@miksmail..com";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska.");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	@Test                          ///1 letter                                             
	void tc24() {
		String x = "m";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	
	@Test                                                          
	void tc25() {
		String x = "DFG@XMAIL.COM";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
	}	                            
	@Test                                                           
	void tc26() {
		String x = "DFG#XMAIL.COM";                                                       
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana greska");
		assertEquals(addUserPage.getEmailErrorText(),"Please enter a valid email address.","Nije dobar text poruke.");
	}	              
	

@Test                                        //  NAMEshort,allowed                                         
void tc27() {
	String x = "m";                                                       
	AddUserPage addUserPage = new AddUserPage(driver, true);
	addUserPage.insertNameOfUser(x);
	addUserPage.clickOnSave();
	assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
	assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana.");
	
}	


   @Test                                //name                                             
   void tc28() {
        String x = "#@999";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertNameOfUser(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
    	assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana.");
        assertEquals(addUserPage.isErrorNameDisplayed(),false," prikazana greska");
        assertEquals(addUserPage.getNameErrorText(),"Please enter a valid name.","Nije dobar text.");
}	
 
   @Test                                                               
   void tc29() {
        String x = "";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertNameOfUser(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana greska.");
        assertEquals(addUserPage.getNameErrorText(),"This field is required.","nije dobar text.");
}		
   @Test                                  //name    1word       1                                  
   void tc30() {
        String x = "Elvis";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertNameOfUser(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
    	assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana.");
     
       
}		
   @Test                                     //name  2 words                                  
   void tc31() {
        String x = "Elvis Presly";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertNameOfUser(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
    	assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana.");
      
       
}		
   @Test              //name                   IgnoreCase                                        
   void tc32() {
        String x = "Elvis CONAHAN";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertNameOfUser(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
    	assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana.");
       
}
   
   @Test              //name    - ..                                         
   void tc33() {
        String x = "Elvis-CONA.HAN";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertNameOfUser(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
    	assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana.");
    	// assertEquals(addUserPage.isErrorNameDisplayed(),false," prikazana greska");
        
        
       
}         
   @Test                                     //name  '                                        
   void tc34() {
        String x = "Elvis 'CONAHAN";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertNameOfUser(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
    	assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana.");
       
} 
   @Test                                                                          
   void tc35() {
        String x = "vvvvvvvvvvv";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertNameOfUser(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
    	assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana.");
       // assertEquals(addUserPage.isErrorNameDisplayed(),false," prikazana greska");
        
} 
   @Test                              //  phone                                        
   void tc36() {
        String x = "phone number";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertPhone(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
        assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
        assertEquals(addUserPage.isErrorPhoneDisplayed(),false,"prikazana greska.");
        assertEquals(addUserPage.getPhoneErrorText(),"Please enter a valid phone number.","Nije dobar text.");
       
} 
   @Test                                                     
   void tc37() {
        String x = "78$#@";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertPhone(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
       //assertEquals(addUserPage.isErrorPhoneDisplayed(),false," prikazana greska.");

} 
 
   @Test                           //  phone   50 max                                      
   void tc38() {
        String x = "1234567 890123456 78901234 5678901234567890123456789022";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertPhone(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana greska.");
        assertEquals(addUserPage.getPhoneErrorText(),"Please enter no more than 50 characters.","text poruke los.");
       
}  

   
   @Test                                                     
   void tc39() {
        String x = "+381612342399";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertPhone(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
        assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
        
       
       
}    
   @Test                                                                            
   void tc40() {
        String x = "3816123-42-399";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertPhone(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
        assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
        }    
   @Test                                                                      
   void tc41() {
        String x = "38161/23423/99Ee";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertPhone(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
        assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
        
       }    
  
   @Test                                                                                 
   void tc42() {
        String x = "3816123.42.399";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertPhone(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
        assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
        //assertEquals(addUserPage.isErrorPhoneDisplayed(),false," prikazana greska.");
       
       
}    
   @Test                                                                             
   void tc43() {
        String x = "000 0000000";                                                       
        AddUserPage addUserPage = new AddUserPage(driver, true);
        addUserPage.insertPhone(x);
        addUserPage.clickOnSave();
        assertEquals(addUserPage.isErrorEmailDisplayed(),true,"Nije prikazana.");
        assertEquals(addUserPage.isErrorNameDisplayed(),true,"Nije prikazana.");
        //assertEquals(addUserPage.isErrorPhoneDisplayed(),true,"Nije prikazana greska.");
        
       
       
}    
   
	                                                           //add
	@Test                                                     // novi email treba
	void tc44() throws InterruptedException {
		String x = "username86@example.com";
		String y = "Loren Chandelier";
		String z = "+381652335670";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.insertNameOfUser(y);
		addUserPage.insertPhone(z);
		addUserPage.choosePhoto();
		addUserPage.clickOnSave();
		assertEquals(addUserPage.isErrorEmailDisplayed(),true,"greska nije prikazana. ");	
		assertEquals(addUserPage.getEmailErrorText(),"The email has already been taken.","los tekst poruke.");
	}	
	
	
	@Test                                                     //  gif
	void tc45() throws InterruptedException {
		String x = "username85@example.com";
		String y = "Loren";
		String z = "+381652335670";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.insertNameOfUser(y);
		addUserPage.insertPhone(z);
		addUserPage.choosePhoto1();
		addUserPage.clickOnSave();
		ListUserPage listUserPage = new ListUserPage(driver);
		assertEquals(listUserPage.countUsersWithName(y),1,"Nije dobar broj.");
		
	}	
	@Test                                                     //  jpg
	void tc46() throws InterruptedException {
		String x = "user85@example.com";
		String y = "LorenFox";
		String z = "+381652335670";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.insertNameOfUser(y);
		addUserPage.insertPhone(z);
		addUserPage.choosePhoto2();
		addUserPage.clickOnSave();
		ListUserPage listUserPage = new ListUserPage(driver);
		assertEquals(listUserPage.countUsersWithName(y),1,"Nije dobar broj");
		
	}	
	
                                         //list
	
    @Test
    void tc47() {
    	ListUserPage listUserPage = new ListUserPage(driver);
    	listUserPage.clickOnAddNewUser();
    	assertEquals(driver.getCurrentUrl(),URLConst.USER_ADD,"Los URL.");
    }
	
	                                     ///          Status
    @Test
    void tc48() {
    	ListUserPage listUserPage = new ListUserPage(driver);
    	assertEquals(listUserPage.isAllStatusSelected(),true,"nije selektovan");
    	assertEquals(listUserPage.getPaginationSize(),19,"Nije dobar size.");
    }
	
    @Test                                          
    void tc49() {
    	ListUserPage listUserPage = new ListUserPage(driver);
    	listUserPage.clickOnEnable();
    	assertEquals(listUserPage.isEnabledSelected(),true,"Nije selektovan enable.");
    	assertEquals(listUserPage.isEnableInAllFieldsCurrentTablePage(),true,"nije enable u celoj tabeli.");
    	assertEquals(listUserPage.getPaginationSize(),17,"Nije dobar size.");
    	assertEquals(listUserPage.getCurrPageTableSize(),5,"Nije dobar size.");
    	
    }
    @Test                                          
    void tc50() {
    	ListUserPage listUserPage = new ListUserPage(driver);
    	listUserPage.clickOnDisable();
    	assertEquals(listUserPage.isDisableSelected(),true,"Nije selektovan disable.");
    	assertEquals(listUserPage.isDisableInAllFieldsCurrentTablePage(),true,"nije disable u celoj tabeli.");
    	assertEquals(listUserPage.getCurrPageTableSize(),5,"Nije dobar size.");
    }
    @Test                                          
    void tc51() {
    	ListUserPage listUserPage = new ListUserPage(driver);
    	listUserPage.clickOnEnable();
    	listUserPage.clickOnDisable();
    	assertEquals(listUserPage.isDisableSelected(),true,"Nije selektovan disable");
    }
	

	@Test                                                //  add bez photo 
	void tc52() throws InterruptedException {
		String x = "user.name87@example.com";
		String y = "Fox";
		String z = "+381652335671";
		AddUserPage addUserPage = new AddUserPage(driver, true);
		addUserPage.insertEmail(x);
		addUserPage.insertNameOfUser(y);
		addUserPage.insertPhone(z);
		addUserPage.clickOnSave();
		ListUserPage listUserPage = new ListUserPage(driver);
		assertEquals(listUserPage.countUsersWithName(y),1,"Nije dobar broj");
		
	}	
	                                                        //search
	@Test                                              
	void tc53() throws InterruptedException {
		String x = "87";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterEmail(x);
		assertEquals(listUserPage.isEnteredMailInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),2,"Nije dobar size.");
		
	} 

	@Test                                              
	void tc54() throws InterruptedException {
		String x = "user  name";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterEmail(x);
		assertEquals(listUserPage.isNoFoundDisplayed(),true,"Greska nije prikazana. ");
		assertEquals(listUserPage.getNoFundText(),"No matching records found","Text poruke los.");
		assertEquals(listUserPage.getCurrPageTableSize(),0,"Nije dobar size.");
		
	} 
	@Test                                              
	void tc55() throws InterruptedException {
		String x = "username";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterEmail(x);
		assertEquals(listUserPage.isEnteredMailInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),3,"Nije dobar size.");
		
	} 
	@Test                                              
	void tc56() throws InterruptedException {
		String x = "name";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterEmail(x);
		assertEquals(listUserPage.isEnteredMailInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),3,"Nije dobar size.");
		
	} 
	@Test                                              
	void tc57() throws InterruptedException {
		String x = "usern";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterEmail(x);
		assertEquals(listUserPage.isEnteredMailInTable(x),true,"Upit nije u tabeli");
		assertEquals(listUserPage.getCurrPageTableSize(),3,"Nije dobar size.");
		
	} 
	@Test                                              
	void tc58() throws InterruptedException {
		String x = "example";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterEmail(x);
		assertEquals(listUserPage.getCurrPageTableSize(),5,"Nije dobar size.");
		assertEquals(listUserPage.isEnteredMailInTable(x),true,"Upit nije u tabeli.");
	} 

	@Test                                              
	void tc59() throws InterruptedException {
		String x = "user.name87@example.com";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterEmail(x);
		assertEquals(listUserPage.isEnteredMailInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),1,"Nije dobar size.");
		
	} 
	                                                                //name
	@Test                                              
	void tc60() throws InterruptedException {
		String x = "lo";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterName(x);
		assertEquals(listUserPage.isEnteredNameInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),5,"Nije dobar size.");
		
	} 
	@Test                                              
	void tc61() throws InterruptedException {
		String x = "loren";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterName(x);
		assertEquals(listUserPage.isEnteredNameInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),3,"Nije dobar size.");
		
	} 
	@Test                                              
	void tc62() throws InterruptedException {
		String x = "lo  ren";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterName(x);
		assertEquals(listUserPage.isNoFoundDisplayed(),true,"Greska nije prikazana. ");
		assertEquals(listUserPage.getNoFundText(),"No matching records found","Los text.");
		assertEquals(listUserPage.getCurrPageTableSize(),0,"Nije dobar size.");
		
		
	} 
	@Test                                              //CaSe
	void tc63() throws InterruptedException {
		String x = "loRen";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterName(x);
		assertEquals(listUserPage.isEnteredNameInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),3,"Nije dobar size.");
		
		
	} 
	@Test                                              
	void tc64() throws InterruptedException {
		String x = "chandelier";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterName(x);
		assertEquals(listUserPage.isEnteredNameInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),1,"Nije dobar size.");
		
		
	} 
	@Test                                              
	void tc65() throws InterruptedException {
		String x = "Loren Chandelier";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterName(x);
		assertEquals(listUserPage.isEnteredNameInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),1,"Nije dobar size.");
		
		
	} 
	                                                           //phone
	@Test
	void tc66() throws InterruptedException {
		String x = "65";
		ListUserPage listUserPage = new ListUserPage(driver);
		listUserPage.enterPhone(x);
		assertEquals(listUserPage.isEnteredPhoneInTable(x),true,"Upit nije u tabeli.");
		assertEquals(listUserPage.getCurrPageTableSize(),5,"Nije dobar size.");
	
	}
	
                                                     
@Test
void tc67() throws InterruptedException {
      String x = "38165";
      ListUserPage listUserPage = new ListUserPage(driver);
      listUserPage.enterPhone(x);
      assertEquals(listUserPage.isEnteredPhoneInTable(x),true,"Upit nije u tabeli.");
      assertEquals(listUserPage.getCurrPageTableSize(),2,"Nije dobar size.");

}
@Test                                                  //space
void tc68() throws InterruptedException {                 
      String x = "38165 23 35 671";
      ListUserPage listUserPage = new ListUserPage(driver);
      listUserPage.enterPhone(x);
      assertEquals(listUserPage.isNoFoundDisplayed(),true,"Greska nije prikazana. ");
	  assertEquals(listUserPage.getNoFundText(),"No matching records found","los text.");
	  assertEquals(listUserPage.getCurrPageTableSize(),0,"Nije dobar size.");

}
                                                   //phone
@Test
void tc69() throws InterruptedException {
          String x = "381652335671";
          ListUserPage listUserPage = new ListUserPage(driver);
          listUserPage.enterPhone(x);;
          assertEquals(listUserPage.isEnteredPhoneInTable(x),true,"Upit nije u tabeli.");
          assertEquals(listUserPage.getCurrPageTableSize(),1,"Nije dobar size.");

}                                                       //show
@Test
void tc70() throws InterruptedException {
          
          ListUserPage listUserPage = new ListUserPage(driver);
          assertEquals(listUserPage.isFiveSelected(),true,"Nije selektovan.");
          assertEquals(listUserPage.getCurrPageTableSize(),5,"Nije dobar size.");
          assertEquals(listUserPage.getPaginationSize(),19,"Nije dobar size.");
}

@Test
void tc71() throws InterruptedException {
          
          ListUserPage listUserPage = new ListUserPage(driver);
          listUserPage.clickOnShowEntries();
          listUserPage.clickOnShow10();
          assertEquals(listUserPage.isTenSelected(),true,"Nije selektovan.");
          assertEquals(listUserPage.getCurrPageTableSize(),10,"Nije dobar size.");
          assertEquals(listUserPage.getPaginationSize(),10,"Nije dobar size.");
}
@Test
void tc72() throws InterruptedException {
    
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnShowEntries();
    listUserPage.clickOnShow15();
    assertEquals(listUserPage.isTenSelected(),true,"Nije selektovan ten");
    assertEquals(listUserPage.getCurrPageTableSize(),15,"nije dobar size");
    assertEquals(listUserPage.getPaginationSize(),7,"Nije dobar size.");
}
@Test	                                            //sort ok
void tc73() throws InterruptedException {
    
    ListUserPage listUserPage = new ListUserPage(driver);
    assertEquals(listUserPage.isAscOrderOfSerNumbers(),true,"Nije ASC order.");
    assertEquals(listUserPage.getListOfUserSerNumOnCurrPage(),"[1, 2, 3, 4, 5]","Nisu dobri brojevi.");
    
}	
@Test	                                             //sortok
void tc74() throws InterruptedException {
    
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnSortByNumber();
    assertEquals(listUserPage.isAscOrderOfSerNumbers(),false,"Asc order je.");
    assertEquals(listUserPage.getListOfUserSerNumOnCurrPage(),"[91, 90, 89, 88, 87]","brojevi losi.");
    
}	
@Test	                                         //mailok
void tc75() throws InterruptedException {
    
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnSortByEmail();
    assertEquals(listUserPage.isAlphabeticalOrderOfEmails(),true,"Nije alphabetical.");
    
    
}	              
@Test	                                         //mailok2
void tc76() throws InterruptedException {
    
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnSortByEmail();
    listUserPage.clickOnSortByEmail();
    assertEquals(listUserPage.isAlphabeticalOrderOfEmails(),false," alphabetical je.");
    
    
}	     
@Test	                                         //okznaci eliminisi
void tc77() throws InterruptedException {
    
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnSortByName();
    assertEquals(listUserPage.isAlphabeticalOrderOfNames(),true,"Nije alphabetical");
    
    
}	       	
@Test	                                         //  oknece2kl
void tc78() throws InterruptedException {
    
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnSortByName();
    listUserPage.clickOnSortByName();
    assertEquals(listUserPage.isAlphabeticalOrderOfNames(),false," alphabetical je.");
    
    
}	    	
@Test	                                         //  date    
void tc79() throws InterruptedException {
    
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnSortByDate();
    assertEquals(listUserPage.isHronollogicalOrderOfDates2(),true," nije Chronologiical");
}    
    
	    	                                     //disable
                 
@Test	                                         
void tc80() throws InterruptedException {
    String y = "Loren Chandelier";
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnDisableUser(y);
    listUserPage.clickOnCancelfromDialogDisable();
    assertEquals(listUserPage.getStatusInTable(y),"enabled"," nije dobar Status");
}    	
@Test	                                           
void tc81() throws InterruptedException {
    String y = "Loren Chandelier";
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnDisableUser(y);
    listUserPage.clickOnDisableFromDialogDisable();
    assertEquals(listUserPage.getStatusInTable(y),"disabled","nije dobar Status");
}    	
@Test	                                        
void tc82() throws InterruptedException {
    String y = "Loren Chandelier";
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnEnableUser(y);
    listUserPage.clickOnCancelfromDialogEnable();
    assertEquals(listUserPage.getStatusInTable(y),"disabled","nije dobar Status");
}    	
@Test	                                         //500 
void tc83() throws InterruptedException {
    String y = "Loren Chandelier";
    ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnEnableUser(y);
    listUserPage.clickOnEnableFromDialogEnable();
    assertEquals(listUserPage.getStatusInTable(y),"enabled","nije dobar Status");
}    	

                                                        //update sad
@Test
void tc84() throws InterruptedException {
	String y = "Loren Chandelier";
	ListUserPage listUserPage = new ListUserPage(driver);
    listUserPage.clickOnUpdateUser(y);
    AddUserPage addUserPage = new AddUserPage(driver, false);
    assertEquals(addUserPage.getNameText(),y,"Nije dobro ime");
    addUserPage.clickOnCancel();
    assertEquals(listUserPage.countUsersWithName(y),1,"broj los");
}
                                      
@Test
void tc85() throws InterruptedException {
String y = "Loren Chandelier";
ListUserPage listUserPage = new ListUserPage(driver);
listUserPage.clickOnUpdateUser(y);
AddUserPage addUserPage = new AddUserPage(driver, false);
assertEquals(addUserPage.getNameText(),y,"Nije ime dobro");
addUserPage.insertNameOfUser("");
addUserPage.clickOnSave();
assertEquals(addUserPage.isErrorNameDisplayed(),true,"nije prikazana");
assertEquals(addUserPage.getNameErrorText(),"This field is required.","Los text poruke");
}

@Test
 void t86() throws InterruptedException {
      String y = "Loren Chandelier";
      String u ="LorenTwo";
     ListUserPage listUserPage = new ListUserPage(driver);
     listUserPage.clickOnAddNewUser();
     AddUserPage addUserPage = new AddUserPage(driver, true);
     addUserPage.insertNameOfUser(u);
     addUserPage.insertEmail("asd@maipppl.com");
     addUserPage.insertPhone("345888");
     addUserPage.clickOnSave();
     
     listUserPage.clickOnUpdateUser(y);
    // AddUserPage addUserPage = new AddUserPage(driver, false);
     assertEquals(addUserPage.getNameText(),y,"Nije dobro ime");
    addUserPage.insertNameOfUser(u);
    addUserPage.clickOnSave();
    assertEquals(driver.getCurrentUrl(),URLConst.USER_LIST,"Los URL");
    assertEquals(listUserPage.countUsersWithName(u),1,"lose ime");
}

@Test
 void tc87() throws InterruptedException {
     String n ="Updated";
      String u ="LorenTwo";
      ListUserPage listUserPage = new ListUserPage(driver);
      listUserPage.clickOnUpdateUser(u);
       AddUserPage addUserPage = new AddUserPage(driver, false);
       assertEquals(addUserPage.getNameText(),u,"Nije ime");
      addUserPage.insertNameOfUser(n);
      addUserPage.clickOnSave();
      assertEquals(driver.getCurrentUrl(),URLConst.USER_LIST,"Los URL");
      assertEquals(listUserPage.countUsersWithName(n),1,"Nije dobar broj.");
      assertEquals(listUserPage.countUsersWithName(u),0,"Nije dobar broj.");

}
                                       //phone i delete photo
@Test                                              
void tc88() throws InterruptedException {
	  String m = "381222333";
	  String z = "+381652335670";
      String u ="Loren";
      ListUserPage listUserPage = new ListUserPage(driver);
      listUserPage.clickOnUpdateUser(u);
      AddUserPage addUserPage = new AddUserPage(driver, false);
      addUserPage.clickOnDeletePhoto();
      assertEquals(addUserPage.getPhoneText(),z,"Nije dobar broj");
      addUserPage.insertPhone(m);
      addUserPage.choosePhoto(); 
      addUserPage.clickOnSave();
      assertEquals(driver.getCurrentUrl(),URLConst.USER_LIST,"Los url.");
      assertEquals(listUserPage.countUsersWithName(u),1,"Nije dobar broj.");
      assertEquals(listUserPage.getPhoneFromTable(u),m,"Nije dobar broj.");

}                                                      
  @Test
  void tc89() throws InterruptedException {
	  String x ="93";
	  ListUserPage listUserPage = new ListUserPage(driver); 
	  listUserPage.enterQueryInSearch(x);
	   assertEquals(listUserPage.isQuerySearchAmongNumbers(x),true,"Upit nije u listi.");
	   assertEquals(listUserPage.HowManyNumContainsQuery(x),1,"Nije dobar broj.");
	   assertEquals(listUserPage.isQuerySearchAmongPhones(x),true,"Upit nije u listi.");
	   assertEquals(listUserPage.HowManyPhonesContainsQuery(x),3,"Nije dobar broj.");
	   assertEquals(listUserPage.getCurrPageTableSize(),4,"Nije dobar broj.");
  }
  @Test
  void tc90() throws InterruptedException {
	  String x ="loren";
	  ListUserPage listUserPage = new ListUserPage(driver); 
	  listUserPage.enterQueryInSearch(x);
	   assertEquals(listUserPage.isQuerySearchAmongNames(x),true,"Upit nije u listi.");
	   assertEquals(listUserPage.HowManyNamesContainsQuery(x),2,"Nije dobar broj.");
	   assertEquals(listUserPage.getCurrPageTableSize(),2,"Nije dobar broj.");
  }
  @Test
  void tc91() throws InterruptedException {
	  String x ="lo  ren";
	  ListUserPage listUserPage = new ListUserPage(driver); 
	  listUserPage.enterQueryInSearch(x);
	   assertEquals(listUserPage.isNoFoundDisplayed(),true,"Poruka nije prikazana.");
	   assertEquals(listUserPage.getNoFundText(),"No matching records found","");
	   assertEquals(listUserPage.getCurrPageTableSize(),0,"Nije dobar broj.");
  }
  @Test
  void tc92() throws InterruptedException {
	  String x ="asd";
	  ListUserPage listUserPage = new ListUserPage(driver); 
	  listUserPage.enterQueryInSearch(x);
	  assertEquals(listUserPage.isQuerySearchAmongEmails(x),true,"Upit nije u listi.");
	   assertEquals(listUserPage.HowManyMailsContainsQuery(x),2,"Nije dobar broj.");
	   assertEquals(listUserPage.getCurrPageTableSize(),2,"Nije dobar broj.");
	   
	   
  }
  @Test
  void tc93() throws InterruptedException {
	  String x ="lorenfox";
	  ListUserPage listUserPage = new ListUserPage(driver); 
	  listUserPage.enterQueryInSearch(x);
	  assertEquals(listUserPage.isQuerySearchAmongNames(x),true,"Upit nije u listi.");
	   assertEquals(listUserPage.HowManyNamesContainsQuery(x),1,"Nije dobar broj.");
	   assertEquals(listUserPage.getCurrPageTableSize(),1,"Nije dobar broj.");
	   
	   
  }
  @Test
  void tc94() throws InterruptedException {
	  String x ="#";
	  ListUserPage listUserPage = new ListUserPage(driver); 
	  listUserPage.enterQueryInSearch(x);
	  assertEquals(listUserPage.isQuerySearchAmongEmails(x),true,"");
	   assertEquals(listUserPage.HowManyMailsContainsQuery(x),1,"Nije dobar broj.");
	   assertEquals(listUserPage.isQuerySearchAmongPhones(x),true,"Upit nije u listi.");
	   assertEquals(listUserPage.HowManyPhonesContainsQuery(x),1,"Nije dobar broj.");
	   assertEquals(listUserPage.getCurrPageTableSize(),2,"Nije dobar broj.");
	   
	   
  }
                                                                //pagin
  @Test                                           
  void tc95() throws InterruptedException {
	  ListUserPage  listUserPage = new ListUserPage(driver); 
	  assertEquals(listUserPage.isFirstPageDisplayed(),true,"Nije prikazana");
	  assertEquals(listUserPage.getUserName("5"),"Elastic Heart Sia","nije dobro ime");
  }
  @Test                                           
  void tc96() throws InterruptedException {
	  ListUserPage  listUserPage = new ListUserPage(driver); 
	  assertEquals(listUserPage.getListOfUserSerNumOnCurrPage(),"[1, 2, 3, 4, 5]","Nije dobra lista");
  }  
	@Test
	void tc97() throws InterruptedException {
		 ListUserPage  listUserPage = new ListUserPage(driver); 
		 listUserPage .clickOnLastPage();
		 assertEquals(listUserPage.isLastPageDisplayed(),true,"Nije prikazana");
	}


	  
	  
	  	  
 
}		
                       
	

