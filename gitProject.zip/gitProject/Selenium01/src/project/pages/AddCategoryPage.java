package project.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cubes.main.URLConst;

public class AddCategoryPage {

	private WebDriver driver;
	@FindBy(xpath="//input[@name='name']")
	private WebElement weCatName;
	@FindBy(xpath="//textarea[@name='description']")
	private WebElement weCatDesc;
	@FindBy(xpath="//button[text()='Save']")
	private WebElement weSave;
	@FindBy(xpath="//a[text()='Cancel']")
	private WebElement weCancel;
	@FindBy(id="name-error")
	private WebElement weCatNameError;
	@FindBy(id="description-error")
	private WebElement weCatDescError;
	@FindBy(xpath="//div[@class='invalid-feedback']")
	private WebElement descErrorlength;
	
	public AddCategoryPage(WebDriver driver, boolean openPage) {
		this.driver=driver;
		this.driver.manage().window().maximize();
		if(openPage) {
			this.driver.get(URLConst.CATEGORY_ADD);
		}
		PageFactory.initElements(driver, this);
	}
	
	
	public void clickOnHome() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Home']"));
		x.click();		
	}
	public void clickOnPostCategories() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Post Categories']"));
		x.click();		
	}
	public void insertCatName(String catName) {
		weCatName.clear();
		weCatName.sendKeys(catName);
	}
	public void insertCatDesc(String catDesc) {
		weCatDesc.clear();
		weCatDesc.sendKeys(catDesc);
	}
	public void clickOnSave() throws InterruptedException {
		weSave.click();
		Thread.sleep(500);
	}
	public void clickOnCancel()  {
		weCancel.click();
	
	}
	
	
	public boolean isCatNameErrorDisplayed() {
		return weCatNameError.isDisplayed();
	}
	public boolean isCatDescErrorDisplayed() {
		return weCatDescError.isDisplayed();
	}
	public boolean isCatDesctwoErrorDisplayed() {
		return descErrorlength.isDisplayed();
	}
	
	public String  getCatDesctwoErrorText() {
		return descErrorlength.getText();
	}
	public String getCatNameErrorText() {
	      return weCatNameError.getText();
	}
	public String getCatDescErrorText() {
		return weCatDescError.getText();
	}
	
	public String getCatNameText() {
		return weCatName.getAttribute("value");	
	}
	public String getCatDescText() {
		return weCatDesc.getAttribute("value");
	}
	public void addNewCat(String catName,String descName ) throws InterruptedException {
		insertCatName(catName);
		insertCatDesc(descName);
		clickOnSave();
	}
	
	
	
	
	
}
