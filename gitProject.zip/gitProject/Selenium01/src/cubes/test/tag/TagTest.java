package cubes.test.tag;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cubes.MyWebDriver;
import cubes.main.URLConst;
import cubes.main.Utils;
import cubes.pages.AddTagPage;
import cubes.pages.LoginPage;
import cubes.pages.tag.ListTagPage;

class TagTest {
	//public static String urlLoginPage = "https://testblog.kurs-qa.cubes.edu.rs/login";
     private static WebDriver driver;
     private static String tempTagName;
     private static String updatedTagName;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		driver=MyWebDriver.getInstance().getDriver("chrome");
		///WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("name")));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		updatedTagName = Utils.getRandomTagName();
		tempTagName = Utils.getRandomTagName();
				
		//driver.manage().window().maximize();
		//driver.get(URLConst.LOGIN);
		//WebElement  weEmail = driver.findElement(By.xpath("//input[@type='email']"));
		//WebElement  wePassword =driver.findElement(By.xpath("//input[@type='password']"));
		//WebElement  weSignIn = driver.findElement(By.xpath("//button[@type='submit']"));
		LoginPage loginPage = new LoginPage(driver);
		loginPage.loginSuccess();
		//weEmail.sendKeys("kursqa@cubes.edu.rs");
		//wePassword.sendKeys("cubesqa");
		//weSignIn.click();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		//logout
		driver.close();
	}

	@BeforeEach
	void setUp() throws Exception {
		driver.get(URLConst.TAG_LIST);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void tc01() throws InterruptedException {
		AddTagPage addTagPage = new AddTagPage(driver,true);
		addTagPage.insertTagName("");
		//Thread.sleep(1000);
		addTagPage.clickOnSave();
		assertEquals(addTagPage.isNameErrorDisplayed(),true,"Poruka nije prikazana");
		assertEquals(addTagPage.getNameErrorText(),"This field is required.","Poruka nije dobra");
		assertEquals(driver.getCurrentUrl(),URLConst.TAG_ADD,"URL nije dobar");
	}
    @Test
    void tc02() {
    	AddTagPage addTagPage = new AddTagPage(driver,true);
    	addTagPage.insertTagName("");
    	addTagPage.clickOnCancel();
    	assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"URL nije dobar");
    }
	@Test
	void tc03() throws InterruptedException {
		AddTagPage addTagPage = new AddTagPage(driver,true);
		 //String tempTagName = Utils.getRandomTagName();
		 addTagPage.insertTagName(tempTagName);
		 Thread.sleep(2000);
		 addTagPage.clickOnCancel();
		 assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"Url nije dobar");
		 ListTagPage listTagPage = new ListTagPage(driver);
		 assertEquals(listTagPage.countTagsWithName(tempTagName),0,"Tag je u listi");
	}
	@Test
	void tc04() throws InterruptedException  {
		AddTagPage addTagPage = new AddTagPage(driver,true);
		//String tempTagName = Utils.getRandomTagName();
		addTagPage.insertTagName(tempTagName);
		//Thread.sleep(2000);
		addTagPage.clickOnSave();
		assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"Url nije dobar");
		ListTagPage listTagPage = new ListTagPage(driver);
		
		assertEquals(listTagPage.countTagsWithName(tempTagName),1,"Tag nije u listi,vise ihje");
		//Thread.sleep(2000);
		//listTagPage.deleteTag(tempTagName);	
		
	}
	//@Test
	//void tc05() throws InterruptedException {
		//ListTagPage listTagPage = new ListTagPage(driver);
		
		//assertEquals(listTagPage.isTagWithNameInList("weTag"),0,"tag je u listi.");
	
	
	//@Test
	//void tc06() {
	//	ListTagPage listTagPage = new ListTagPage(driver);
	//	assertEquals(listTagPage.isTagWithNameInList("weTag"),false,"tag je u listi.");//"weTag"moze
	//}
	//@Test
	//void tc07() {
	//	ListTagPage listTagPage = new ListTagPage(driver);
	//    assertEquals(listTagPage.countTagsWithName("asds"),0,"Tag je u listi");
	//}
	//@Test 
	//void tc08() throws InterruptedException {
	//	ListTagPage listTagPage = new ListTagPage(driver);
	//	listTagPage.doLogout();
	//}
	//@Test
	//void tc09() throws InterruptedException {
		//AddTagPage addTagPage = new AddTagPage(driver);
		//String tempTagName = Utils.getRandomTagName();
		//addTagPage.insertTagName(tempTagName);
		//Thread.sleep(2000);
		//addTagPage.clickOnSave();
		//ListTagPage listTagPage = new ListTagPage(driver);
		//listTagPage.getTagWithNameList("weTag");
		//assertEquals(listTagPage.getTagWithNameList("weTag"),"[]","Elem je u listi.");
	//}
	//@Test
	//void tc10() throws InterruptedException {
	//	ListTagPage listTagPage = new ListTagPage(driver);
	//	listTagPage.editName();
	
	@Test
	void tc05() throws InterruptedException {
		//AddTagPage addTagPage = new AddTagPage(driver);
		//String tempTagName = Utils.getRandomTagName();
		ListTagPage listTagPage = new ListTagPage(driver);
		listTagPage.clickOnUpdateTag(tempTagName);
		AddTagPage addTagPage = new AddTagPage(driver,false);
		assertEquals(tempTagName,addTagPage.getTagNameText(),"Nije dobar naziv taga.");
		addTagPage.clickOnCancel();
		assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"url nije dobar");
		assertEquals(listTagPage.countTagsWithName(tempTagName),1,"Stari tag nije u listi");
		//addTagPage.insertTagName(tempTagName);
		//addTagPage.clickOnSave();
		//addTagPage.addNewTag(tempTagName);
		//assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"url nije dobar");
		//ListTagPage listTagPage = new ListTagPage(driver);
		//int countTags = listTagPage.countTagsWithName(tempTagName);
		//assertEquals(countTags,1,"Tag nije u listi ili ih je vise");
		//Thread.sleep(3000);
		//listTagPage.clickOnUpdateTag(tempTagName);
		//assertEquals(tempTagName,addTagPage.getTagNameText(),"Nije dobar naziv taga.");
		//String updateTagName= Utils.getRandomTagName();
		//addTagPage.clickOnCancel();
		//addTagPage.insertTagName(updateTagName);
		//addTagPage.clickOnSave();
		//assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"Url nije dobar");
		//assertEquals(listTagPage.countTagsWithName(tempTagName),0,"stari tag se pojavljuje u listi");
		//assertEquals(listTagPage.countTagsWithName(updateTagName),1,"Novi tag nije u listi.");
		//listTagPage.deleteTag(updateTagName);
	}
	@Test
	void tc06() {
		AddTagPage addTagPage = new AddTagPage(driver,false);
		ListTagPage listTagPage = new ListTagPage(driver);
		listTagPage.clickOnUpdateTag(tempTagName);
		assertEquals(tempTagName,addTagPage.getTagNameText(),"Nije dobar naziv taga.");
		addTagPage.insertTagName("");
		addTagPage.clickOnSave();
		assertEquals(addTagPage.isNameErrorDisplayed(),true,"Poruka nije prikazana");
		assertEquals(addTagPage.getNameErrorText(),"This field is required.","nije dob poruka");
		//assertEquals(addTagPage.getNameErrorText(),"The name has already been taken.","nije dobra");
		
	}
	@Test
	void tc07() throws InterruptedException {
		AddTagPage addTagPage = new AddTagPage(driver,true);
		String secondTagName = addTagPage.addNewTag();
		ListTagPage listTagPage = new ListTagPage(driver);
		listTagPage.clickOnUpdateTag(tempTagName);
		assertEquals(tempTagName,addTagPage.getTagNameText(),"Nije dobar naziv taga.");
		addTagPage.insertTagName(secondTagName);
		addTagPage.clickOnSave();
		assertEquals(addTagPage.isNameErrorDisplayed(),true,"nijeprik");
		assertEquals(addTagPage.getNameErrorText(),"The name has already been taken.","nije dobra");
		addTagPage.clickOnCancel();
		assertEquals(listTagPage.countTagsWithName(secondTagName),1,"nije ulisti");
		assertEquals(listTagPage.countTagsWithName(tempTagName),1,"nije ulisti");
		listTagPage.deleteTag(secondTagName);
	}
	@Test
	void tc08() {
		ListTagPage listTagPage = new ListTagPage(driver);
		listTagPage.clickOnUpdateTag(tempTagName);
		AddTagPage addTagPage = new AddTagPage(driver,false);
		assertEquals(tempTagName,addTagPage.getTagNameText(),"Nije dobar naziv taga.");
		addTagPage.insertTagName(updatedTagName);
		addTagPage.clickOnSave();
		assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"url nije dobar");
		assertEquals(listTagPage.countTagsWithName(tempTagName),0,"Stari tag je u listi");
		assertEquals(listTagPage.countTagsWithName(updatedTagName),1," tag nije u listi");
	}
	@Test
	void tc09() {
		ListTagPage listTagPage = new ListTagPage(driver);
		listTagPage.clickOnDeleteTag(updatedTagName);
		listTagPage.clickOnDeleteDialogCancel();
		assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"url nije dobar");
		assertEquals(listTagPage.countTagsWithName(updatedTagName),1,"Stari tag nije u listi");
	}
	@Test
	void tc10() {
		ListTagPage listTagPage = new ListTagPage(driver);
		listTagPage.clickOnDeleteTag(updatedTagName);
		listTagPage.clickOnDeleteDialogDelete();
		assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"url nije dobar");
		assertEquals(listTagPage.countTagsWithName(updatedTagName),0,"Stari tag nije u listi");
	}
	
	//@Test
	///void tc11() throws InterruptedException {
		
		//AddTagPage addTagPage = new AddTagPage(driver);
		//String tempTagName = Utils.getRandomTagName();
		//addTagPage.addNewTag(tempTagName);
		//ListTagPage listTagPage = new ListTagPage(driver);
		//assertEquals(listTagPage.countTagsWithName(tempTagName),1," tag nije pouje u listi");
		//String updateTagName= Utils.getRandomTagName();
		//listTagPage.clickOnAddNewTag();
		//addTagPage.insertTagName(updateTagName);
		//addTagPage.clickOnSave();
		////assertEquals(listTagPage.countTagsWithName(tempTagName),1," tag nije pouje u listi");
		///assertEquals(listTagPage.countTagsWithName(updateTagName),1,"drugi tag nije u listi");
		//Thread.sleep(2000);
		//listTagPage.clickOnUpdateTag(updateTagName);
		//assertEquals(updateTagName,addTagPage.getTagNameText(),"Nije dobar naziv taga");
		//addTagPage.insertTagName(tempTagName);
		//addTagPage.clickOnSave();
		//assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"Url nije dobar");
		//assertEquals(listTagPage.countTagsWithName(updateTagName),0,"novi nije uje ulisti");
		//assertEquals(listTagPage.countTagsWithName(tempTagName),1,"stari je uje  ulisti");
	//}
	//@Test
	//void tc16(){
		//ListTagPage listTagPage = new ListTagPage(driver);
		//listTagPage.clickOnUpdateTag(tempTagName);
		//AddTagPage addTagPage = new AddTagPage(driver,false);
		//assertEquals(tempTagName,addTagPage.getTagNameText(),"Nije dobar naziv taga");
		//addTagPage.insertTagName("");
		//addTagPage.clickOnSave();
		//assertEquals(addTagPage.isNameErrorDisplayed(),true,"Poruka nije prikazana");
		//assertEquals(addTagPage.getNameErrorText(),"This field is required.","nije dob poruka");
		//assertEquals(driver.getCurrentUrl(),URLConst.TAG_ADD,"los url");
	//}
	//@Test
	//void tc17() throws InterruptedException {
		//AddTagPage addTagPage = new AddTagPage(driver,true);
		//String secTagName = Utils.getRandomTagName();
		//addTagPage.insertTagName(secTagName);
		//addTagPage.clickOnSave();
		//ListTagPage listTagPage = new ListTagPage(driver);
		//assertEquals(listTagPage.countTagsWithName(secTagName),1,"nije ulisti");
		//listTagPage.clickOnUpdateTag(tempTagName);
	//	assertEquals(tempTagName,addTagPage.getTagNameText(),"Nije dobar naziv taga");
		//addTagPage.insertTagName(secTagName);
		//addTagPage.clickOnSave();
		//assertEquals(addTagPage.isNameErrorDisplayed(),true,"nije dobgreska");
	//assertEquals(addTagPage.getNameErrorText(),"The name has already been taken.","nije dobra");
		//addTagPage.clickOnCancel();
		//assertEquals(listTagPage.countTagsWithName(secTagName),1,"nije ulisti");
		//assertEquals(listTagPage.countTagsWithName(tempTagName),1,"nije ulisti");
		//listTagPage.deleteTag(secTagName);
		
	//}
	//@Test
	//void tc18() throws InterruptedException {
	//	ListTagPage listTagPage = new ListTagPage(driver);
	//	listTagPage.clickOnUpdateTag(tempTagName);
	//	AddTagPage addTagPage = new AddTagPage(driver,false);
	//	assertEquals(tempTagName,addTagPage.getTagNameText(),"Nije dobar naziv taga");
	//	addTagPage.insertTagName(updatedTagName);
	//	addTagPage.clickOnSave();
	//	assertEquals(driver.getCurrentUrl(),URLConst.TAG_LIST,"los url");
	//	assertEquals(listTagPage.countTagsWithName(tempTagName),0,"stari u listi");
	//	assertEquals(listTagPage.countTagsWithName(updatedTagName),1,"novi nije u listilisti");
	//	listTagPage.deleteTag(updatedTagName);
	//}
	
	
	
	}
	
	

