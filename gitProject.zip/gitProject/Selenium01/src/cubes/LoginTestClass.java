package cubes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cubes.main.URLConst;

public class LoginTestClass {

	public static void main(String[] args) throws InterruptedException {
		
		String urlLoginPage = "https://testblog.kurs-qa.cubes.edu.rs/login";
			
       // System.setProperty("webdriver.chrome.driver","D:/Desktop/webdriver/chromedriver.exe");
		
		//ChromeDriver chromeDriver = new ChromeDriver();
		WebDriver driver = MyWebDriver.getInstance().getDriver("chrome");
		driver.get(urlLoginPage);
		driver.manage().window().maximize();
		Thread.sleep(1000);
		
		WebElement weEmail = driver.findElement(By.name("email"));
		WebElement wePassword = driver.findElement(By.name("password"));
		WebElement weSignIn = driver.findElement(By.tagName("button"));
	//tc 15 isp mail isp passw .klik na sign in			
		weEmail.sendKeys("kursqa@cubes.edu.rs");
		wePassword.sendKeys("cubesqa");
		weSignIn.click();
		
		System.out.println(driver.getTitle());
		
		if(driver.getTitle().equalsIgnoreCase("Admin Page | Blog")) {
			System.out.println("TC15-ok");
		}
		else {System.out.println("TC15-NOT ok");}
	//tc01 prazno mail .prazno passw,klik na sign in
		weEmail.sendKeys("");
		wePassword.sendKeys("");
		weSignIn.click();
		
		if(driver.getCurrentUrl().equalsIgnoreCase(urlLoginPage)) {
			System.out.println("TC 01-ok");
		}
		else {
			System.out.println("TC 01-Not ok");
		}
		
		
		
		
		
		
		
		
		
		

	}

}
