package project.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cubes.main.URLConst;
import cubes.main.Utils;

public class ListPostPage {
        private WebDriver driver;
        
        @FindBy(xpath="//a[@class='btn btn-success']")
        private WebElement weAddNewPost;
	    @FindBy(xpath="//input[@type='text']")
	    private WebElement weTitle;
        @FindBy(xpath="//select[@name='entities-list-table_length']")
	    private WebElement showEntries;
	    
	    @FindBy(xpath="//input[@class='form-control form-control-sm']")
	    private WebElement searchPost;
	    @FindBy(xpath="//li[@id='entities-list-table_previous']")
	     private WebElement previous;
	    
	    @FindBy(xpath="//td[@class='dataTables_empty']")
	    private WebElement tabmass;
	  
	  
	  public ListPostPage(WebDriver driver) {
		  this.driver = driver;
		  // this.driver.manage().window().maximize();
		  //this.driver.get(URLConst.POST_LIST);
		  PageFactory.initElements(driver, this);
		  
		   }
	 	  
	  public int countPostsWithName(String name) throws InterruptedException {
	      WebElement x = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a"));
	      ((JavascriptExecutor)driver).executeScript("window.scrollBy(3000,0)");
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
		 //((JavascriptExecutor)driver).executeScript("window.scrollBy(0,6000)");
		  Thread.sleep(1000);
	      x.click();
	      Thread.sleep(1000);
		 List<WebElement> l = driver.findElements(By.xpath("//td[text()='"+name+"']"));
		 return l.size();
	}
	  
	  public int countPostWithTitle(String name) throws InterruptedException {
		   WebElement x = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a"));
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
			 Thread.sleep(1000);
		      x.click();
		      Thread.sleep(1000);
			List<WebElement> l = driver.findElements(By.xpath("//td[text()='"+name+"']"));
			return l.size();
		}
      	
      
   public void insertTitle(String title) {
	    weTitle.clear();
	    weTitle.sendKeys(title);
 }  

  public boolean isEnteredTitleInTable(String name) {
    List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[5]"));
    for(int i = 0;i<x.size();i++) {
	if(x.get(i).getText().equalsIgnoreCase(name)) {
		return true;
	}
  }
    return false;
  }

   public String getTitleText() {
           return weTitle.getAttribute("value");
      }
                   



      // Autor select HIDDEN 1 .2 //Prvi loc 1 od 1//2gi lokat 1 od70brclan liste)
      public void clickOnChAuthor() {

           WebElement el = driver.findElement(By.xpath("//span[@class='select2-selection__rendered'][@Title='--Choose Author --']"));

          ((JavascriptExecutor)driver).executeScript("arguments[0].removeAttribute('style');", el);

           el.click();


       }

       public void clickOnOptionForAuthor(String name) {
               List<WebElement>options = driver.findElements(By.xpath("//select[@name='user_id']//option"));
               for(int i= 0;i<options.size();i++) {
               if(options.get(i).getText().contains(name)) {
               options.get(i).click();
    }
    }                                                       
     }
        public void scrollInsideAuthorList() {
          WebElement x = driver.findElement(By.xpath("//select[@name='user_id']//option[9]"));
          Actions act = new Actions(driver);
          act.scrollToElement(x).perform();
          x.click();
        }


                                         // SIZE i NAME
       public int getSizeOfAutorList() {
            List<WebElement>options = driver.findElements(By.xpath("//select[@name='user_id']//option"));
            return options.size();
     }
       public String getNameSelOptAutor() {                        
            String x = "";
            List<WebElement>op = driver.findElements(By.xpath("//select[@name='user_id']//option"));

            for(int i =0;i<op.size();i++) {
            if(op.get(i).isSelected()) {
            x = op.get(i).getText();
      }

      }
     return x;	
   }	

         public String getNameSelOpAutor(int n) {

            WebElement dd = driver.findElement(By.xpath("//select[@name='user_id']"));
            Select sel = new Select(dd);
            sel.selectByIndex(n);
            String st = sel.getFirstSelectedOption().getText();
 
            return st;	
       }                       
      public boolean isChoosenAuthorInTable(String name) {
        List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[6]"));
        for(int i = 0;i<x.size();i++) {
        if(x.get(i).getText().equalsIgnoreCase(name)) {
        return true;
   }
   }
           return false;
   }

                                            // CATEGORY prve2

    public void clickOnCategory() {
	     WebElement el = driver.findElement(By.xpath("//span[@class='select2-selection__rendered'][@title='--Choose Category --']"));
		((JavascriptExecutor)driver).executeScript("arguments[0].removeAttribute('style');", el);
		
         el.click();
	
		 
		 }
	  
	   
   public void clickOnOptionForCategory(String name) {
	  List<WebElement>options = driver.findElements(By.xpath("//select[@name='post_category_id']//option"));
	  for(int i= 0;i<options.size();i++) {
		  if(options.get(i).getText().contains(name)) {
			  options.get(i).click();
		  }
	  }
 }
 

                                             
 public int getSizeOfCategList() {
  List<WebElement>options = driver.findElements(By.xpath("//select[@name='post_category_id']//option"));
  return options.size();
   }                                                      

   public String getNameSelOptCategory() {
      String x = "";
   List<WebElement>op = driver.findElements(By.xpath("//select[@name='post_category_id']//option"));

    for(int i =0;i<op.size();i++) {
       if(op.get(i).isSelected()) {
       x = op.get(i).getText();
      }

      }
     return x;	
     
  }	

    public String getNameSelOpCategory(int n) {

         WebElement dd = driver.findElement(By.xpath("//select[@name='post_category_id']"));
         Select sel = new Select(dd);
         sel.selectByIndex(n);
         String st = sel.getFirstSelectedOption().getText();

        return st;	
   }
    
    public boolean isChoosenCategoryInTable(String name) {
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[7]"));
		for(int i = 0;i<x.size();i++) {
			if(x.get(i).getText().equalsIgnoreCase(name)) {
				return true;
			}
		}
		return false;
	}
               

                                             //IMPORTANTklik ;name
	  
	  
    public void clickOnImportant() {
          WebElement dd = driver.findElement(By.xpath("//select[@name='important']"));
          ((JavascriptExecutor)driver).executeScript("scroll(0, -250);");
          Utils.scrollToElement(driver,  dd);
          dd.click();
     }

      public void clickOnOptionForImportant(String name) {

          List<WebElement>options = driver.findElements(By.xpath("//select[@name='important']//option"));

          for(int i= 0;i<options.size();i++) {
          if(options.get(i).getText().contains(name)) {
          options.get(i).click();
}
}
}                                                             
                                    //IMPORTANt  KOSELEK import 2fale ILi GETTEXT

     public int getSizeOfImportantList() {
       List<WebElement>options = driver.findElements(By.xpath("//select[@name='important']//option"));
       return options.size();
} 
     public String getNameSelImportant() {

       String x = "";
       List<WebElement>options = driver.findElements(By.xpath("//select[@name='important']//option"));

       for(int i =0;i<options.size();i++) {
       if(options.get(i).isSelected()) {
       x = options.get(i).getText();}
}
       return x;
}
      public String getNameSelOpImportant(int n) { 

        WebElement dd = driver.findElement(By.xpath("//select[@name='important']"));
        Select sel = new Select(dd);
        sel.selectByIndex(n);
        String st = sel.getFirstSelectedOption().getText();

        return st;	
   }


     public boolean isChoosenImportantInTable(String name) {
        List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[3]"));
        for(int i = 0;i<x.size();i++) {
        if(x.get(i).getText().equalsIgnoreCase(name)) {
        return true;
}
 }
        return false;
}
                     

                                                         //STATUS ;NAME
     public void clickOnStatus() {
        WebElement dd = driver.findElement(By.xpath("//select[@name='status']"));
        dd.click();
}
     public void clickOnOptionForStatus(String name) {
          List<WebElement>options = driver.findElements(By.xpath("//select[@name='status']//option"));

          for(int i= 0;i<options.size();i++) {
          if(options.get(i).getText().contains(name)) {
          options.get(i).click();
}
}
}   

      public int getSizeOfStatusList() {
           List<WebElement>options = driver.findElements(By.xpath("//select[@name='status']//option"));
           return options.size();
} 

      public String getNameSelStatus() {

           String x = "";
           List<WebElement>options = driver.findElements(By.xpath("//select[@name='status']//option"));

           for(int i =0;i<options.size();i++) {
           if(options.get(i).isSelected()) {
           x = options.get(i).getText();}
}
           return x;
}

    public String getNameSelOpStatus(int n) {  

            WebElement dd = driver.findElement(By.xpath("//select[@name='status']"));
            Select sel = new Select(dd);
            sel.selectByIndex(n);
            String st = sel.getFirstSelectedOption().getText();

            return st;	
}

    public boolean isChoosenStatusInTable(String name) {
           List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[4]"));
           for(int i = 0;i<x.size();i++) {
           if(x.get(i).getText().equalsIgnoreCase(name)) {
           return true;
}
}
           return false;
}    
                 


                                  //wITH TAG =SEARCH DROPDOWN

   public void clickOnWithTag() {
         WebElement el = driver.findElement(By.xpath("//ul[@class='select2-selection__rendered']"));
         WebElement x = driver.findElement(By.xpath("//select[@name='tag_ids']"));
        ((JavascriptExecutor)driver).executeScript("arguments[0].removeAttribute('aria-hidden');", el);
         //((JavascriptExecutor)driver).executeScript("arguments[0].setAttribute('aria-selected', 'true');",x);
         el.click();


}
    public void clickOnWithTagOption(String name)  {
       List<WebElement>opt = driver.findElements(By.xpath("//select[@name='tag_ids']//option"));
       // ((JavascriptExecutor)driver).executeScript("arguments[0].removeAttribute('aria-selected');",opt);
      for(int i= 0;i<opt.size();i++) {
      if(opt.get(i).getText().contains(name)) {
       opt.get(i).click();
}
}

}                                              //SCROLL NA GORESSSS(0,-2000)


         public void scrollInsideWithTagList() {
            WebElement x = driver.findElement(By.xpath("//select[@name='tag_ids']//option[5]"));

           Actions act = new Actions(driver);
           act.moveToElement(x).perform();
           x.click();

}

        public int getSizeOfWithTagList() {
               List<WebElement>options = driver.findElements(By.xpath("//select[@name='tag_ids']//option"));
               return options.size();
}

      public int getNumbOfSelInWithTagList() {
           List<WebElement>list = driver.findElements(By.xpath("//select[@name='tag_ids']//option"));
           int m = 0;
           for(int i = 0;i<list.size();i++) {
           if(list.get(i).isSelected()) {
            m++;
}
}
          return m;
}

     public String getNameSelInWithTag() {

          String x = "";
          List<WebElement>options = driver.findElements(By.xpath("//select[@name='tag_ids']//option"));

          for(int i =0;i<options.size();i++) {
           if(options.get(i).isSelected()) {
          x = options.get(i).getText();}
}
          return x;
}                                             

      public String getNameSelWithTag(int n) {

           WebElement dd = driver.findElement(By.xpath("//select[@name='tag_ids']"));
           Select sel = new Select(dd);
           sel.selectByIndex(n);
           String st = sel.getFirstSelectedOption().getText();

           return st;	
}

    public boolean isChoosenWithTagInTable(String name) {
           List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[8]"));
           for(int i = 0;i<x.size();i++) {
           if(x.get(i).getText().equalsIgnoreCase(name)) {
           return true;
}
}
           return false;
}
           
     public    String   getListStringWithTag()  {
          String x ="";
          List<String> text = new ArrayList<String>();
          List< WebElement> list =  driver.findElements(By.xpath("//select[@name='tag_ids']//option"));

           for(int i =0;i<list.size();i++) {
          if(list.get(i).isSelected()) { 

          x = driver.findElement(By.xpath("//select[@name='tag_ids']//option")).getText();
          text.add(x);

}

} 
          return text.toString();
}                

     public String getAllSelInWithTag() {

        List <String>st = new ArrayList<String>();
        WebElement dd = driver.findElement(By.xpath("//select[@name='tag_ids']"));
        Select sel = new Select(dd);
        List<WebElement> we = sel.getAllSelectedOptions();

        for(WebElement el:we) {
        st.add(el.getText());}
      // for(String s:strings) {
           // System.out.println(s);

        return st.toString();     //expected arraylist but wasstringzatu Tostring
}



             	                                //SHOW ENRTIES
     public boolean isTenSelected() {
    	 return driver.findElement(By.xpath("//select[@name='entities-list-table_length']//option[1])")).isSelected();
     }
     
     public void clickOnShowEntries() {
	      showEntries.click();
}
    public void clickOnShowEnOption(String x) throws InterruptedException {
	     List<WebElement> list = driver.findElements(By.xpath("//select[@name='entities-list-table_length']//option"));
	     for(int i=0;i<list.size();i++) {
		 if(list.get(i).getText().contains(x)) {
		        list.get(i).click();
		        Thread.sleep(1000);
		  }
	  }
}

                   
               
  public int getSizeOfShowEnList() {
        List<WebElement>options = driver.findElements(By.xpath("//select[@name='entities-list-table_length']//option"));
        return options.size();
    }

   public String getValueShowEn() {
       String x = "";
       List<WebElement>options = driver.findElements(By.xpath("//select[@name='entities-list-table_length']//option"));

     for(int i =0;i<options.size();i++) {
     if(options.get(i).isSelected()) {
      x = options.get(i).getText();
       }

 }
return x;	
}	

      public void clickOnHome()   {
    	 driver.findElement(By.xpath("//a[text()='Home']")).click();
      }

	  public void openPage() {
		  this.driver.get(URLConst.POST_LIST);
	  }
	  public void clickOnAddnewPost() {
		  weAddNewPost.click();
	  }
	  
	
	  
	  
	  public boolean isPostWithNameInList(String name) {
		  List<WebElement> postList = driver.findElements(By.xpath("//td[text()='"+name+"']"));
		  return postList.size()>0;
	  }
	  public List<WebElement> getListWithPostName(String name) {
		 return driver.findElements(By.xpath("//td[text()='"+name+"']"));
		 
	 }
	 public void deletePost(String name) throws InterruptedException {
		 clickOnDeletePost(name);
		 WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Delete']")));
		 clickOnDeleteDialogDelete();
	 } 
	 
	 
	                                             //ON DELETE POST
	 
	  public void clickOnDeletePost(String name) throws InterruptedException {
		  WebElement n = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a[1]"));
		  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n);
		  Thread.sleep(500);
		  n.click();
		  Thread.sleep(500);
		  WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
		  WebElement deleteButton = driver.findElement(By.xpath("//button[@data-name='"+name+"']"));
		  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
		  Thread.sleep(500);
		  ((JavascriptExecutor)driver).executeScript("window.scrollBy(3000,0)");
		  Thread.sleep(500);
		  deleteButton.click();
		  Thread.sleep(500);    
	  }
	  
	  public void clickOnDeleteDialogDelete() {
		  
		  WebElement deleteButton = driver.findElement(By.xpath("//button[text()='Delete']"));
		  deleteButton.click();
	  }
	  private String getDeleteButtonLocator(String name) {
		  return "//td[text()='"+name+"']//ancestor::tr//td[12]//button";
	  }
	  
	  public void clickOnDeleteDialogCancel() {
		  WebElement cancelButton = driver.findElement(By.xpath("//button[text()='Delete']//ancestor::div[1]//button[1]"));
		  cancelButton.click();
	  }
	  //button[text()='Delete']//ancestor::div[1]//button[1]//a[2] ako ima 3 u prvom redu ;ako dva onda a[1] ILI a samo a
	  ///a[2] ako su oko update i bin /a a[1] ako su upd i kan u 1redu
	  
	  
	                                                 //update
	  private String getUpdateButtonlocator(String name) {
		  return "//td[text()='"+name+"']//ancestor::tr[1]//td[12]//a[2]";
	  }
	                                             //scROLL RIGHT
	  
	  public void clickOnUpdatePost(String name) throws InterruptedException {
		  WebElement n = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a[1]"));
		  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n);
		  Thread.sleep(1000);
		  n.click();
		  Thread.sleep(1000);
		  WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
		  WebElement updateButton = driver.findElement(By.xpath(getUpdateButtonlocator(name)));
		  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
		 
		  Thread.sleep(1000);
		  ((JavascriptExecutor)driver).executeScript("window.scrollBy(3000,0)");
		  Thread.sleep(1000);
		 //Utils.scrollToElement(driver,  updateButton);
		  updateButton.click();
		  Thread.sleep(1000);
		  
	  }
	                                                     // sort
	  public void clickOnSortBySerNumber() throws InterruptedException {
		  driver.findElement(By.xpath("//th[@class='sorting_asc']")).click();
		  Thread.sleep(1000);
	  }
	  public void clickOnSortByTitle() throws InterruptedException {
		  driver.findElement(By.xpath("//th[@class='sorting_asc']//following::th[4]")).click();
		  Thread.sleep(2000);
	  }
	
	  public void clickOnSortByAuthor() throws InterruptedException {
		  driver.findElement(By.xpath("//th[@class='sorting_asc']//following::th[5]")).click();
		  Thread.sleep(1000);
	  }                                            
	  
	  public void clickOnSortByCategory() throws InterruptedException {
		  driver.findElement(By.xpath("//th[@class='sorting_asc']//following::th[6]")).click();
		  Thread.sleep(1000);
	  }           
	   public void clickOnSortByDate() throws InterruptedException {
	  driver.findElement(By.xpath("//th[@class='text-center sorting']")).click();
	  Thread.sleep(1000);                             
  }   
	   
	   
	 public boolean isAscOrderOfSerNumbers() {

			List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
			
			for(int i = 0;i<x.size()-1;i++) {
			if( ((Integer.parseInt(x.get(i).getText()) < ( Integer.parseInt(x.get(i+1).getText() ))  )) ) {
			return true;
			
			}}
			return false;}
		
		public boolean isAlphabeticalOrderOfTitless() {
			List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[5]"));
			boolean is = true;
		    for(int i = 0;i<x.size()-1;i++) {
		    	if(x.get(i).getText().compareToIgnoreCase(x.get(i+1).getText()) > 0 ) {
		    		is = false;
		    		break;}}
		    return is;	
		}
	   
		public boolean isAlphabeticalOrderOfAuthors() {
			List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[6]"));
			boolean is = true;
		    for(int i = 0;i<x.size()-1;i++) {
		    	if(x.get(i).getText().compareToIgnoreCase(x.get(i+1).getText()) > 0 ) {
		    		is = false;
		    		break;}}
		    return is;	
		}
		   
		public boolean isAlphabeticalOrderOfCategoriess() {
					List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[7]"));
					boolean is = true;
				    for(int i = 0;i<x.size()-1;i++) {
				    	if(x.get(i).getText().compareToIgnoreCase(x.get(i+1).getText()) > 0 ) {
				    		is = false;
				    		break;}}
				    return is;	
				}
	   
		
		public boolean isHronollogicalOrderOfDates2() {
			List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[11]"));

			
			boolean is = true;
			
		    for(int i = 0;i<x.size()-1;i++) {
		    	if(x.get(i).getText().compareTo(x.get(i+1).getText()) > 0 ) {
		    		is = false;
		    		break;}}
		    return is;	
		}
		                                              //disable
		    
	                                            
		 public String getStatusInTable(String name) {
			   return driver.findElement(By.xpath("//td[text()='"+name+"']//preceding-sibling::td[1]")).getText();
		     }
	   
	   
	   public void clickOnDisable(String name) throws InterruptedException {
		   WebElement n = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a[1]"));
		   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n );
		    // ((JavascriptExecutor)driver).executeScript("window.scrollBy(1000,0)");
		     Thread.sleep(500);
			  n.click();
			  Thread.sleep(500);
			  WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
			  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
			  Thread.sleep(500);
			  ((JavascriptExecutor)driver).executeScript("window.scrollBy(5000,0)");
			  Thread.sleep(500);
		  WebElement y = driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[12]//div[2]//button[1]"));
		  y.click();
	      Thread.sleep(500);} 
	   
		public void clickOnDisableFromDialogDisable() throws InterruptedException {
			WebElement x = driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-danger'])[2]"));
			x.click();
			Thread.sleep(1000);
		}
		public void clickOnCancelfromDialogDisable() {
			WebElement x = driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-danger'])[2]//preceding::button[1]"));
			x.click();
		}
		                                                //enable
		
		 public void clickOnEnable(String name) throws InterruptedException {
			 
			  WebElement n = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a[1]"));
			   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n );
			    // ((JavascriptExecutor)driver).executeScript("window.scrollBy(1000,0)");
			   Thread.sleep(1000);
				  n.click();
				  Thread.sleep(1000);
			 WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
				  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
				  Thread.sleep(1000);
				  ((JavascriptExecutor)driver).executeScript("window.scrollBy(5000,0)");
				  Thread.sleep(1000);
			  WebElement y = driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[12]//div[2]//button[1]"));
			  y.click();
		      Thread.sleep(1000);} 
			 
			 
		 public void clickOnEnableFromDialogEnable() throws InterruptedException {
				WebElement x = driver.findElement(By.xpath("//button[@type='submit'][@class='btn btn-success']"));
				x.click();
				Thread.sleep(1000);
			}
		public void clickOnCancelfromDialogEnable() {
				WebElement x = driver.findElement(By.xpath("//button[@type='submit'][@class='btn btn-success']//ancestor::div[1]//button[1]"));
				x.click();
			}
			
			                                           //important
		 public String getImpInTable(String name) {
			   return driver.findElement(By.xpath("//td[text()='"+name+"']//preceding-sibling::td[2]")).getText();
		     }
		 public void clickOnSetAsImportantPost(String name) throws InterruptedException {
			 WebElement n = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a[1]"));
			   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n );
			    // ((JavascriptExecutor)driver).executeScript("window.scrollBy(1000,0)");
			   Thread.sleep(1000);
				  n.click();
				  Thread.sleep(1000);
		     WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
				  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
				  Thread.sleep(1000);
				  ((JavascriptExecutor)driver).executeScript("window.scrollBy(5300,0)");
				  Thread.sleep(1000);
		     WebElement y = driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[12]//div[2]//button[2]"));
				  // ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
			y.click();
			 Thread.sleep(1000);}
		         
		 
         public void clickOnSetasImpFromDialog() throws InterruptedException {
        	 driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-success'])[2]")).click();
        	 Thread.sleep(1000);
         }
		
         public void clickOnCancelImporDialog() {
        	 driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-success'])[2]//preceding::button[1]")).click();}
         
		                                                //unimportant
         
         
		 public void clickOnSetAsUnimportantPost(String name) throws InterruptedException {
			 WebElement n = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a[1]"));
			   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n );
			    // ((JavascriptExecutor)driver).executeScript("window.scrollBy(1000,0)");
			   Thread.sleep(1000);
				  n.click();
				  Thread.sleep(1000);
			WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
			  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
			  Thread.sleep(1000);
			  ((JavascriptExecutor)driver).executeScript("window.scrollBy(5300,0)");
			  Thread.sleep(1000);
		    WebElement y = driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[12]//div[2]//button[2]"));
            y.click();
			      Thread.sleep(1000);}
			 
	         public void clickOnSetAsUnImpFromDialog() throws InterruptedException {
	        	 driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-danger'])[3]")).click();
	        	 Thread.sleep(1000);
	         }
	         public void clickOnCanceUnImportantDialog() {
	        	 driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-danger'])[3]//preceding::button[1]")).click();}
	         
	          //Prvi loc 1 od 1//@gi lokat 1 od  70brclan liste)

	 

	                                                       // TEXT POLja
	
	  public String getWithTagText() {
		  WebElement el = driver.findElement(By.xpath("//select[@name='tag_ids']"));
		  return el.getText();
	  }
	  
	 
	
	  public String getImportantText() {
		  WebElement dd = driver.findElement(By.xpath("//select[@name='important']"));
		  return dd.getText();
	  }
	  public String getStatusText() {
		  WebElement dd = driver.findElement(By.xpath("//select[@name='status']"));
		  return dd.getText();
	  }
	  
	  
	                                                 //SEARCH:
	  
	  public void insertQueryForSearch(String name) throws InterruptedException {
		  searchPost.clear();
		  searchPost.sendKeys(name);
		  //searchPost.sendKeys(Keys.ENTER);
		  Thread.sleep(1000);
		  }
	  public String getSearchText() {
		  return searchPost.getAttribute("value");
	  }
	  
	  public boolean isQuerySearchAmongSerNumbers(String query) {
          List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
          for(int i = 0;i<x.size();i++) {
        	  if(x.get(i).getText().contains(query))
        		  return true;
        	  }
        	  return false;
          }
	  public boolean isQuerySearchAmongTitles(String query) {
          List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[5]"));
          for(int i = 0;i<x.size();i++) {
        	  if(x.get(i).getText().contains(query))
        		  return true;
        	  }
        	  return false;
          }
	
	  
		public int HowManyNumContainsQuery(String query) {
			int m = 0;
			List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
	        for(int i = 0;i<x.size();i++) {
	      	  if(x.get(i).getText().contains(query)) {
	      		  m++;
	      	  }}
	      	  return m;
		}
		
		  
			public int HowManyTitlesContainsQuery(String query) {
				int m = 0;
				List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[5]"));
		        for(int i = 0;i<x.size();i++) {
		      	  if(x.get(i).getText().contains(query)) {
		      		  m++;
		      	  }}
		      	  return m;
			}
			
	         

	  public String getsearchText() {
		 return driver.findElement(By.xpath("(//input[@type='search'])[2]")).getText();
	  }
	 
			                                     //TABELaSADRZAJ POLJA IMP I STATUS
	  
        public int getSizeOfTable() {
				List<WebElement>tab = driver.findElements(By.xpath("//table[@id='entities-list-table']//tr"));
				return tab.size()-1;
			}
	
        public String getTextImportant() {
             WebElement i = driver.findElement(By.xpath("//span[@class='text-danger']"));
             return i.getText();
        }
        
        public String getTextStatus() {
        	WebElement i = driver.findElement(By.xpath("//span[@class='text-success']"));
        	 return i.getText();
        }
        
        
                                                      //pagin
  	  
         public void clickOnPrevious() {
        	 previous.click();}
         
        public int getPaginationSize() {
           List<WebElement> x = driver.findElements(By.xpath("//ul[@class='pagination']//li"));            
           return x.size();
        }
        
        public void clickOnNext() throws InterruptedException {
        	  WebElement x = driver.findElement(By.xpath("//ul[@class='pagination']//li[9]//a"));
        	  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
            	 Thread.sleep(500);
            	 x.click();
            	 Thread.sleep(1000);}
        	 
        
	     public String whichPageIsSelected() {
	    	 String z = "";
	    	 List<WebElement> x = driver.findElements(By.xpath("//ul[@class='pagination']//li//a")); 
	    	
	    	 for(int i = 0;i<x.size();i++) {
	    		 if(x.get(i).isSelected()){
	    			 z = x.get(i).getText();
	    			 
	    		 }
	    	 }
	    	return z;
	     }
	   
        

         public void goPaginatRight() {
      	   WebElement f = driver.findElement(By.xpath("//ul[@class='pagination']//li[2]"));
      	   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", f ); 
      	  // f.click();
             WebElement next = driver.findElement(By.xpath("//ul[@class='pagination']//li[7]"));
             ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", next );
             String dis = driver.findElement(By.xpath("//ul[@class='pagination']//li[7]")).getAttribute("class");
             while(!dis.contains("disabled")) {
             next.click();
         }

         }


       public void goPaginatLeft() {
      	WebElement last = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]"));
      	((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", last );
          last.click();
        WebElement prev = driver.findElement(By.xpath("//ul[@class='pagination']//li[1]"));
          ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", prev );
          String dis = driver.findElement(By.xpath("//ul[@class='pagination']//li[1]")).getAttribute("class");
          while(!dis.contains("disabled")) {
          prev.click();
         }

         }
    
       public boolean isNextDisplayed() {
        	 return   driver.findElement(By.xpath("//ul[@class='pagination']//li[7]")).isDisplayed();
         }
  	     
       public boolean isPreviousDisplayed() {
      	 return   driver.findElement(By.xpath("//ul[@class='pagination']//li[1]")).isDisplayed();
       }
	     
	    	 
	    
       public boolean isFirstPageDisplayed() {
           return   driver.findElement(By.xpath("//ul[@class='pagination']//li[2]")).isDisplayed();}
	     
	     
       public boolean isLastPageDisplayed() {
           return   driver.findElement(By.xpath("//ul[@class='pagination']//li[6]")).isDisplayed();}
	     
       public boolean isNextEnabled() {
      	 return   driver.findElement(By.xpath("//ul[@class='pagination']//li[7]")).isEnabled();
       }
	     
       public boolean isPreviousEnabled() {
      	 return   driver.findElement(By.xpath("//ul[@class='pagination']//li[1]")).isEnabled();
       }
       
       public void clickOnFirstPage() {
      	 WebElement x = driver.findElement(By.xpath("//ul[@class='pagination']//li[2]//a"));
      	 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
      	 x.click();}		
       public void clickOnLastPage() throws InterruptedException {
       	 WebElement x = driver.findElement(By.xpath("//ul[@class='pagination']//li[6]//a"));
       	 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
       	 Thread.sleep(500);
       	 x.click();
       	 Thread.sleep(1000);}
       
       public boolean isPageSelected(String num) throws InterruptedException {
      	 List<WebElement> l = driver.findElements(By.xpath("//ul[@class='pagination']//li//a")); 
      	 for(int i = 0;i<l.size();i++) {
      		 if(l.get(i).getText().equals(num) && l.get(i).isSelected() ) {
      			 Thread.sleep(1000);
      			 return true;
      		 }
      	 }
      	 return false;
       }
                                               
       public void clickOnPageNP(String x) throws InterruptedException {
    		 WebElement z = driver.findElement(By.xpath("//ul[@class='pagination']//li[2]//a"));
          	 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", z);
      	 List<WebElement> l = driver.findElements(By.xpath("//ul[@class='pagination']//li//a"));
      	 Thread.sleep(1000);
       	 
         for(int i = 0;i<l.size();i++) {
      		 if(l.get(i).getText().equals(x)) {
      			Thread.sleep(1000);
      			l.get(i).click();
      			Thread.sleep(1000);
      			
      		 }
      	 }}
        
       public String getAuthorName(String title) { 
    	   String k ="";
    	    boolean foundNum = false;
    		List<WebElement> x = driver.findElements(By.xpath("//td[text()='"+title+"']"));
    		for(int i = 0;i<x.size();i++) {
    			if(foundNum = false) {
    				driver.findElement(By.xpath("//ul[@class='pagination']//li[7]")).click();
    				return null;
    				
    			}
    			
    		  if(foundNum = true) {
    			k = driver.findElement(By.xpath("//td[text()='"+title+"']//following::td[1]")).getText();
    	}}
    	return k;
    }
    


                                                                         
    
    public int getTotalNumOfPostsInAllTable() {                                            
    	List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
    	List<String> y = new ArrayList<>();
    	for(WebElement m:x) {
    		y.add(m.getText());
    	}
    	String s =   driver.findElement(By.xpath("//ul[@class='pagination']//li[7]")).getAttribute("class");
    	while(!s.contains("disabled")) {
    		driver.findElement(By.xpath("//ul[@class='pagination']//li[7]")).click();
    	}
    	x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
    	for(WebElement m:x) {
    		y.add(m.getText());
    	}
    	int q = y.size();
    	
    	
    return q;	
    }
     
    public String getListOfPostsSerNumOnCurrPage() {
    	List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
    	List<String> y = new ArrayList<>();
    	for(WebElement m:x) {
    		y.add(m.getText());
    	}
    	return y.toString();
    }
                                                      //photo
public boolean isPhotoDisplayed(String name) {
return driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[2]//img")).isDisplayed();
}

public int getPhotoWidth(String name) {
return driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[2]//img")).getSize().getWidth();	 }


public int getPhotoHeight(String num) {
return driver.findElement(By.xpath("//td[text()='"+num+"']//ancestor::tr[1]//td[2]//img")).getSize().getHeight();	 }


public String getPhotoUrl(String num) {
return driver.findElement(By.xpath("//td[text()='"+num+"']//ancestor::tr[1]//td[2]//img")).getAttribute("src");	 }

public String getDescriptionOfPhoto(String name) {

String src = driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[2]//img")).getAttribute("src");
String y = src.substring(src.length()-13);
return y;                                             
}    

                //update posle
            public String getUpdatedImport(String name) {
            	return driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[3]")).getText();
            }
            public String getUpdatedTitle(String num) {
            	return driver.findElement(By.xpath("//td[text()='"+num+"']//ancestor::tr[1]//td[5]")).getText();
            }
            public String getUpdatedCategory(String name) {
            	return driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[7]")).getText();
            }
            
            public String getUpdatedWithTag(String name) {
            	return driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[8]")).getText();
            }
            public String getChangededStatus(String num) {
            	return driver.findElement(By.xpath("//td[text()='"+num+"']//ancestor::tr[1]//td[4]")).getText();
            }
            public String getChangedStatus(String name) {
            	return driver.findElement(By.xpath("//td[text()='"+name+"']//preceding::td[1]//span")).getText();
            }
          
            public String getAuthor(String title) { 
         	   String k ="";                                           
         	   boolean foundTit = false;
         		List<WebElement> x = driver.findElements(By.xpath("//td[text()='"+title+"']"));
         		for(int i = 0;i<x.size();i++) {
         			if(foundTit = false) {
         				driver.findElement(By.xpath("//ul[@class='pagination']//li[9]")).click();
         				return null;
         				
         			}
         			
         		  if(foundTit = true) {
         			k = driver.findElement(By.xpath("//td[text()='"+title+"']//following::td[1]")).getText();
         	}}
         	return k;                                  
         }
      
            
    public boolean isTabmassDisplayed() {
	      return tabmass.isDisplayed();
   }
    public String getTabSearchText() {
	      return tabmass.getText();
  } 
        
  }
		  
	

