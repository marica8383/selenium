package project.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cubes.main.URLConst;
import cubes.main.Utils;

public class AddPostPage {
       private WebDriver driver;
       
       @FindBy(xpath="//select[@name='post_category_id']")
       private WebElement weCategory;
	   @FindBy(xpath="//input[@type='text']")
	   private WebElement weTitle;
	   @FindBy(xpath="//textarea[@name='description']")
	   private WebElement weDescription;
	   @FindBy(xpath="//label[@for='set-as-unimportant']")
	   private WebElement weImpNo;
	   @FindBy(xpath="//label[@for='set-as-important']")
	   private WebElement weImpYes;
	   @FindBy(xpath="//input[@value='0']")
	   private WebElement weNo;
	   @FindBy(xpath="//input[@value='1']")
	   private WebElement weYes;
	   
	 
	   //   FILE
	   
	   @FindBy( xpath="//input[@type='file']")
	   private WebElement chooseFile;
	   @FindBy(xpath="//textarea[@name='content']")
	   private WebElement weContent;
	  
	                                                 
	   
	                                                  //ERRORS
	   @FindBy(xpath="//span[@id='title-error']")
	   private WebElement weTitleError;
	   @FindBy(xpath="//span[@id='description-error']")
	   private WebElement weDescriptionError;                      
	   @FindBy(xpath="//span[@id='tag_id[]-error']")           
       private WebElement weChechTagError;                      
	   @FindBy(xpath="//div[@class='invalid-feedback']")        
	   private WebElement contentError;
	
	
	public AddPostPage(WebDriver driver, boolean openPage) {
		this.driver = driver;
		this.driver.manage().window().maximize();
		if(openPage) {
			this.driver.get(URLConst.POST_ADD);
		}
		PageFactory.initElements(driver, this);
	}
	                                           
	
	
	                                              //UPLOAD 
	public void clickOnHome() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Home']"));
		x.click();		
	}
	public void clickOnPost() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Post']"));
		x.click();		
	}
     public void uploadFile() {
    	 chooseFile.sendKeys("D:\\Desktop\\pictures\\Capture9.png");
    	 
     }
     public void uploadFile1() {
    	 chooseFile.sendKeys("D:\\Desktop\\1.gif");
    	 
     }
	  
     public void uploadFile2() {
    	 chooseFile.sendKeys("D:\\Desktop\\2.jpg");
    	 
     }
     public void uploadFile3() {
    	 chooseFile.sendKeys("D:\\Desktop\\pictures\\phototxt.txt");
    	 
     }
	public void  clickOnChooseCat() {
		weCategory.click();
		
	}
	public void clickOnCatOption(String opt) {
		List<WebElement>options = driver.findElements(By.xpath("//select[@name='post_category_id']//option"));
		for(int i = 0;i < options.size();i++) {
			if (options.get(i).getText().contains(opt)) {
				options.get(i).click();
			}
		}
		
	}
	
	                                              //BROJ CLAN LISTE CATEGORY
	
	public int getSizeCatOpt() {
		List<WebElement>options = driver.findElements(By.xpath("//select[@name='post_category_id']//option"));
		return options.size();
	}
	                                               //CATEGORY
	                                             //BROJ SELEKtov.uvek 1 nije multisel
	public int getNumofSelInCategory() {
		List<WebElement>options = driver.findElements(By.xpath("//select[@name='post_category_id']//option"));
		int m = 0;
		for(int i =0;i<options.size();i++) {
			if(options.get(i).isSelected()) {
				m++;
			}
			
		}
		return m;
	}
	                                      // KOJI JE SELEKTOVAN u select.  DA
	
	public String getNameSelOptCategory(int n) {

		WebElement dd = driver.findElement(By.xpath("//select[@name='post_category_id']"));
		Select sel = new Select(dd);
		sel.selectByIndex(n);
		String st = sel.getFirstSelectedOption().getText();
		
	return st;	
	}                                               
	public String getNameSelOptCategory() {
		String x = "";
		List<WebElement>op = driver.findElements(By.xpath("//select[@name='post_category_id']//option"));
		
		for(int i =0;i<op.size();i++) {
			if(op.get(i).isSelected()) {
				 x = op.get(i).getText();
			}
		
	}
	return x;	
  }	
	
	                                                   //UNESI TEXT
	public void insertTitle(String title) {
		 weTitle.clear();
		 weTitle.sendKeys(title);
	}
	public void insertPostDesc(String desc) {
		 weDescription.clear();
		 weDescription.sendKeys(desc);
	}                                          
	             //Content nije displayed.remove attribute style
	           //METODA  style:vis hidden;display none;//HIDDEN   
	
	public void insertContent(String cont) throws InterruptedException {
		
		WebElement el = driver.findElement(By.xpath("//textarea[@name='content']"));
		 ((JavascriptExecutor)driver).executeScript("arguments[0].removeAttribute('style');", el);
		     
		 el.sendKeys(cont);
		 Thread.sleep(2000);
	}
	
	                              //= LABELAsamo zaklikovde     
	                            
	
	public void clickOnYes()  {
		// WebDriverWait wait = new WebDriverWait(driver,Duration.ofMillis(500));
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='1']")));
		weYes.click();
	}
	 public void clickOnNo() {
		weNo.click();
	}
	 public void clickOnImpYes()  {
		 weImpYes.click();
		}
	 public void clickOnImpNo() {
		 weImpNo.click();
	 }
	                                                    //GETSIZE RADIolis 
	 
	 public int getRadioListSize() {
		 List<WebElement>chboxList = driver.findElements(By.xpath("//input[@type='radio']"));
		 return chboxList.size();
	 }
	 
	
	                                                    // UVEK1sELEKTOVAN
	 
	 public int getNumbOfSelInRadioList() {
		 List<WebElement>list = driver.findElements(By.xpath("//input[@type='radio']"));
		 int m = 0;
		 for(int i = 0;i<list.size();i++) {
			 if(list.get(i).isSelected()) {
				 m++;
			 }
		 }
		 return m;
	 }   
	                                                  /// GET LABELA IME(LIsta stringova o lista
	 public String getLabelRadioName() {               //i ubaci u listu stringova
	 	    String r = "";
	 	   
	 	    List<WebElement> list = driver.findElements(By.xpath("//input[@type='radio']"));
	 	   
				
	 	   for(int i =0;i<list.size();i++) {
				if(list.get(i).isSelected()) {
			 
				 r = driver.findElement(By.xpath("//input[@type='radio']//following::label[1]")).getText();
				
			}}
			return r;	   
	 	        	   
	 	   } 	           
	                                                         //CHECKBOX
	        
	 public boolean isChboxSelected() {
	 
	           WebElement x = driver.findElement(By.xpath("//input[@id='tag-checkbox-8085']"));
	            return x.isSelected();
	 }                                                     
	     //CHECKiraj 1 preko labele tjimena taga= NA JEDNO IME CHbox
		//CHECKBOX ALL; na  SVE kocke=inp type ch 1 od kraja npr to lista
	 
	 public void clickOnCheckBoxLabelTagname(String tagname) {
			WebElement checkBoxTag = driver.findElement(By.xpath("//label[text()='"+tagname+"']"));
			checkBoxTag.click();
		}
	 
	 public void selectAllChBoxes() {
		 List<WebElement>chboxList = driver.findElements(By.xpath("//input[@type='checkbox']"));
		 for(int i = 0;i<chboxList.size();i++) {
			 chboxList.get(i).click();
		 }
	 }
	 
	                                       //SIZE CHEXK LISTE
	 public int getCheckboxListSize() {
		 List<WebElement>chboxList = driver.findElements(By.xpath("//input[@type='checkbox']"));
		 return chboxList.size();
	 }
	 
	                                      //BROJ SELEK UcHboxLISTI 1/vise
	 public int getNumbOfSelInCheckboxList() {
		 List<WebElement>chboxList = driver.findElements(By.xpath("//input[@type='checkbox']"));
		 int m = 0;
		 for(int i = 0;i<chboxList.size();i++) {
			 if(chboxList.get(i).isSelected()) {
				 m++;
			 }
		 }
		 return m;
	 }                                       // LABEPRATI1SELE CHEC
	 public String getLabelCheckboxName() {
 	    String l = "";
 	   
 	    List<WebElement> list = driver.findElements(By.xpath("//input[@type='checkbox']"));
 	   
			
			for(int i =0;i<list.size();i++) {
				if(list.get(i).isSelected()) {
				l = driver.findElement(By.xpath("//input[@type='checkbox']//following::label")).getText();	
				}
			
		}
		return l;	   
 	        	   
 	           }                                                         
	 
	                    
	                                            //prvi2x
	  public String getNamesbOfSelInCheckboxList() {               	 
	      String m ="";
		 List<WebElement>l = driver.findElements(By.xpath("//input[@type='checkbox']"));
		 List<String> st = new ArrayList<String>();
		 
		 for(int i = 0;i<l.size();i++) {
			 if(l.get(i).isSelected()) {
				 m = driver.findElement(By.xpath("//input[@type='checkbox']//following::label[1]")).getText();
			     st.add(m);	 
		 }}
		 return st.toString();}
	 

	 
	 
	                                 // SVE2 xPONAVLJ iz doma

	 
	  public List<String>  getListStringCHEC(){
		
		    List<String> text = new ArrayList<String>();
		    
	        List<WebElement> list =  driver.findElements(By.xpath("//input[@type='checkbox']"));
	          for(int i =0;i<list.size();i++) {
	    	   	if(list.get(i).isSelected()) {
	    	   	    List<WebElement> o = driver.findElements(By.xpath("//input[@type='checkbox']//following::label[1]"));
			              for(WebElement el:o) {
			        	   text.add(el.getText());}
	    	   		
				  
				 }}
		return text;}
	  
	     	                               //  ok index1
	  public int getIndexOfSelectedCh() {
		  List<WebElement> l =  driver.findElements(By.xpath("//input[@type='checkbox']"));
		     int n = 0;
		  for(int i= 0;i<l.size();i++) {
			  if(l.get(i).isSelected()) {
				  n = i+1;}
			  }
		  return n;
		  }  
	  
	  
	  public String getIndexOfSelTags() {      // okINDEXEi(i+1) VISE cekIRANIH
		  int x = 0;
		  List<WebElement> l =  driver.findElements(By.xpath("//input[@type='checkbox']"));
		  List<Integer> n = new ArrayList<>();
		     for(int i= 0;i<l.size();i++) {
			     if(l.get(i).isSelected()) {
			    	  x = i+1;
			    	  n.add(x);
			     }}
	  
	  
	  return n.toString();
	  
	  
	  }  
	  
	 
	    
	                             /// DELETE PHOTO SCROLL
	                            //scroll levoprvi-;gore drugi-/desno prvi+,dole drugi +//
	    
	  public void clickOnChooseFile() {
		 chooseFile.click();
	 }
	   public void clickOnDeletePhoto() throws InterruptedException {
		   ((JavascriptExecutor)driver).executeScript("window.scrollBy(2000,0)");
			 Thread.sleep(2000);
			 WebElement e = driver.findElement(By.xpath("//button[@data-action='delete-photo']"));
			 e.click();  	 
	      ((JavascriptExecutor)driver).executeScript("window.scrollBy(-2000,0)");  
			  
	
		   
	   }
	public void clickOnContent() {
		 weContent.click();                                     
	}  
	                                          //CLICK ON SAVE                     
	
	public void clickOnSave() throws InterruptedException  {
		WebElement s = driver.findElement(By.xpath("//button[@type='submit']"));
		//((JavascriptExecutor)driver).executeScript("window.scrollBy(0,+3000)");
		Utils.scrollToElement(driver, s);
		 //((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", s );
		Thread.sleep(500);
		// WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Save']")));
	   s.click();
	
	}
	
	public void clickOnCancel() throws InterruptedException {
		WebElement s = driver.findElement(By.xpath("//a[text()='Cancel']"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", s );
		//Utils.scrollToElement(driver, s);
		Thread.sleep(1000);
		    //WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
			//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Cancel']")));
		s.click();
		// Thread.sleep(1000);
		 
	}
	                                          // ERRORI IS i GET
	
	//GRESKE 3 + 2(=sa prve 2 locatori)
	public boolean isTitleErrorDisplayed() {
		return weTitleError.isDisplayed();
	}
	public boolean isDescriptionErrorDisplayed() {
		return weDescriptionError.isDisplayed();
	}
	public boolean isTagErrorDisplayed() {
		return  weChechTagError.isDisplayed();
	}
	
	public boolean isContentErrorDisplayed() {
		return  contentError.isDisplayed();
	}
	 public String getTitleErrorText()  {
		 return  weTitleError.getText();
	 }
	 public String getDescrErrorText() {
		 return  weDescriptionError.getText();
	 }
	 public String getTagErrorText() {
		 return weChechTagError.getText();
	 }
	 public String getContentErrorText() {
		 return contentError.getText();
	 }
	 
	                                              //TEXT U POLJU
	 
	public String getCategoryText() {
		return weCategory.getText();
	}
	 public String getTitleText() {
		 return weTitle.getAttribute("value");
	 }
	 public String getDesripionText() {
		 return weDescription.getAttribute("value");
	 } 
	 
           
            	  //BOOLEANi rad
	
	 public boolean isYesSelected() {
		 return weYes.isSelected();
	 }
		 
	 public boolean isNoSelected() {
		 return weNo.isSelected();
	 } 
	 
	 public boolean isYesDisplayed() {
		 return weYes.isDisplayed();
	 }
	 public boolean isNoDisplayed() {
		 return weNo.isDisplayed();
	 }
	                                                       
	                                        
                                                   
 
	                                                             //photo
	 public boolean isPhotoDisplayed(String n) {
	 return driver.findElement(By.xpath("//img[@alt='"+n+"']")).isDisplayed();
	 }

	 public int getPhotoWidth(String n) {
	 return driver.findElement(By.xpath("//img[@alt='"+n+"']")).getSize().getWidth();	 }


	 public int getPhotoHeight(String n) {
	 return driver.findElement(By.xpath("//img[@alt='"+n+"']")).getSize().getHeight();	 }


	 public String getPhotoUrl(String n) {
	 return driver.findElement(By.xpath("//img[@alt='"+n+"']")).getAttribute("src");	 }

	 public String getDescriptionOfPhoto(String n) {

	 String src = driver.findElement(By.xpath("//img[@alt='"+n+"']")).getAttribute("src");
	 String y = src.substring(10);
	 return y;                                             
	 }      
	      
	 
	
	 
	
	 
	 
	 
	 
	 
	 }
	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 

