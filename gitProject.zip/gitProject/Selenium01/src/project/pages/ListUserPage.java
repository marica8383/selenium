package project.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import cubes.main.URLConst;

import java.util.ArrayList;
import java.util.Date;

public class ListUserPage {

	private WebDriver driver;
	
	
	
	public ListUserPage(WebDriver driver) {
		this.driver = driver;
		//this.driver.manage().window().maximize();
		//this.driver.get(URLConst.USER_LIST);
		PageFactory.initElements(driver,this);
	}
	
	public void openPage() {
		this.driver.get(URLConst.USER_LIST);
	}
	public void clickOnHome() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Home']"));
		x.click();
	}
	
	public void clickOnAddNewUser() {
		WebElement x = driver.findElement(By.xpath("//a[@class='btn btn-success']"));
		x.click();
	}
	
	
	
	public int countUsersWithName(String name) throws InterruptedException {
	      WebElement x = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
		 Thread.sleep(1000);
	      x.click();
	      Thread.sleep(1000);
		List<WebElement> l = driver.findElements(By.xpath("//td[text()='"+name+"']"));
		return l.size();
	}
	public boolean isUserInList(String name) {
		List<WebElement> x = driver.findElements(By.xpath("//td[text()='"+name+"']"));
		return x.size()>0;
	}
	public String getUsersWithNameInList(String name) {
		return driver.findElements(By.xpath("//td[text()='"+name+"']")).toString();
	}
	
	
	
	public void clickOnStatusArrow() {
		WebElement x = driver.findElement(By.xpath("//select[@name='status']"));
		x.click();
	}
	
	public void clickOnEnable() {
		WebElement x = driver.findElement(By.xpath("//select[@name='status']//option[2]"));
		x.click();
	}
	public boolean isEnabledSelected() {
		WebElement x = driver.findElement(By.xpath("//select[@name='status']//option[2]"));
		return x.isSelected();
	}
	public boolean isEnableInAllFieldsCurrentTablePage() {
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[2]//span"));
	      for(int i=0;i<x.size();i++) {
	         if(x.get(i).getText().equalsIgnoreCase("enabled")) {
	        		  return true;
	        	  }}
	         return false;
	          }
	
	
	
	public void clickOnDisable() {
		WebElement x = driver.findElement(By.xpath("//select[@name='status']//option[3]"));
		x.click();
	}
	
	public boolean isDisableSelected() {
		WebElement x = driver.findElement(By.xpath("//select[@name='status']//option[3]"));
		return x.isSelected();
	}
	
	
	public boolean isDisableInAllFieldsCurrentTablePage() {
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[2]//span"));
	      for(int i=0;i<x.size();i++) {
	         if(x.get(i).getText().equalsIgnoreCase("disabled")) {
	        	 return true;
	        	  }}
	        return false;
	          }
	public boolean isAllStatusSelected() {
		WebElement x = driver.findElement(By.xpath("//select[@name='status']//option[1]"));
		return x.isSelected();
	}
	
	
	
	                                 // enter
	
	public boolean isNoFoundDisplayed() {
		return driver.findElement(By.xpath("//td[@class='dataTables_empty']")).isDisplayed();
	}
	public String getNoFundText() {
		return driver.findElement(By.xpath("//td[@class='dataTables_empty']")).getText();
	}
	public void enterEmail(String name) throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//input[@name='email']"));
		x.clear();
		x.sendKeys(name);
		Thread.sleep(1000);
	}
	public boolean isEnteredMailInTable(String mail) {
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[4]"));
		for(int i = 0;i<x.size();i++) {
			if(x.get(i).getText().contains(mail)) {
				return true;
			}
		}
		return false;
	}
	
	
	public void enterName(String name) throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//input[@name='name']"));
		x.clear();
		x.sendKeys(name);
		Thread.sleep(1000);
	}
	
	public boolean isEnteredNameInTable(String name) {
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[5]"));
		for(int i = 0;i<x.size();i++) {
			if(x.get(i).getText().equalsIgnoreCase(name)) {
				return true;
			}
		}
		return false;
	}
	
	public void enterPhone(String name) throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//input[@name='phone']"));
		x.clear();
		x.sendKeys(name);
		Thread.sleep(1000);
	}
	
	public boolean isEnteredPhoneInTable(String name) {
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[6]"));
		for(int i = 0;i<x.size();i++) {
			if(x.get(i).getText().contains(name)) {
				return true;
			}
		}
		return false;
	}
	                                           
	
	public void clickOnShowEntries() {
		WebElement x = driver.findElement(By.xpath("//select[@name='entities-list-table_length']"));
		x.click();
	}
	public void clickOnShow5() {
		WebElement x = driver.findElement(By.xpath("//select[@name='entities-list-table_length']//option[1]"));
		x.click();
	}
	
	public void clickOnShow10() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//select[@name='entities-list-table_length']//option[2]"));
		x.click();
		Thread.sleep(1000);
	}
	public void clickOnShow15() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//select[@name='entities-list-table_length']//option[3]"));
		x.click();
		Thread.sleep(1000);
	}
	public boolean isFiveSelected() {
		return driver.findElement(By.xpath("//select[@name='entities-list-table_length']//option[1]")).isSelected();
	}
	
	public boolean isTenSelected() {
		return driver.findElement(By.xpath("//select[@name='entities-list-table_length']//option[2]")).isSelected();
	}
	
	public boolean isFifteenSelected() {
		return driver.findElement(By.xpath("//select[@name='entities-list-table_length']//option[3]")).isSelected();
	}
	
	
	
	
	public void enterQueryInSearch(String name) throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//input[@type='search']"));
		x.clear();
		x.sendKeys(name);
		Thread.sleep(1000);
	}
	public boolean isQuerySearchAmongNumbers(String query) {
	          List<WebElement> x = driver.findElements(By.xpath("//td[@class='sorting_1']"));
	          for(int i = 0;i<x.size();i++) {
	        	  if(x.get(i).getText().contains(query))
	        		  return true;
	        	  }
	        	  return false;
	          }
	
	public boolean isQuerySearchAmongEmails(String query) {
        List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[4]"));
        for(int i = 0;i<x.size();i++) {
      	  if(x.get(i).getText().contains(query))
      		  return true;
      	  }
      	  return false;
        }
	public boolean isQuerySearchAmongNames(String query) {
        List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[5]"));
        for(int i = 0;i<x.size();i++) {
      	  if(x.get(i).getText().contains(query))
      		  return true;
      	  }
      	  return false;
        }
	
	public boolean isQuerySearchAmongPhones(String query) {
        List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[6]"));
        for(int i = 0;i<x.size();i++) {
      	  if(x.get(i).getText().contains(query))
      		  return true;
      	  }
      	  return false;
        }
	
	
	public int HowManyNumContainsQuery(String query) {
		int m = 0;
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
        for(int i = 0;i<x.size();i++) {
      	  if(x.get(i).getText().contains(query)) {
      		  m++;
      	  }}
      	  return m;
	}
	
	
	public int HowManyMailsContainsQuery(String query) {
		int m = 0;
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[4]"));
        for(int i = 0;i<x.size();i++) {
      	  if(x.get(i).getText().contains(query)) {
      		  m++;
      	  }}
      	  return m;
	}
	public int HowManyNamesContainsQuery(String query) {
		int m = 0;
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[5]"));
        for(int i = 0;i<x.size();i++) {
      	  if(x.get(i).getText().contains(query)) {
      		  m++;
      	  }}
      	  return m;
	}
	
	
	public int HowManyPhonesContainsQuery(String query) {
		int m = 0;
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[6]"));
        for(int i = 0;i<x.size();i++) {
      	  if(x.get(i).getText().contains(query)) {
      		  m++;
      	  }}
      	  return m;
	}
	
	                                                       //sort
	
	public void clickOnSortByNumber() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//th[@class='sorting_asc']"));
		x.click();
		Thread.sleep(1000);
	}
	public boolean isAscOrderOfSerNumbers() {

		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
		
		for(int i = 0;i<x.size()-1;i++) {
		if( ((Integer.parseInt(x.get(i).getText()) < ( Integer.parseInt(x.get(i+1).getText() ))  )) ) {
		return true;
		
		}}
		return false;}
	
	
	
	
	public void clickOnSortByEmail() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//th[@class='sorting_asc']//following-sibling::th[3]"));
		x.click();
		Thread.sleep(1000);
	}
	public boolean isAlphabeticalOrderOfEmails() {
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[4]"));
		boolean is = true;
	    for(int i = 0;i<x.size()-1;i++) {
	    	if(x.get(i).getText().compareToIgnoreCase(x.get(i+1).getText()) > 0 ) {
	    		is = false;
	    		break;}}
	    return is;	
	}
		
	
	
		public void clickOnSortByName() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//th[@class='sorting_asc']//following-sibling::th[4]"));
		x.click();
		Thread.sleep(1000);     
	}                                                           
	
		
		public boolean isAlphabeticalOrderOfNames() {
			List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[5]"));
			boolean is = true;
		    for(int i = 0;i<x.size()-1;i++) {
		    	if(x.get(i).getText().compareToIgnoreCase(x.get(i+1).getText()) > 0 ) {
		    		is = false;
		    		break;}}
		    return is;	
		}
		
		
	public void clickOnSortByDate() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//th[@class='sorting_asc']//following-sibling::th[6]"));
		x.click();
		Thread.sleep(1000);
	}
	public boolean isHronollogicalOrderOfDates() {
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[7]"));
		boolean is = true;
		
	    for(int i = 1;i<x.size();i++) {
	    	if( ((Date) x.get(i)).before((Date) x.get(i-1))) {
	    		is = false;                                               
	    		break;}}                                               
	    return is;	
	}
	
	public boolean isHronollogicalOrderOfDates2() {
		List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[7]"));

		boolean is = true;
		
	    for(int i = 0;i<x.size()-1;i++) {
	    	if(x.get(i).getText().compareTo(x.get(i+1).getText()) > 0 ) {
	    		is = false;
	    		break;}}
	    return is;	
	}
	     
	  
	  public void clickOnUpdateUser(String name) throws InterruptedException {
		  WebElement n = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a[1]"));
		  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n);
		  Thread.sleep(500);
		  n.click();
		  Thread.sleep(500);
		  WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
		  WebElement updateButton = driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[8]//a[2]"));
		  
		  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
		 Thread.sleep(500);
		  ((JavascriptExecutor)driver).executeScript("window.scrollBy(3000,0)");
		  Thread.sleep(500);
		  //Utils.scrollToElement(driver,  updateButton);
		  updateButton.click();
		  
	  }
	
	  public void clickOnEnableUser(String name) throws InterruptedException {
		  WebElement n = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a[1]"));
		  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n);
		  Thread.sleep(1000);
		  n.click();
		  Thread.sleep(1000);
		  WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
		  WebElement y = driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[8]//button[1]"));
		  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
		  Thread.sleep(1000);
		  ((JavascriptExecutor)driver).executeScript("window.scrollBy(3000,0)");
		  Thread.sleep(1000);
			
		 y.click();
		 Thread.sleep(1000);
		}
		public void clickOnEnableFromDialogEnable() throws InterruptedException {
			WebElement x = driver.findElement(By.xpath("//button[@type='submit'][@class='btn btn-success']"));
			x.click();
			Thread.sleep(500);
		}
		public void clickOnCancelfromDialogEnable() {
			WebElement x = driver.findElement(By.xpath("//button[@type='submit'][@class='btn btn-success']//ancestor::div[1]//button[1]"));
			x.click();
		}
		

		public void clickOnDisableUser(String name) throws InterruptedException {
			  WebElement n = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a[1]"));
			  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", n);
			  Thread.sleep(1000);
			  n.click();
			  Thread.sleep(1000);
			WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
			WebElement y = driver.findElement(By.xpath("//td[text()='"+name+"']//ancestor::tr[1]//td[8]//button[1]"));
			//WebElement y = driver.findElement(By.xpath("//form[@id='disable-modal']"));
			//((JavascriptExecutor)driver).executeScript("arguments[0].removeAttribute('style');", y);
			//((JavascriptExecutor)driver).executeScript("arguments[0].removeAttribute('arria-hidden');", y);
			
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
			 Thread.sleep(1000);  
			// ((JavascriptExecutor)driver).executeScript("window.scrollBy(3000,0)");
			 Thread.sleep(1000);  
		 y.click();
		 Thread.sleep(1000);
		}
		
		public void clickOnDisableFromDialogDisable() throws InterruptedException {
			WebElement x = driver.findElement(By.xpath("//button[@type='submit'][@class='btn btn-danger']"));
			x.click();
			Thread.sleep(1000);
		}
		public void clickOnCancelfromDialogDisable() {
			WebElement x = driver.findElement(By.xpath("//button[@type='submit'][@class='btn btn-danger']//preceding::button[1]"));
			x.click();
		}

		public void clickOnEye(String name) throws InterruptedException {
			WebElement x = driver.findElement(By.xpath("//td[text()='"+name+"']"));
			WebElement y = driver.findElement(By.xpath("//td[text()='"+name+"']//following-sibling::td[3]//a[1]"));
			
		      ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
			  Thread.sleep(500);
			  ((JavascriptExecutor)driver).executeScript("window.scrollBy(3000,0)");
			  Thread.sleep(500);
		   y.click();
		}
	  

		
	                                                    //photo
	     public boolean isPhotoDisplayed(String num) {
	      return driver.findElement(By.xpath("//td[text()='"+num+"']//ancestor::tr[1]//td[3]//img")).isDisplayed();
	  }

	      public int getPhotoWidth(String num) {
	       return driver.findElement(By.xpath("//td[text()='"+num+"']//ancestor::tr[1]//td[3]//img")).getSize().getWidth();	 }


	      public int getPhotoHeight(String num) {
	        return driver.findElement(By.xpath("//td[text()='"+num+"']//ancestor::tr[1]//td[3]//img")).getSize().getHeight();	 }


	     public String getPhotoUrl(String num) {
	      return driver.findElement(By.xpath("//td[text()='"+num+"']//ancestor::tr[1]//td[3]//img")).getAttribute("src");	 }

	     public String getDescriptionOfPhoto(String num) {
	     
	     String src = driver.findElement(By.xpath("//td[text()='"+num+"']//ancestor::tr[1]//td[3]//img")).getAttribute("src");
	     String y = src.substring(13);
	     return y;                                             
	     }        
		
	     //                                                 getfromtabl
	     public String getStatusFromTable(String num) {
			   return driver.findElement(By.xpath("//td[text()='"+num+"']//following-sibling::td[1]")).getText();
		     }
	     
	     public String getMailFromTable(String num) {
		   return driver.findElement(By.xpath("//td[text()='"+num+"']//following-sibling::td[3]")).getText();
	     }
	
	     public String getNameFromTable(String num) {
			   return driver.findElement(By.xpath("//td[text()='"+num+"']//following-sibling::td[4]")).getText();
		     }
	     
	     public String getPhoneFromTable(String name) {
			   return driver.findElement(By.xpath("//td[text()='"+name+"']//following-sibling::td[1]")).getText();
		     }
	     
	    
	     public String getStatusInTable(String name) {
			   return driver.findElement(By.xpath("//td[text()='"+name+"']//preceding-sibling::td[3]")).getText();
		     }
	     
	     
                                                   //pagin
	 	
           public void goPaginatRight() {
        	   WebElement f = driver.findElement(By.xpath("//ul[@class='pagination']//li[2]"));
        	   ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", f ); 
        	  // f.click();
               WebElement next = driver.findElement(By.xpath("//ul[@class='pagination']//li[9]"));
               ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", next );
               String dis = driver.findElement(By.xpath("//ul[@class='pagination']//li[9]")).getAttribute("class");
               while(!dis.contains("disabled")) {
               next.click();
           }

           }


         public void goPaginatLeft() {
        	WebElement last = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]"));
        	((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", last );
            last.click();
            WebElement prev = driver.findElement(By.xpath("//ul[@class='pagination']//li[1]"));
            ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", prev );
            String dis = driver.findElement(By.xpath("//ul[@class='pagination']//li[1]")).getAttribute("class");
            while(!dis.contains("disabled")) {
            prev.click();
           }

           }
      

         public int getPaginationSize() {
            WebElement x = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a"));            
            return Integer.parseInt(x.getText());
         }

        public int getCurrPageTableSize() {
          List<WebElement> x = driver.findElements(By.xpath("//td[@class='sorting_1']"));              
          return x.size();
       }
	     
        
	  
	     public boolean isFirstPageDisplayed() {
             return   driver.findElement(By.xpath("//ul[@class='pagination']//li[2]")).isDisplayed();}
	     
	     
         public boolean isLastPageDisplayed() {
             return   driver.findElement(By.xpath("//ul[@class='pagination']//li[8]")).isDisplayed();}
	     
         public boolean isNextEnabled() {
        	 return   driver.findElement(By.xpath("//ul[@class='pagination']//li[9]")).isEnabled();
         }
	     
         public boolean isPreviousEnabled() {
        	 return   driver.findElement(By.xpath("//ul[@class='pagination']//li[1]")).isEnabled();
         }
         
         public void clickOnFirstPage() throws InterruptedException {
        	 WebElement x = driver.findElement(By.xpath("//ul[@class='pagination']//li[2]//a"));
        	 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
        	 Thread.sleep(500);
        	 x.click();}		
         public void clickOnLastPage() throws InterruptedException {
         	 WebElement x = driver.findElement(By.xpath("//ul[@class='pagination']//li[8]//a"));
         	 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
         	 Thread.sleep(500);
         	 
         	 x.click();}
        
           
         
         public String whichPageIsSelected() {
	    	 String z = "";
	    	 List<WebElement> x = driver.findElements(By.xpath("//ul[@class='pagination']//li//a")); 
	    	
	    	 for(int i = 0;i<x.size();i++) {
	    		 if(x.get(i).isSelected()){
	    			 z = x.get(i).getText();
	    			 
	    		 }
	    	 }
	    	return z;
	     }
	   
         public boolean isPageSelected(String x) {
        	 List<WebElement> l = driver.findElements(By.xpath("//ul[@class='pagination']//li//a")); 
        	 for(int i = 1;i<l.size()-1;i++) {
        		 if(l.get(i).getText() == x && l.get(i).isDisplayed() ) {
        			 return true;
        		 }
        	 }
        	 return false;
         }
                                                  
         public void clickOnPageNP(String x) {
        	 List<WebElement> l = driver.findElements(By.xpath("//ul[@class='pagination']//li//a"));
        	 WebElement f = driver.findElement(By.xpath("//ul[@class='pagination']//li[1]//a"));
        	 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", f);
   		    
   		 
        	 for(int i = 0;i<l.size();i++) {
        		 if(l.get(i).getText().contains(x)) {
        			l.get(i).click();
        			
        		 }
        	 }}
        	                                      
        public String getUserName(String num) { 
        	   String k ="";                                      //found number then get user
        	   boolean foundNum = false;
        		List<WebElement> x = driver.findElements(By.xpath("//td[text()='"+num+"']"));
        		for(int i = 0;i<x.size();i++) {
        			if(foundNum = false) {
        				driver.findElement(By.xpath("//ul[@class='pagination']//li[9]")).click();
        				return null;
        				
        			}
        			
        		  if(foundNum = true) {
        			k = driver.findElement(By.xpath("//td[text()='"+num+"']//following-sibling::td[4]")).getText();
        	}}
        	return k;
        }
        
  

                                                                             
        
        public int getTotalNumOfUsersInAllTable() throws InterruptedException {                                            //check
        	List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
        	List<String> y = new ArrayList<>();
        	for(WebElement m:x) {
        		y.add(m.getText());
        	}
        	
            WebElement p = driver.findElement(By.xpath("//ul[@class='pagination']//li[9]"));
        	String s =   driver.findElement(By.xpath("//ul[@class='pagination']//li[9]")).getAttribute("class");
        	 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", p);
   		     Thread.sleep(1000);
        	while(!s.contains("disabled")) {
        		driver.findElement(By.xpath("//ul[@class='pagination']//li[9]")).click();
        	}
        	x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
        	for(WebElement m:x) {
        		y.add(m.getText());
        	}
        	int q = y.size();
        	
        	
        return q;	
        }
         
        public String getListOfUserSerNumOnCurrPage() {
        	List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//td[1]"));
        	List<String> y = new ArrayList<>();
        	for(WebElement m:x) {
        		y.add(m.getText());
        	}
        	return y.toString();
        }
         
         
         
}       
         
	   
