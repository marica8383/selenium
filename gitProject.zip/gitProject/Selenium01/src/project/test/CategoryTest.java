package project.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;

import cubes.MyWebDriver;
import cubes.main.URLConst;
import cubes.main.Utils;
import cubes.pages.AddTagPage;
import cubes.pages.LoginPage;
import project.pages.AddCategoryPage;
import project.pages.AddPostPage;
import project.pages.ListCategoryPage;
import project.pages.ListPostPage;

class CategoryTest {
     private static WebDriver driver;
     
     private static String  tempCatName;
     private static String  descName;
     private static String  updatedName;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		driver= MyWebDriver.getInstance().getDriver("chrome");
		//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("name")));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		LoginPage loginPage = new LoginPage(driver);
	    loginPage.loginSuccess();
	 
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		driver.close();
	}

	@BeforeEach
	void setUp() throws Exception {
		driver.get(URLConst.CATEGORY_LIST);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	
	@Test                      
	void tc01() {
		AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
		addCategoryPage.clickOnPostCategories();
		assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar.");
	}
	@Test                      
	void tc02() throws InterruptedException {
		String x ="a";
		AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
		addCategoryPage.insertCatName(x);
		addCategoryPage.insertCatDesc(x);
		addCategoryPage.clickOnSave();
		assertEquals(addCategoryPage.isCatDesctwoErrorDisplayed(),true,"Greska nije prikazana");
		assertEquals(addCategoryPage.getCatDesctwoErrorText(),"The description must be at least 50 characters.","Text poruke proveri.");
		
	}
	@Test                      //         add category
	void tc03() throws InterruptedException {
	   String x = Utils.getDescName();
	   AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	    addCategoryPage.insertCatName(x);
		addCategoryPage.insertCatDesc(x);
		addCategoryPage.clickOnSave();
		ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
		assertEquals(listCategoryPage.countCatWithName(x),1,"Kategorija nije u listi.");
		
	}
	@Test                     
	void tc04() throws InterruptedException {
	   String x = "#456Category";
	   String y = "12345678@# 12345678@# 12345678@# 12345678@# 12345678@#";
	   AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	    addCategoryPage.insertCatName(x);
		addCategoryPage.insertCatDesc(y);
		addCategoryPage.clickOnSave();
		ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
		assertEquals(listCategoryPage.countCatWithName(x),1,"Kategorija nije u listi.");
	   
	} 
	@Test                             //   change order
	void tc05() throws InterruptedException {
		String x = Utils.getDescName();
		String y = "#456Category";
		ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
		listCategoryPage.clickOnChangeOrder();
		listCategoryPage.changeOrder(y, x);
		listCategoryPage.clickOnCancelOrder();
		assertEquals(listCategoryPage.isOrderonCurrentPageChanged(),false,"Redosled je promenjen.");
	}
	@Test                                          
	void tc06() throws InterruptedException {
		String x = Utils.getDescName();
		String y = "#456Category";
		ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
		listCategoryPage.clickOnChangeOrder();
		listCategoryPage.changeOrder(y, x);
		listCategoryPage.clickOnSaveOrder();
		assertEquals(listCategoryPage.isOrderonCurrentPageChanged(),true,"Order nije promenjen.");
	}
	@Test                                          
	void tc07() throws InterruptedException {
	ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
	listCategoryPage.clickOnAddNewCat();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_ADD,"Nije dobar URL.");
	}

	@Test                                        //empty;save
	void tc09() throws InterruptedException {
		AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
		addCategoryPage.insertCatName("");
		addCategoryPage.insertCatDesc("");
		addCategoryPage.clickOnSave();
		assertEquals(addCategoryPage.isCatNameErrorDisplayed(),true,"Poruka za ime nije prikazana.");
		assertEquals(addCategoryPage.isCatDescErrorDisplayed(),true,"Poruka za opis nije prikazana.");
		assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_ADD,"Url nije dobar.");
		assertEquals(addCategoryPage.getCatNameErrorText(),"This field is required.","Poruka nije dobra.");
		assertEquals(addCategoryPage.getCatDescErrorText(),"This field is required.","Poruka nije dobra.");
	}
@Test                                          //empty ;cancel
void tc10() {
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	addCategoryPage.insertCatName("");
	addCategoryPage.insertCatDesc("");
	addCategoryPage.clickOnCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar.");
}
@Test                                          //ok ime opis;cancel
void tc11() {
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	String x  = Utils.getRandomCatName();
	descName = Utils.getDescName();
	addCategoryPage.insertCatName(x);
	addCategoryPage.insertCatDesc(descName);
	addCategoryPage.clickOnCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar");
	ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
	assertEquals(listCategoryPage.countCatWithName(x),0,"Kategorija je u listi.");
}
@Test                                            //dobro ime;los opis;Save
void tc12() throws InterruptedException {
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	tempCatName = Utils.getRandomCatName();
	String x ="pictures";
	addCategoryPage.insertCatName(tempCatName);
	addCategoryPage.insertCatDesc(x);
	addCategoryPage.clickOnSave();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_ADD,"Url nije dobar.");
	assertEquals(addCategoryPage.isCatDesctwoErrorDisplayed(),true,"Poruka nije prikazana.");
	assertEquals(addCategoryPage.getCatDesctwoErrorText(),"The description must be at least 50 characters.","Poruka nije dobra.");
}
@Test                                              //dobra OBA;SAVE
void tc13() throws InterruptedException {
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	descName = Utils.getDescName();
	tempCatName = Utils.getRandomCatName();
	addCategoryPage.insertCatName(tempCatName);
	addCategoryPage.insertCatDesc(descName);
    addCategoryPage.clickOnSave();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar");
	ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
	assertEquals(listCategoryPage.countCatWithName(tempCatName),1,"Kategorija nije u listi.");
}
@Test                                                   //UpDATE ;NA CANCEL
void tc14() throws InterruptedException {
	
	String x = Utils.getDescName();	
	ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
	listCategoryPage.clickOnUpdateCateg(x);
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, false);
    assertEquals(addCategoryPage.getCatNameText(),x,"Nije dobar naziv kategorije.");
	addCategoryPage.clickOnCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar");
	assertEquals(listCategoryPage.countCatWithName(x),1,"Kategorija nije u listi");

}
@Test                                  //UPDATE ;OSTAVI prazno oba ;SAVE
void tc15() throws InterruptedException {
	String x = Utils.getDescName();	
	ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
    listCategoryPage.clickOnUpdateCateg(x);
    
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, false);
	assertEquals(addCategoryPage.getCatNameText(),x,"Nije dobar naziv kategorije");
	addCategoryPage.insertCatName("");
	addCategoryPage.insertCatDesc("");
	addCategoryPage.clickOnSave();
	assertEquals(addCategoryPage.isCatNameErrorDisplayed(),true,"Poruka za ime nije prikazana.");
	assertEquals(addCategoryPage.getCatNameErrorText(),"This field is required.","Poruka nije dobra.");
	assertEquals(addCategoryPage.isCatDescErrorDisplayed(),true,"Poruka nije prikazana.");
	assertEquals(addCategoryPage.getCatNameErrorText(),"This field is required.","Poruka nije dobra.");
}
@Test                         //POKUSAJ UPDATE SApostojecim u listi.NE da
void tc16() throws InterruptedException{
	String x = "#456Category";
    String d = Utils.getDescName();
    
	ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
	listCategoryPage.clickOnUpdateCateg(d);
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, false);
	assertEquals(addCategoryPage.getCatNameText(),d,"Nije dobar naziv kategorije");
	addCategoryPage.insertCatName(x);
	addCategoryPage.insertCatDesc(d);
	addCategoryPage.clickOnSave();
	assertEquals(addCategoryPage.isCatDesctwoErrorDisplayed(),true,"poruka nije prikazana.");
	assertEquals(addCategoryPage.getCatDesctwoErrorText(),"The name has already been taken.","Nije dobar text.");
	addCategoryPage.clickOnCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar");
	assertEquals(listCategoryPage.countCatWithName(d),1,"Kategorija nije u listi");
	assertEquals(listCategoryPage.countCatWithName(x),1,"Kategorija nije u listi");
	
}
@Test                                //UPDATE SA NOVim MOZE
void tc17() throws InterruptedException {
	     String x ="#456Category";
		 ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
	     listCategoryPage.clickOnUpdateCateg(x);
	     AddCategoryPage addCategoryPage = new AddCategoryPage(driver, false);
	     assertEquals(addCategoryPage.getCatNameText(),x,"nije dobar naziv kategorije.");
		 addCategoryPage.insertCatName("updatedName");
		 addCategoryPage.clickOnSave();
		 assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar");
		 assertEquals(listCategoryPage.countCatWithName(x),0,"Kategorija nije u listi");
		 assertEquals(listCategoryPage.countCatWithName("updatedName"),1,"Kategorija nije u listi.");	
}	
  
	
	

@Test                                         //DELETE pa CANCEL 1 U LIS dial broji=2
void tc18() throws InterruptedException {
	ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
	listCategoryPage.clickOnDeleteCat("updatedName");
	listCategoryPage.clickOnDeleteDialogCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar");
	assertEquals(listCategoryPage.countCatWithName("updatedName"),2,"Kategorija nije u listi.");
}
@Test                                                               //Delete pa delete;0 u listi
void tc19() throws InterruptedException {  
	ListCategoryPage listCategoryPage = new ListCategoryPage(driver);
	listCategoryPage.clickOnDeleteCat("updatedName");
	listCategoryPage.clickOnDeleteDialogDelete();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar");
	assertEquals(listCategoryPage.countCatWithName("updatedName"),0,"Kategorija je u listi.");
	}
@Test                                                            //ADD;dobro ime;opis empty;SAVE
 void tc20() throws InterruptedException{
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	tempCatName = Utils.getRandomCatName();
	addCategoryPage.insertCatName(tempCatName);
	addCategoryPage.insertCatDesc("");
	addCategoryPage.clickOnSave();
	assertEquals(addCategoryPage.getCatDescErrorText(),"This field is required.","Poruka nije dobra.");
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_ADD,"Url nije dobar.");
}
@Test                                                             //ADD; empty name;dobar opis;SAVE
 void tc21() throws InterruptedException{
	String x = Utils.getDescName();
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	addCategoryPage.insertCatName("");
	addCategoryPage.insertCatDesc(x);
	addCategoryPage.clickOnSave();
	assertEquals(addCategoryPage.getCatNameErrorText(),"This field is required.","Poruka nije dobra");
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_ADD,"Url nije dobar");
	
}
@Test                                                             //ADD; dobro ime;empty opis;CANCEL
 void tc22() {
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	tempCatName = Utils.getRandomCatName();
	addCategoryPage.insertCatName(tempCatName);
	addCategoryPage.insertCatDesc("");
	addCategoryPage.clickOnCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar");
}
@Test                                  //ADD;Prazno ime ;dobar opis:CANCEL
 void tc23() {
	String x = Utils.getDescName();
	AddCategoryPage addCategoryPage = new AddCategoryPage(driver, true);
	addCategoryPage.insertCatName("");
	addCategoryPage.insertCatDesc(x);
	addCategoryPage.clickOnCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.CATEGORY_LIST,"Url nije dobar");
}
                                               





}













