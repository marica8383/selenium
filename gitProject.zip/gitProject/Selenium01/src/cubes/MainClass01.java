package cubes;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainClass01 {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","D:/Desktop/webdriver/chromedriver.exe");
		
		ChromeDriver chromeDriver = new ChromeDriver();
		
		
		chromeDriver.get("https://google.rs");
		
		System.out.println("Title:"+chromeDriver.getTitle());
		System.out.println("Url:"+chromeDriver.getCurrentUrl());
		//chromeDriver.manage().window().maximize();
		Thread.sleep(2000);
		//chromeDriver.manage().window().minimize();
		WebElement inputElement = chromeDriver.findElement(By.id("APjFqb"));
		//System.out.println(inputElement);
		inputElement.sendKeys("Cubes school");
		inputElement.sendKeys(Keys.ENTER);
		
	   // WebElement inputElement = chromeDriver.findElement(By.id("APjFqb"));
		
		
		
		
		
		
		

	}

}
