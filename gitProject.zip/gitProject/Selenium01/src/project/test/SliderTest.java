package project.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;

import cubes.MyWebDriver;
import cubes.main.URLConst;
import cubes.main.Utils;
import cubes.pages.LoginPage;
import project.pages.AddSliderPage;
import project.pages.ListCategoryPage;
import project.pages.ListSliderPage;

class SliderTest {
    
	private static WebDriver driver;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
		driver= MyWebDriver.getInstance().getDriver("chrome");
		//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("name")));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		LoginPage loginPage = new LoginPage(driver);
	    loginPage.loginSuccess();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		driver.close();
	}

	@BeforeEach
	void setUp() throws Exception {
		driver.get(URLConst.SLIDER_LIST);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test 
	void test01() {
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.clickOnSliders();
		assertEquals(driver.getCurrentUrl(),URLConst.SLIDER_LIST,"Los URL.");
    
	}
	@Test                                            //valid 4 add
	void tc02() throws InterruptedException {
		String x = "Nihil dolor voluptas possimus et ex dolorem.";
		String t = "SliderButton SliderButton SliderButton SliderButt";
		String y = "http://www.mclaughlin.com/similique-aut-nam-similique-non-repellat-sed-temporibus";
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertTitle(x);
		addSliderPage.insertButtonTitle(t);
		addSliderPage.insertButtonUrl(y);
		addSliderPage.choosePhoto();
		addSliderPage.clickOnSave();
		ListSliderPage listSliderPage = new ListSliderPage(driver);
		assertEquals(listSliderPage.countSlidersWithName(x),1,"Slider nije dodat.");
		
	}                                             //short tit
	@Test
	void tc03() throws InterruptedException {
		String x = "v";
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertTitle(x);
		addSliderPage.clickOnSave();
		assertEquals(addSliderPage.isErrorButtTitleDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.isErrorButtUrlDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.isPhotoErrorDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.getButtTitleErrorText(),"This field is required.","Nije dobar text.");
		
		
	}
	
	@Test                                         //short bt
	void tc04() throws InterruptedException {
		String x = "v";
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertButtonTitle(x);
		addSliderPage.clickOnSave();
		assertEquals(addSliderPage.isErrorButtUrlDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.isPhotoErrorDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.isErrorTitleDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.getTitleErrorText(),"This field is required.","Nije dobar text.");
	
	}
	
	@Test                                       //short url error for format
	void tc05() throws InterruptedException {
		String x = "http@\\   qwert";
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertButtonUrl(x);
		addSliderPage.clickOnSave();
		assertEquals(addSliderPage.isErrorTitleDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.isErrorButtTitleDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.isPhotoErrorDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.getTitleErrorText(),"This field is required.","Nije dobar text.");
		assertEquals(addSliderPage.isUrlFormatErrorDisplayed(),false,"prikazana je.");
		
	}
	@Test                                   //long bt >50
	void tc06() throws InterruptedException {
		String t = "SliderButton SliderButton SliderButton SliderButtton Button";
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertButtonTitle(t);
		addSliderPage.clickOnSave();
		assertEquals(addSliderPage.isErrorButtTitleDisplayed(),true,"Greska nije prikazana.");
		assertEquals(addSliderPage.getBTitLengthErrorText(),"Please enter no more than 50 characters.","Text poruke nije dobar.");
		
	}
	@Test                                   //long tit >255;
	void tc07() throws InterruptedException {
		String x = "Nihil dolor voluptas possimus et ex dolorem dolorem dolorm doloremNihil dolor voluptas possimus et ex dolorem dolorem dolorm doloremNihil dolor voluptas possimus et ex dolorem dolorem dolorm doloremNihil dolor voluptas possimus et ex dolorem dolorem dolorm doloremNihil dolor voluptas possimus et ex dolorem dolorem dolorm dolorem";
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertTitle(x);
		addSliderPage.clickOnSave();
		assertEquals(addSliderPage.isTitleLengthErrorDisplayed(),true,"greska nije prikazana.");
	    assertEquals(addSliderPage.getTitleErrorText(),"Please enter no more than 255 characters.","Text nije dobar");
}
	@Test                                    //symbol
	void tc08() throws InterruptedException {
		String x = "Picture$%123";
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertTitle(x);
		addSliderPage.clickOnSave();
		assertEquals(addSliderPage.isErrorButtTitleDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.isErrorButtUrlDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.isPhotoErrorDisplayed(),true,"greska nije prikazana.");
		assertEquals(addSliderPage.getButtTitleErrorText(),"This field is required.","Nije dobar text.");
	    
		}
	
	@Test                                         //empty
	void tc09() throws InterruptedException {
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertTitle("");
		addSliderPage.insertButtonTitle("");
		addSliderPage.insertButtonUrl("");
		addSliderPage.clickOnSave();
		assertEquals(addSliderPage.isErrorTitleDisplayed(),true,"Nije prikazana greska");
		assertEquals(addSliderPage.isErrorButtTitleDisplayed(),true,"Nije prikazana greska.");
		assertEquals(addSliderPage.isErrorButtUrlDisplayed(),true,"Nije prikazana greska");
		assertEquals(addSliderPage.isPhotoErrorDisplayed(),true,"Nije prikazana greska");
		assertEquals(addSliderPage.getButtTitleErrorText(),"This field is required.","Nije dobar text.");
	}                                         
	@Test                                 //empty cancel
	void tc10() throws InterruptedException {
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertTitle("");
		addSliderPage.insertButtonTitle("");
		addSliderPage.insertButtonUrl("");
		addSliderPage.clickOnCancel();
		assertEquals(driver.getCurrentUrl(),URLConst.SLIDER_LIST,"nije url dobar.");
	}
	
	@Test                                      //photo gif 2 add
	void tc11() throws InterruptedException {
		String x = "ART & MUSIC";
		String m = "Click Me";
		String y = "http://www.mclaughlin.com";
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertTitle(x);
		addSliderPage.insertButtonTitle(m);
		addSliderPage.insertButtonUrl(y);
		addSliderPage.choosePhoto1();
		addSliderPage.clickOnSave();
		ListSliderPage listSliderPage = new ListSliderPage(driver);
		assertEquals(listSliderPage.countSlidersWithName(x),1,"Slider nije dodat.");
	}
	@Test                                      //photo jpg 3add
	void tc12() throws InterruptedException {
		String x = "# SpaCe For FreeDom";
		String m = "DONE";
		String y = "http://www.mclaughlin.com";
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		addSliderPage.insertTitle(x);
		addSliderPage.insertButtonTitle(m);
		addSliderPage.insertButtonUrl(y);
		addSliderPage.choosePhoto2();
		addSliderPage.clickOnSave();
		ListSliderPage listSliderPage = new ListSliderPage(driver);
		assertEquals(listSliderPage.countSlidersWithName(x),1,"Slider nije dodat.");
	}	
	@Test                                          //placehol 2
	void tc13() {
		AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		assertEquals(addSliderPage.isPlachBTDisplayed(),true,"Placeholder nije prikazan.");
		assertEquals(addSliderPage.isPlachBURLDisplayed(),true,"Placeholder nije prikazan.");
		assertEquals(addSliderPage.getBTPlacText(),"Enter name","Nije dobar text.");
		assertEquals(addSliderPage.getBURLPlacText(),"Enter phone","Nije dobar text.");
	}


	
	                                      //lista          change order
	@Test
	void tc14() throws InterruptedException {
		String y = "ART & MUSIC";
		String x = "Nihil dolor voluptas possimus et ex dolorem.";
		ListSliderPage listSliderPage = new ListSliderPage(driver);
		listSliderPage.clickOnChangeOrder();
		listSliderPage.changeOrder(y, x);
		listSliderPage.clickOnCancelOrder();
		assertEquals(listSliderPage.isOrderonCurrentPageChanged2(),false,"Redosled slidera je promenjen.");
		
	}
	
	@Test
	void tc15() throws InterruptedException {
		String x = "ART & MUSIC";
		String y = "Nihil dolor voluptas possimus et ex dolorem.";
		ListSliderPage listSliderPage = new ListSliderPage(driver);
		listSliderPage.clickOnChangeOrder();
		listSliderPage.changeOrder(y, x);
		listSliderPage.clickOnSaveOrder();
		assertEquals(listSliderPage.isOrderonCurrentPageChanged2(),true,"Order nije promenjen.");
	}
	
	@Test                                                  
	void tc16() throws InterruptedException {
		ListSliderPage listSliderPage = new ListSliderPage(driver);
		listSliderPage.clickOnAddNewCategory();
		assertEquals(driver.getCurrentUrl(),URLConst.SLIDER_ADD,"Nije dobar URL.");
		
	
	}
	                                                 //update

	@Test                                                                 
	void tc17() throws InterruptedException {
		String x = "ART & MUSIC";
	    ListSliderPage listSliderPage = new ListSliderPage(driver);
		listSliderPage.clickOnUpdateSlider(x);
		AddSliderPage addSliderPage = new AddSliderPage(driver, false);
		assertEquals(addSliderPage.getTitleText(),x,"Nije naziv u polju.");
		addSliderPage.clickOnCancel();
		assertEquals(listSliderPage.countSlidersWithName(x),1,"Slider nije u listi."); 
	}
	@Test                                            //updat                           
	void tc18() throws InterruptedException {
		String x = "ART & MUSIC";
	    ListSliderPage listSliderPage = new ListSliderPage(driver);
	    listSliderPage.clickOnUpdateSlider(x);
	    AddSliderPage addSliderPage = new AddSliderPage(driver, false);
	    assertEquals(addSliderPage.getTitleText(),x,"Nije dobar naziv.");
	    addSliderPage.insertTitle("");
	    addSliderPage.clickOnSave();
	    assertEquals(addSliderPage.isUpErrorTitDisplayed(),true,"Greska nije prikazana.");
	    assertEquals(addSliderPage.getUpTitleErrorText(),"This field is required.","losa poruka-text.");
	
}
	@Test                                          //updat  sa novoub                       
	void tc19() throws InterruptedException {
		 String old = "ART & MUSIC";
		 String x ="Inserted";
		 String y = "http://www.someexampre.com";
		 AddSliderPage addSliderPage = new AddSliderPage(driver, true);
		 addSliderPage.insertTitle(x);
		 addSliderPage.insertButtonTitle(x);
		 addSliderPage.insertButtonUrl(y);
		 addSliderPage.choosePhoto();
		 addSliderPage.clickOnSave();
		 ListSliderPage listSliderPage = new ListSliderPage(driver);
		 listSliderPage.clickOnUpdateSlider(old);
		 addSliderPage.insertTitle(x);
		 addSliderPage.clickOnSave();
		 assertEquals(listSliderPage.countSlidersWithName(x),2,"slider nije u listi.");
		 assertEquals(listSliderPage.countSlidersWithName(old),0,"slider je u listi.");
	}	
	@Test                                                               
	void tc20() throws InterruptedException {
		 
		 String x ="Inserted";
		 String n = "Upadted Title";
		 ListSliderPage listSliderPage = new ListSliderPage(driver);
		 listSliderPage.clickOnUpdateSlider(x);
		 AddSliderPage addSliderPage = new AddSliderPage(driver, false);
		 assertEquals(addSliderPage.getTitleText(),x,"Nije dobro ime.");
		 addSliderPage.insertTitle(n);
		 addSliderPage.clickOnSave();
		 assertEquals(listSliderPage.countSlidersWithName(x),1,"Slider je u listi.");
		 assertEquals(listSliderPage.countSlidersWithName(n),1,"Slider nije u listi."); 
	}
		
	@Test
	void tc21() throws InterruptedException {
		 String n = "Upadted Title";
		 ListSliderPage listSliderPage = new ListSliderPage(driver);
		 listSliderPage.clickOnEnableSlider(n);
		 listSliderPage.clickOnCancelfromDialogEnable();
		 assertEquals(listSliderPage.getStatusFrTable(n),"disabled","nije dobar status.");
	}
		
	@Test
	void tc22() throws InterruptedException {
		 String n = "Upadted Title";
		 ListSliderPage listSliderPage = new ListSliderPage(driver);
		 listSliderPage.clickOnEnableSlider(n);
		 listSliderPage.clickOnEnableFromDialogEnable();
		 assertEquals(listSliderPage.getStatusFrTable(n),"enabled","nije dobar status.");
	}
			
	@Test
	void tc23() throws InterruptedException {
		 String n = "Upadted Title";
		 ListSliderPage listSliderPage = new ListSliderPage(driver);
		 listSliderPage.clickOnDisableSlider(n);
		 listSliderPage.clickOnCancelfromDialogDisable();
		 assertEquals(listSliderPage.getStatusFrTable(n),"enabled","nije dobar status.");
	}
	
	@Test
	void tc24() throws InterruptedException {
		 String n = "Upadted Title";
		 ListSliderPage listSliderPage = new ListSliderPage(driver);
		 listSliderPage.clickOnDisableSlider(n);
		 listSliderPage.clickOnDisableFromDialogDisable();
		 assertEquals(listSliderPage.getStatusFrTable(n),"disabled","nije dobar status.");
	}		
		
	@Test
	void tc25() throws InterruptedException {
		 String n = "Upadted Title";
		 ListSliderPage listSliderPage = new ListSliderPage(driver);
		 listSliderPage.clickOnDeleteSlider(n);
		 listSliderPage.clickOnCancelfromDialogDelete();
		 assertEquals(listSliderPage.countSlidersWithName(n),2,"Slider nije u listi.");
	}		
	@Test
	void tc26() throws InterruptedException {
		 String n = "Upadted Title";
		 ListSliderPage listSliderPage = new ListSliderPage(driver);
		 listSliderPage.clickOnDeleteSlider(n);
		 listSliderPage.clickOnDeletefromDialogDelete();
		 assertEquals(listSliderPage.countSlidersWithName(n),1,"Slider nije obrisan.");//1 from dialog
	}				
		
		
		
		
	

		
		
		
	
	
}
