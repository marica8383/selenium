package cubes.test.login;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cubes.MyWebDriver;
import cubes.main.URLConst;
import cubes.pages.LoginPage;

class LoginTestCase {
	//public static String urlLoginPage = "https://testblog.kurs-qa.cubes.edu.rs/login";
	private static WebDriver driver;
	//private static WebElement weEmail;
	//private static WebElement wePassword;
	//private static WebElement weSignIn;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		 driver = MyWebDriver.getInstance().getDriver("chrome");
		//driver.get(urlLoginPage);
		driver.manage().window().maximize();
		driver.get(URLConst.LOGIN);
		 //weEmail = driver.findElement(By.xpath("//input[@type='email']"));
		// wePassword =driver.findElement(By.xpath("//input[@type='password']"));
		// weSignIn = driver.findElement(By.xpath("//button[@type='submit']"));
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		driver.close();
	}

	@BeforeEach
	void setUp() throws Exception {
		//driver.get(urlLoginPage);
		//weEmail.clear();
		//wePassword.clear();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test01() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.insertEmail("");
		loginPage.insertPassword("");
		loginPage.clickOnSignIn();
		//weEmail.sendKeys("");
		//wePassword.sendKeys("");
		//weSignIn.click();
		WebElement weEmailError = driver.findElement(By.xpath("//p[@id='email-error']"));
		WebElement wePasswordError = driver.findElement(By.xpath("//p[@id='password-error']"));
		assertEquals(driver.getCurrentUrl(),URLConst.LOGIN,"URL nije dobar");
		assertEquals(loginPage.isEmailErrorDisplayed(),true,"Email poruka nije prikazana");
		assertEquals(loginPage.isPasswordErrorDisplayed(),false,"Password element je prikazan");
		assertEquals(loginPage.getEmailErrorText(),"Email* is required field","Email poruka nije dobra");
		//assertEquals(loginPage.getPasswordErrorText(),"Password* is required field","Password poruka nije dobra");
		
		//assertEquals(weEmailError.isDisplayed(),true,"email error not displayed");
		//assertEquals(wePasswordError.isDisplayed(),false,"pasword error is displayed");
		//assertEquals(weEmailError.getText(),"Email* is required field","poruka email nije dobra");
		//assertEquals(wePasswordError.getText(),"Password is required field","Pasword poruka nije dobra");
		//assertEquals(wePasswordError.getText(),"","Password nije dobar");
	}
	
	@Test
	void test02() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.insertEmail("marko");
		loginPage.insertPassword("");
		loginPage.clickOnSignIn();
		//weEmail.sendKeys("marko");
		//wePassword.sendKeys("");
		//weSignIn.click();
	WebElement weEmailError = driver.findElement(By.xpath("//p[@id='email-error']"));
	WebElement wePasswordError = driver.findElement(By.xpath("//p[@id='password-error']"));
	
	assertEquals(driver.getCurrentUrl(),URLConst.LOGIN,"URL nije dobar");
	assertEquals(loginPage.isEmailErrorDisplayed(),true,"Email poruka nije prikazana");
	assertEquals(loginPage.isPasswordErrorDisplayed(),false,"Password element je prikazan");
	assertEquals(loginPage.getEmailErrorText(),"Please, enter the valid Email address","Email poruka nije dobra");
	//assertEquals(loginPage.getPasswordErrorText(),"Password* is required field","Password poruka nije dobra");
	
	
	//assertEquals(weEmailError.isDisplayed(),true,"email error not displayed");
	//assertEquals(wePasswordError.isDisplayed(),false,"pasword error is displayed");
	//assertEquals(weEmailError.getText(),"Please, enter the valid Email address","poruka email nije dobra");
	//assertEquals(wePasswordError.getText(),""," Tekst Pasword poruke nije dobar");
	
	
	}
	@Test
	void test03() {
		
		LoginPage loginPage = new LoginPage(driver);
		loginPage.insertEmail("marko");
		loginPage.insertPassword("marko");
		loginPage.clickOnSignIn();
		//weEmail.sendKeys("marko");
		//wePassword.sendKeys("marko");
		//weSignIn.click();
	WebElement weEmailError = driver.findElement(By.xpath("//p[@id='email-error']"));
	//WebElement wePasswordError = driver.findElement(By.xpath("//p[@id='password-error']"));
	
	assertEquals(driver.getCurrentUrl(),URLConst.LOGIN,"URL nije dobar");
	assertEquals(loginPage.isEmailErrorDisplayed(),true,"Email poruka nije prikazana");
	//assertEquals(loginPage.isPasswordErrorDisplayed(),false,"Password element je prikazan");
	assertEquals(loginPage.getEmailErrorText(),"Please, enter the valid Email address","Email poruka nije dobra");
	//assertEquals(weEmailError.isDisplayed(),true,"email error not displayed");
	//assertEquals(wePasswordError.isDisplayed(),false,"password error is displayed");
	//assertEquals(weEmailError.getText(),"Please, enter the valid Email address","poruka email nije dobra");
	//assertEquals(wePasswordError.getText(),"","Pasword poruka nije dobra");
	}
@Test
    void test04() {
	LoginPage loginPage = new LoginPage(driver);
	loginPage.insertEmail("");
	loginPage.insertPassword("marko");
	loginPage.clickOnSignIn();
	//weEmail.sendKeys("");
	//wePassword.sendKeys("marko");
	//weSignIn.click();
	
	WebElement weEmailError = driver.findElement(By.xpath("//p[@id='email-error']"));
	//WebElement wePasswordError = driver.findElement(By.xpath("//p[@id='password-error']"));
	
	assertEquals(driver.getCurrentUrl(),URLConst.LOGIN,"URL nije dobar");
	assertEquals(weEmailError.isDisplayed(),true,"email error not displayed");
	//assertEquals(wePasswordError.isDisplayed(),false,"password error is displayed");
	assertEquals(weEmailError.getText(),"Email* is required field","poruka email nije dobra");	
	
}
//@Test
    // void test05()    {
	   // LoginPage loginPage = new LoginPage(driver)

// loginPage.loginSuccess();











}












