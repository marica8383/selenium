package cubes.main;

public class URLConst {
	//public final static String LOGIN =" https://testblog.kurs-qa.cubes.edu.rs/login";
	//public final static String TAG_ADD = "https://testblog.kurs-qa.cubes.edu.rs/admin/tags/add";
	//public final static String TAG_LIST = "https://testblog.kurs-qa.cubes.edu.rs/admin/tags";
	public final static String  BASE_URL = "https://testblog.kurs-qa.cubes.edu.rs";
	public final static String LOGIN = BASE_URL+"/login";
	public final static String TAG_ADD = BASE_URL+"/admin/tags/add";
	public final static String TAG_LIST = BASE_URL+"/admin/tags";
	public final static String CATEGORY_ADD = BASE_URL+"/admin/post-categories/add";
	public final static String CATEGORY_LIST= BASE_URL+"/admin/post-categories";
	public final static String POST_ADD = BASE_URL+"/admin/posts/add";
	public final static String POST_LIST = BASE_URL+"/admin/posts";
	
	public final static String SLIDER_ADD = BASE_URL+"/admin/sliders/add";
	public final static String SLIDER_LIST = BASE_URL+"/admin/sliders";
	public final static String USER_ADD = BASE_URL+"/admin/users/add";
	public final static String USER_LIST = BASE_URL+"/admin/users";
	
	
	
	
}
 //rs/admin/post-categories/edit/1845 Za EDIT STRANICA