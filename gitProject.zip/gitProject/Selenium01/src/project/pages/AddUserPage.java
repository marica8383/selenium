package project.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import cubes.main.URLConst;

public class AddUserPage {

private WebDriver driver;
	
	public AddUserPage(WebDriver driver, boolean openPage) {
		this.driver = driver;
		this.driver.manage().window().maximize();
		if(openPage) {
		this.driver.get(URLConst.USER_ADD);}
		PageFactory.initElements(driver,this);
	}
	
	public void insertEmail(String name) {
		WebElement x = driver.findElement(By.xpath("//input[@name='email']"));
		x.clear();
		x.sendKeys(name);
	}
	
	public void insertNameOfUser(String name) {
		WebElement x = driver.findElement(By.xpath("//input[@name='name']"));
		x.clear();
		x.sendKeys(name);
	}
	
	public void insertPhone(String name) {
		WebElement x = driver.findElement(By.xpath("//input[@name='phone']"));
		x.clear();
		x.sendKeys(name);
	}
	
	public void choosePhoto() {
		WebElement x = driver.findElement(By.xpath("//input[@type='file']"));
		x.sendKeys("D:\\Desktop\\pictures\\Capture5.png");
	}
	public void choosePhoto1() {
		WebElement x = driver.findElement(By.xpath("//input[@type='file']"));
		x.sendKeys("D:\\Desktop\\1.gif");
	}
	public void choosePhoto2() {
		WebElement x = driver.findElement(By.xpath("//input[@type='file']"));
		x.sendKeys("D:\\Desktop\\2.jpg");
	}
	public void choosePhotoTxt() {
		WebElement x = driver.findElement(By.xpath("//input[@type='file']"));
		x.sendKeys("D:\\Desktop\\pictures\\phototx.txt");
	}
	
	public void clickOnHome() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Home']"));
		x.click();		
	}
	public void clickOnUsers() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Users']"));   
		x.click();		
	}
	
	public void clickOnSave() {
		WebElement x = driver.findElement(By.xpath("//button[@type='submit']"));
		x.click();	
		
	}
	
	public void clickOnCancel() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Cancel']"));
		x.click();		
	}
	
	                                   //reqyired,format isti lokatori
	public boolean isErrorEmailDisplayed() {
		WebElement x = driver.findElement(By.xpath("//span[@id='email-error']"));     
		return x.isDisplayed();
	}
	
	                                    
	public boolean isErrorNameDisplayed() {
		WebElement x = driver.findElement(By.xpath("//span[@id='name-error']"));
		return x.isDisplayed();
	}
	                                    //req,max.format
	public boolean isErrorPhoneDisplayed() {
		WebElement x = driver.findElement(By.xpath("//span[@id='phone-error']"));
		return x.isDisplayed();
	}
	
	
	
	
	public String getEmailErrorText() {
		WebElement x = driver.findElement(By.xpath("//span[@id='email-error']"));
		return x.getText();
	}
	public String getNameErrorText() {
		WebElement x = driver.findElement(By.xpath("//span[@id='name-error']"));
		return x.getText();
	}
	
	public String getPhoneErrorText() {
		WebElement x = driver.findElement(By.xpath("//span[@id='phone-error']"));
		return x.getText();
	}
	
	
	
	public String getEmailText() {
		WebElement x = driver.findElement(By.xpath("//input[@name='email']"));
	     return x.getAttribute("value");
	}
	public String getNameText() {
		WebElement x = driver.findElement(By.xpath("//input[@name='name']"));
	     return x.getAttribute("value");
	}
	
	
	public String getPhoneText() {
		WebElement x = driver.findElement(By.xpath("//input[@name='phone']"));
	     return x.getAttribute("value");
	}
	
	                               //delete photo scroll
	
	
	   public void clickOnDeletePhoto() throws InterruptedException {
		   
		     ((JavascriptExecutor)driver).executeScript("window.scrollBy(2000,0)");
			 Thread.sleep(2000);
			 WebElement e = driver.findElement(By.xpath("//button[@data-action='delete-photo']"));
		     e.click();  	 
	         ((JavascriptExecutor)driver).executeScript("window.scrollBy(-2000,0)");  
			  
	
		   
	   }
                              //photo for update
     public boolean isPhotoDisplayed() {
      return driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).isDisplayed();
  }

      public int getPhotoWidth() {
       return driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).getSize().getWidth();	 }


      public int getPhotoHeight() {
        return driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).getSize().getHeight();	 }


     public String getPhotoUrl() {
      return driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).getAttribute("src");	 }

     public String getDescriptionOfPhoto() {
    
     String src = driver.findElement(By.xpath("//label[text()='Photo']//following::img[1]")).getAttribute("src");
     String y = src.substring(14);
     return y;                                             
}             
	

     
     
     
     
}
