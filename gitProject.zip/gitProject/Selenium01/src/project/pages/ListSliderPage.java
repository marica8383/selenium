package project.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cubes.main.URLConst;

public class ListSliderPage {
            
	private WebDriver driver;
	
	
	
	public ListSliderPage(WebDriver driver) {
		this.driver = driver;
		//this.driver.manage().window().maximize();
		//this.driver.get(URLConst.SLIDER_LIST);
		PageFactory.initElements(driver,this);
	}
	
	
	
	public void openPage() {
		this.driver.get(URLConst.SLIDER_LIST);
	}
	public void clickOnHome() {
		WebElement x = driver.findElement(By.xpath("//a[text()='Home']"));
		x.click();
	}
	
	public void clickOnAddNewCategory() {
		WebElement x = driver.findElement(By.xpath("//a[@class='btn btn-success']"));
		x.click();
	}
	
	public void clickOnChangeOrder() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//button[@data-action='show-order']"));
		x.click();
		Thread.sleep(500);
	}
	
	public void clickOnSaveOrder() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//button[@class='btn btn-outline-success']"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
		Thread.sleep(500);
		x.click();
		Thread.sleep(1000);
	}
	
	
	public void clickOnCancelOrder() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//button[@class='btn btn-outline-danger']"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x );
		
		x.click();
		Thread.sleep(500);
	}
	
	
	
	public int countSlidersWithName(String name) {
		List<WebElement> x = driver.findElements(By.xpath("//strong[text()='"+name+"']"));
		return x.size();
	}
	public boolean isSliderInList(String name) {
		List<WebElement> x = driver.findElements(By.xpath("//strong[text()='"+name+"']"));
		return x.size()>0;
	}
	public String getSlidersWithNameInList(String name) {
		return driver.findElements(By.xpath("//strong[text()='"+name+"']")).toString();
		
	}
	
	
	
	
	                                                //update
	
	public void clickOnUpdateSlider(String name) throws InterruptedException {
		WebElement updateButton = driver.findElement(By.xpath("//strong[text()='"+name+"']//ancestor::tr//td[7]//a[1]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", updateButton );
		 
		  Thread.sleep(2000);
	   updateButton.click();
	}
	public void clickOnEnableSlider(String name) throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//strong[text()='"+name+"']//ancestor::tr//td[7]//button[1]"));
		
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
		 Thread.sleep(2000);
		  x.click();
	}
	public void clickOnEnableFromDialogEnable() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-success'])[1]"));
		x.click();
		Thread.sleep(500);
	}
	public void clickOnCancelfromDialogEnable() {
		WebElement x = driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-success'])//ancestor::div[1]//button[1]"));
		x.click();
	}
	
	
	public void clickOnDisableSlider(String name) throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//strong[text()='"+name+"']//ancestor::tr//td[7]//button[1]"));
		
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
		 Thread.sleep(2000);
		  x.click();
	}
	public void clickOnDisableFromDialogDisable() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-danger'])[2]"));
		x.click();
		Thread.sleep(500);
	}
	public void clickOnCancelfromDialogDisable() {
		WebElement x = driver.findElement(By.xpath("(//button[@type='submit'][@class='btn btn-danger'])[2]//preceding::button[1]"));
		x.click();
	}
	
                                                              //delete
	
	public void clickOnDeleteSlider(String name) throws InterruptedException {
		//((JavascriptExecutor)driver).executeScript("window.scrollBy(1000,0)");
		WebElement x = driver.findElement(By.xpath("//strong[text()='"+name+"']//ancestor::tr//td[7]//button[2]"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", x);
		 // Thread.sleep(2000);
		Thread.sleep(1000);
		x.click();
	}
	public void clickOnDeletefromDialogDelete() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//button[text()='Delete']"));
		x.click();
		Thread.sleep(500);
	}
	public void clickOnCancelfromDialogDelete() throws InterruptedException {
		WebElement x = driver.findElement(By.xpath("//button[text()='Delete']//ancestor::div[1]//button[1]"));
		x.click();
		
	}
	        
	
	                                                      //change
	public boolean isOrderChanged() {
		 List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//tr"));
	     List<String> y = new ArrayList<>();
	     for(int i = 1;i<x.size()-1;i++) {
	    	 y.add(x.get(i).getAttribute("data-id"));
	     }
	     for(int j = 0;j<y.size()-1;j++) {
	    	 if((Integer.parseInt(y.get(j)))>(Integer.parseInt(y.get(j+1)))){
			 return true;
		 }
	     }
	     return false;
	}
	
	                                           //CHANGE
	
	
	   public boolean isOrderonCurrentPageChanged2() {
		   List<WebElement> x = driver.findElements(By.xpath("//table[@id='entities-list-table']//tr"));
		  for(int i = 1;i<x.size()-1;i++) {
		  if( ((Integer.parseInt(x.get(i).getAttribute("data-id")) > ( Integer.parseInt(x.get(i+1).getAttribute("data-id") ))  )) ) {
		  return true;
		
		}}
		   return false;
	                                                                 
	}	       
	
	
	 public void changeOrder(String name, String nameSec) throws InterruptedException {
		 Thread.sleep(500);
		 Actions act = new Actions(driver);
		 WebElement dragable = driver.findElement(By.xpath("//strong[text()='"+name+"']//preceding::td[2]//span[1]"));
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", dragable );
		 ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,4000)");
	    WebElement dropable = driver.findElement(By.xpath("//strong[text()='"+nameSec+"']//preceding::td[2]//span[1]"));
		 Thread.sleep(1000);
		 ((JavascriptExecutor)driver).executeScript("arguments[0].click();", dragable );
		// dragable.click();
		 Thread.sleep(1000);
		 act.dragAndDrop(dragable, dropable).build().perform();
		 Thread.sleep(1000);
		
      }                                       //prvi ispod dr  
	public void changeOrderByNum(String num,String numSec) {
		 WebElement dragable = driver.findElement(By.xpath("//tr[@data-id='"+num+"']//td[1]//span[1]"));
		 WebElement dropable = driver.findElement(By.xpath("//tr[@data-id='"+numSec+"']//td[1]//span[1]"));
		 Actions act = new Actions(driver);
		 act.dragAndDrop(dragable, dropable).build().perform();
	}
	
	
	
	
                                                         //photo
	 public boolean isPhotoDisplayed(String name) {
		  return driver.findElement(By.xpath("//strong[text()='"+name+"']//preceding::td[1]//img")).isDisplayed();
	 }
	  
	 public int getPhotoWidth(String name) {
		 return driver.findElement(By.xpath("//strong[text()='"+name+"']//preceding::td[1]//img")).getSize().getWidth(); }
	 
	 
	 public int getPhotoHeight(String name) {
		 return driver.findElement(By.xpath("//strong[text()='"+name+"']//preceding::td[1]//img")).getSize().getHeight(); }
	 
	 
	 public String getPhotoUrl(String name) {
		 return driver.findElement(By.xpath("//strong[text()='"+name+"']//preceding::td[1]//img")).getAttribute("src");	}
	 
	 public String getDescriptionOfPhoto(String name) {
		String src = driver.findElement(By.xpath("//strong[text()='"+name+"']//preceding::td[1]//img")).getAttribute("src");
	   
		String y = src.substring(58, 70);
	 return y;                                              
	 }                                                      
	                                             //fromtab
	 
	 
	  public String getTitleFromTable(String num) {
		   return driver.findElement(By.xpath(" //tr[@data-id='"+num+"']//td[1]//following-sibling::td[2]")).getText();
		   
		                                     
	   }
	
	   public String getUrlFromTable(String name) {
		   return driver.findElement(By.xpath(" //strong[text()='"+name+"']//ancestor::tr[1]//td[4]")).getText();
		   
		                                     
	   }                                          
	 
	 public String getStatusFromTable(String num) {
		  return driver.findElement(By.xpath(" //tr[@data-id='"+num+"']//td[1]//following-sibling::td[4]")).getText();
	 }
	
	 public String getStatusFrTable(String name) {
		  return driver.findElement(By.xpath("//strong[text()='"+name+"']//ancestor::tr[1]//td[5]")).getText();
	 }
	                                           
	


	
	
	
	
	
}
