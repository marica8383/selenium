package cubes.main;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Utils {
	
	public static int getRandomNumber() {
		Random random = new Random();
		return random.nextInt(10000);
	}
	public static String getRandomTagName() {
		return "TagName"+getRandomNumber();
	}
	public static void scrollToElement(WebDriver driver, WebElement element) {
	((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", element);
		
	}
	
	public static void scrollToElement(WebDriver driver, String locator) {
		WebElement element = driver.findElement(By.xpath(locator));
	 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}
	                                                              //   CATEG
	public static String getRandomCatName() {
	     return "CategoryNew"+getRandomNumber();}
	
	public static String getCatUpdName() {
		 return "CategoryForUpdate";}
	
	public static String getDescName() {                                  ///50 opis kat 63
		 return "This is very long description for those who cant easily express";
	}
	                                                   //POST
	
	public static String getPostTitle() {                             //20
		 return "This is post about Art and Music";
	}
	public static String getPostTitle2() {                             //20
		 return "This is New post about Art and Music";
	}                                                                  //50
	public static String getPostDesc() {
		 return "Post description for those who need many Words to say smthing";
	}
	
	
	
	
	
	
	
	
	
}
