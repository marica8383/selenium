package project.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;

import cubes.MyWebDriver;
import cubes.main.URLConst;
import cubes.main.Utils;
import cubes.pages.AddTagPage;
import project.pages.AddCategoryPage;
import project.pages.AddPostPage;
import project.pages.ListPostPage;
import project.pages.LoginPage;

class PostTest {
     
	
	private static WebDriver driver;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		driver = MyWebDriver.getInstance().getDriver("chrome");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		LoginPage loginPage = new LoginPage(driver);
		loginPage.loginSuccess();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		driver.close();
		
	}

	@BeforeEach
	void setUp() throws Exception {
		driver.get(URLConst.POST_LIST);
	}

	@AfterEach
	void tearDown() throws Exception {
	}                                                                              
 @Test
 void tc01() {
	 AddPostPage addPostPage = new AddPostPage(driver,true);
	 addPostPage.clickOnPost();
	 assertEquals(driver.getCurrentUrl(),URLConst.POST_LIST,"URL nije dobar.");
 }
  @Test    //P emp save
  void tc02() throws InterruptedException {
		AddPostPage addPostPage = new AddPostPage(driver,true);
		addPostPage.insertTitle("");
		addPostPage.insertPostDesc("");
		addPostPage.clickOnSave();
		assertEquals(driver.getCurrentUrl(),URLConst.POST_ADD,"URL nije dobar.");
		assertEquals(addPostPage.isTitleErrorDisplayed(),true,"Greska za title nije prikazana.");
		assertEquals(addPostPage.isDescriptionErrorDisplayed(),true,"Greska za opis nije prikazana.");
		assertEquals(addPostPage.isTagErrorDisplayed(),true,"Greska za tag nije prikazana.");
		assertEquals(addPostPage.getTitleErrorText(),"This field is required.","Text poruke los.");
		assertEquals(addPostPage.getDescrErrorText(),"This field is required.","Text poruke los.");
	}


@Test              // empty u oba.NA CANCEL,LISTU
 void tc03() throws InterruptedException {
	AddPostPage addPostPage = new AddPostPage(driver,true);
	addPostPage.insertTitle("");
	addPostPage.insertPostDesc("");
	addPostPage.clickOnCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.POST_LIST,"URL nije dobar.");
}
@Test   // P    sve validno, Cancel; 3,4tag  
void tc04() throws InterruptedException {                
	String t = Utils.getRandomTagName();
	AddTagPage addTagPage = new AddTagPage(driver,true);
	addTagPage.insertTagName(t);
	addTagPage.clickOnSave();
	
	AddPostPage addPostPage = new AddPostPage(driver,true);
	String m = Utils.getPostTitle();
	String n = Utils.getPostDesc();
	String c ="SOME NEW CONTENT";
	addPostPage.insertTitle(m);
	addPostPage.insertPostDesc(n);
	addPostPage.clickOnCheckBoxLabelTagname(t);
	addPostPage.insertContent(c);
	addPostPage.clickOnCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.POST_LIST,"URL nije dobar.");
	ListPostPage listPostPage = new ListPostPage(driver);
	assertEquals(listPostPage.countPostWithTitle(m),0,"Post je u listi.");
}
@Test                  
void tc05() throws InterruptedException { 
	String m = "123456789NewPostTitle";
	String x = "Default TAG NE BRISATI";
	AddPostPage addPostPage = new AddPostPage(driver,true);
	addPostPage.insertTitle(m);
	addPostPage.insertPostDesc(m);
	addPostPage.clickOnCheckBoxLabelTagname(x);
	addPostPage.clickOnSave();
	assertEquals(addPostPage.isDescriptionErrorDisplayed(),true,"Greska nije prikazana.");
	assertEquals(addPostPage.getDescrErrorText(),"Please enter at least 50 characters.","Poruka text los.");
	
	}
	
@Test            //P  short tit&desc,save,na add si;3grESKE
void tc06() throws InterruptedException {
AddPostPage addPostPage = new AddPostPage(driver,true);
String m = "abba";
String n = "songs";
addPostPage.insertTitle(m);
addPostPage.insertPostDesc(n);
addPostPage.clickOnSave();
assertEquals(driver.getCurrentUrl(),URLConst.POST_ADD,"URL nije dobar.");
assertEquals(addPostPage.getTitleErrorText(),"Please enter at least 20 characters.","Poruka tekst los.");
assertEquals(addPostPage.getDescrErrorText(),"Please enter at least 50 characters.","Poruka text los.");
}


@Test     //      P  UNESI DOBAR NASL,OPIS, CEKIRAJ TAG ;NA SAVE;add i1gRESKa
void tc07() throws InterruptedException {
String m = Utils.getPostTitle();
String n = Utils.getPostDesc();
AddPostPage addPostPage = new AddPostPage(driver,true);
addPostPage.insertTitle(m);
addPostPage.insertPostDesc(n);
addPostPage.clickOnCheckBoxLabelTagname("Default TAG NE BRISATI");
addPostPage.clickOnSave();
assertEquals(driver.getCurrentUrl(),URLConst.POST_ADD,"URL nije dobar");
assertEquals(addPostPage.getContentErrorText(),"The content field is required.","Text poruke los.");
}
	
@Test             //Sva 4 dobra unesi,na save;//CANNOT add POST     8  add
void tc08() throws InterruptedException {
	String m = Utils.getPostTitle();
	String n = Utils.getPostDesc();
	String x ="Default TAG NE BRISATI";
	String c = "Some  new  content";
	AddPostPage addPostPage = new AddPostPage(driver, true);
	addPostPage.insertTitle(m);
	addPostPage.insertPostDesc(n);
	addPostPage.clickOnCheckBoxLabelTagname(x);
	//addPostPage.uploadFile2();
	addPostPage.insertContent(c);
	addPostPage.clickOnSave();
	ListPostPage listPostPage = new ListPostPage(driver);
	assertEquals(listPostPage.countPostWithTitle(m),1,"Post nije u listi.");
	
}
                                         //addpost tu category

@Test       // P Ubacenu kategorij sel;  
void tc09() throws InterruptedException {
String x = "This is very long description for those who cant easily express";
AddPostPage addPostPage = new AddPostPage(driver,true);
addPostPage.clickOnChooseCat();
addPostPage.clickOnCatOption(x);
assertEquals(addPostPage.getNameSelOptCategory(),x,"Nije dobar naziv.");
assertEquals(addPostPage.getNumofSelInCategory(),1,"Nije dobar broj selektovanih.");
}
@Test          //p KL na categ,pa na opciju;vise
void tc10() throws InterruptedException {
	String x = "This is very long description for those who cant easily express";
	String y ="#456Category";
	AddPostPage addPostPage = new AddPostPage(driver,true);
	addPostPage.clickOnChooseCat();
	addPostPage.clickOnCatOption(x);
	addPostPage.clickOnCatOption(y);
	assertEquals(addPostPage.getNameSelOptCategory(),y,"Lose ime kategorije.");
	assertEquals(addPostPage.getNumofSelInCategory(),1,"Nije dobar broj selektovanih.");
}

                                             //RADIO


	@Test
	void tc11() {
		AddPostPage addPostPage = new AddPostPage(driver,true);
		assertEquals(addPostPage.isNoSelected(),true,"Nije selektovan.");
	}
	
	
@Test                  
void tc12() {
	AddPostPage addPostPage = new AddPostPage(driver,true);
	assertEquals(addPostPage.isYesDisplayed(),false,"Radio YES je prikazan.");
	 addPostPage.clickOnImpYes();
	 assertEquals(addPostPage.isYesSelected(),true,"Radio button nije selektovan.");
	 addPostPage.clickOnImpYes();
	 assertEquals(addPostPage.isYesSelected(),true,"Radio button nije selektovan.");
}
            //  p SAMO 1 MOZE BITI CEKIRAN,PRVI ODCEKIRA
@Test
void tc13() {
	AddPostPage addPostPage = new AddPostPage(driver,true);
	addPostPage.clickOnImpNo();
	addPostPage.clickOnImpYes();
	assertEquals(addPostPage.isYesSelected(),true,"Radio button nije selektovan.");
	assertEquals(addPostPage.isNoSelected(),false,"Radio No je selektovan.");
}
@Test// p          nO ne mozes odcekirati;
void tc14() {
	AddPostPage addPostPage = new AddPostPage(driver,true);
	assertEquals(addPostPage.isNoSelected(),true,"Radio No nije selektovan.");
	addPostPage.clickOnImpNo();
	assertEquals(addPostPage.isNoSelected(),true,"Radio No nije selektovan.");
}
@Test   ///  NO Je selekt.;daj size   
void tc15() {
	AddPostPage addPostPage = new AddPostPage(driver,true);
	assertEquals(addPostPage.isNoSelected(),true,"Radio No nije selektovan.");
	assertEquals(addPostPage.getLabelRadioName(),"No","Nije dobar naziv labele.");
	assertEquals(addPostPage.getRadioListSize(),2,"Size los.");
	assertEquals(addPostPage.getNumbOfSelInRadioList(),1,"Broj selektovanih los.");
	
}  

@Test                    //prlabele samo RADIO
void tc16() {
	AddPostPage addPostPage = new AddPostPage(driver,true);
	assertEquals(addPostPage.getRadioListSize(),2,"Nije dobar size radio liste.");
	assertEquals(addPostPage.getLabelRadioName(),"No","Nije dobro ime radio buttona.");
	assertEquals(addPostPage.getNumbOfSelInRadioList(),1,"Nije dobar broj selektovanih.");

}

                                  //checkbox
@Test      // P  CEKIRAJ DVA;lista size;broj selektov; 
void tc17() throws InterruptedException {
	 AddPostPage addPostPage = new AddPostPage(driver,true);
     addPostPage.clickOnCheckBoxLabelTagname("Default TAG NE BRISATI");
	 addPostPage.clickOnCheckBoxLabelTagname("TenSharpBeautiful");
	 assertEquals(addPostPage.getIndexOfSelTags(),"[1, 2]","lista losa.");        
	 assertEquals(addPostPage.getNumbOfSelInCheckboxList(),2,"Broj selektovanih los.");
	                    
}	

         
@Test   //p SELEKTUJ SVE;broj sel ;
 void tc18() {
	AddPostPage addPostPage = new AddPostPage(driver,true);
	addPostPage.selectAllChBoxes();

}  
	
@Test       //   PIME LABELE JEDNE //MoZES oDCEKIRATI box
void tc19() {
	
	AddPostPage addPostPage = new AddPostPage(driver,true);
	addPostPage.clickOnCheckBoxLabelTagname("Default TAG NE BRISATI");
	assertEquals(addPostPage.getIndexOfSelectedCh(),1,"Index selektovanog nije dobar.");
	assertEquals(addPostPage.getLabelCheckboxName(),"Default TAG NE BRISATI","Lose ime Taga.");
	addPostPage.clickOnCheckBoxLabelTagname("Default TAG NE BRISATI");
	assertEquals(addPostPage.isChboxSelected(),false,"CEKIRAN je box.");
}



                                              
@Test         //Nece na sav tu fail   //      add cannot   add 8 ,21 rucnoubacen  1  
void tc21() throws InterruptedException {
	
	AddPostPage addPostPage = new AddPostPage(driver, true);
	String m = Utils.getPostTitle();
	String n = Utils.getPostDesc();                                                    
    addPostPage.insertTitle(m);
	addPostPage.insertPostDesc(n);
	addPostPage.clickOnCheckBoxLabelTagname("TenSharpBeautiful");
	addPostPage.insertContent("SOMENEWCONTENT");
	addPostPage.clickOnSave();
	ListPostPage listPostPage = new ListPostPage(driver);
	//assertEquals(driver.getCurrentUrl(),URLConst.POST_LIST,"URL los");
	assertEquals(listPostPage.countPostsWithName(m),1,"Post nije dodat.");
}	
	

@Test    
void tc23() throws InterruptedException {
String z = "#456Category";
String x = Utils.getRandomCatName();
String y = Utils.getDescName();
AddCategoryPage  addCategoryPage = new AddCategoryPage(driver,true);
addCategoryPage.insertCatName(x);
addCategoryPage.insertCatDesc(y);
addCategoryPage.clickOnSave();

AddPostPage addPostPage = new AddPostPage(driver,true);
addPostPage.clickOnChooseCat();
addPostPage.clickOnCatOption(x);
addPostPage.clickOnCatOption(z);
assertEquals(addPostPage.getNumofSelInCategory(),1,"Nije dobar broj selektovanih.");
assertEquals(addPostPage.getNameSelOptCategory(),z,"Nije dobro ime.");
}


               /////HIDDENSELECT          //// LISTA POST

        
      


@Test
void tc24() {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnAddnewPost();
	assertEquals(driver.getCurrentUrl(),URLConst.POST_ADD,"Url nije dobar.");
	
}	
	                                                        //search by
@Test
void tc25() throws InterruptedException {
	String x ="This is post about Art and Music";
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.insertTitle(x);
	assertEquals(listPostPage.isPostWithNameInList(x),true,"Post nije u listi.");
	assertEquals(listPostPage.getSizeOfTable(),1,"Nije dobar size.");
	
}		
	
               
@Test         //p   NA AuThORA pa opciju;get size liste 'ime selektov.
void tc26() {

  String x="Polaznik Kursa" ;                               
  ListPostPage listPostPage = new ListPostPage(driver);
  listPostPage.clickOnChAuthor();
  listPostPage.clickOnOptionForAuthor(x);
  assertEquals(listPostPage.getNameSelOptAutor(),x,"Nije dobar autor.");
  assertEquals(listPostPage.isChoosenAuthorInTable(x),true,"Author nije u listi.");
}  

@Test               //p                    
void tc27() {
  String h ="Name test";
  String x="Tag name 1";
  ListPostPage listPostPage = new ListPostPage(driver);
listPostPage.clickOnChAuthor();
listPostPage.clickOnOptionForAuthor(h);
listPostPage.clickOnOptionForAuthor(x);
assertEquals(listPostPage.getNameSelOptAutor(),x,"Nije dobar autor.");

}  
@Test            // p Klik na category ,opciju; ime; size liste
void tc28() throws InterruptedException {

String x = "#456Category";
ListPostPage listPostPage = new ListPostPage(driver);
listPostPage.clickOnCategory();
listPostPage.clickOnOptionForCategory(x);
assertEquals(listPostPage.getNameSelOptCategory(),x,"Lose ime kategorije.");

}
	
@Test
void tc29() {
	String x = "#456Category";
	String z = "This is very long description for those who cant easily express";
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnCategory();
	listPostPage.clickOnOptionForCategory(x);
	listPostPage.clickOnOptionForCategory(z);
	assertEquals(listPostPage.getNameSelOptCategory(),z,"Lose ime sel. kategorije.");
	
}

	
@Test                  // KLIK na IMpORTANT,na opciju,get name selekt,siz 

void tc30() {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnImportant();
	listPostPage.clickOnOptionForImportant("yes");
	assertEquals(listPostPage.getSizeOfImportantList(),3,"Nije dobar size liste.");
	assertEquals(listPostPage.getNameSelImportant(),"yes","Nije dobro ime.");
	assertEquals(listPostPage.isChoosenImportantInTable("yes"),true,"Nije dobar status");
}                     

@Test
void tc31() {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnImportant();
	listPostPage.clickOnOptionForImportant("no");
	assertEquals(listPostPage.getSizeOfImportantList(),3,"Nije dobar size.");
	assertEquals(listPostPage.getNameSelImportant(),"no","Nije dobro ime.");
	assertEquals(listPostPage.isChoosenImportantInTable("no"),true,"");
}        
@Test
void tc32() {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnImportant();
	listPostPage.clickOnOptionForImportant("yes");
	listPostPage.clickOnOptionForImportant("no");
	assertEquals(listPostPage.getSizeOfImportantList(),3,"Nije dobar size.");
	assertEquals(listPostPage.getNameSelImportant(),"no","Nije dobro ime.");
	assertEquals(listPostPage.isChoosenImportantInTable("no"),true,"Nije u tabeli.");
}        
@Test//        KLIK NA STATUS ,NA OPCIJU;IME SEL;get size liste;
void tc33() {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnStatus();;
	listPostPage.clickOnOptionForStatus("enabled");
	assertEquals(listPostPage.getNameSelStatus(),"enabled","Nije dobro ime.");
	assertEquals(listPostPage.getSizeOfStatusList(),3,"Nije dobar size.");
	assertEquals(listPostPage.isChoosenStatusInTable("enabled"),true,"Nije u tabeli.");
}
@Test
void tc34() {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnStatus();;
	listPostPage.clickOnOptionForStatus("disabled");
	assertEquals(listPostPage.getNameSelStatus(),"disabled","Nije dobro ime.");
	assertEquals(listPostPage.getSizeOfStatusList(),3,"Nije dobar size.");
	assertEquals(listPostPage.isChoosenStatusInTable("disabled"),true,"Nije u tabeli.");
}

@Test
void tc35() {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnStatus();;
	listPostPage.clickOnOptionForStatus("enabled");
	listPostPage.clickOnOptionForStatus("disabled");
	assertEquals(listPostPage.getNameSelStatus(),"disabled","Nije dobro ime.");
	assertEquals(listPostPage.getSizeOfStatusList(),3,"Nije dobar size");
	assertEquals(listPostPage.isChoosenStatusInTable("disabled"),true,"Status nije u tabeli.");
}
                   // SEARCH WITH TAG        
@Test           // Klik WITHtAG;get size;broj selek;iimeSELEKT.          
void tc36()  {                                                                             
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnWithTag();
	listPostPage.clickOnWithTagOption("Default TAG NE BRISATI");
	listPostPage.clickOnWithTagOption("TenSharpBeautiful");
	assertEquals(listPostPage.getNumbOfSelInWithTagList(),2,"broj je los");
	assertEquals(listPostPage.getAllSelInWithTag(),"[Default TAG NE BRISATI, TenSharpBeautiful]","Nije dobra lista.");
}

@Test  
void tc37()  {
String x ="Default TAG NE BRISATI";
ListPostPage listPostPage = new ListPostPage(driver);
listPostPage.clickOnWithTag();
listPostPage.clickOnWithTagOption(x);
assertEquals(listPostPage.getNumbOfSelInWithTagList(),1,"los broj.");
assertEquals(listPostPage.getNameSelInWithTag(),x,"Nije dobro ime selektovanog.");
assertEquals(listPostPage.isChoosenWithTagInTable(x),true,"Tag nije u tabeli."); 
}
	
@Test
void tc38() {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnWithTag();
	listPostPage.clickOnWithTagOption("TenSharpBeautiful");
	assertEquals(listPostPage.isChoosenWithTagInTable("TenSharpBeautiful"),true,"Nije u tabeli.");
}
@Test                                     //SHOW ENTRIES
void tc39() {
	ListPostPage listPostPage = new ListPostPage(driver);
	assertEquals(listPostPage.isTenSelected(),true,"nije selektovan");
	assertEquals(listPostPage.getSizeOfTable(),10,"Nije dobar size.");
}
@Test      //  P SHOWentries,GETSIZElist;NA OPCIJU;KOJe upolju; 
                                        
void tc40() throws InterruptedException {
ListPostPage listPostPage = new ListPostPage(driver);
listPostPage.clickOnShowEntries();
assertEquals(listPostPage.getSizeOfShowEnList(),4,"Nije dobar size showEntrlist");
listPostPage.clickOnShowEnOption("25");
assertEquals(listPostPage.getValueShowEn(),"25","Nije dobra vrednost selektovanog.");
assertEquals(listPostPage.getSizeOfTable(),25,"Nije dobar size.");
}	


@Test                   
                                                 
void tc41() throws InterruptedException {
ListPostPage listPostPage = new ListPostPage(driver);
listPostPage.clickOnShowEntries();
assertEquals(listPostPage.getSizeOfShowEnList(),4,"Nije dobar size showlist.");
listPostPage.clickOnShowEnOption("50");
assertEquals(listPostPage.getValueShowEn(),"50","Nije dobra vrednost selektovanog.");
assertEquals(listPostPage.getSizeOfTable(),50,"Nije dobar size.");
}	
@Test
void tc42() throws InterruptedException {
ListPostPage listPostPage = new ListPostPage(driver);
listPostPage.clickOnShowEntries();
assertEquals(listPostPage.getSizeOfShowEnList(),4,"Nije dobar size showlist.");
listPostPage.clickOnShowEnOption("100");
assertEquals(listPostPage.getValueShowEn(),"100","Nije dobra vrednost selektovanog.");
assertEquals(listPostPage.getSizeOfTable(),100,"Nije dobar size.");
}	
@Test
void tc43() throws InterruptedException {
ListPostPage listPostPage = new ListPostPage(driver);
listPostPage.clickOnShowEntries();
assertEquals(listPostPage.getSizeOfShowEnList(),4,"Nije dobar size showlist.");
listPostPage.clickOnShowEnOption("10");
listPostPage.clickOnShowEntries();
listPostPage.clickOnShowEnOption("25");
assertEquals(listPostPage.getValueShowEn(),"25","Nije dobra vrednost selektovanog.");
assertEquals(listPostPage.getSizeOfTable(),25,"Nije dobar size.");
}	


                                     // U P D A T E P O S T = OK


                  ///NECE da ADD postkaze"NO SUCH Element"  a update ok;
@Test       //P      UPDATe pa  na Cancel  ;; SAMOUZ THREADsl00;                   
 void tc44() throws InterruptedException {
	                    
    String m = "This is post about Art and Music";
	ListPostPage listPostPage = new ListPostPage(driver);  
	listPostPage.clickOnUpdatePost(m);
	AddPostPage addPostPage = new AddPostPage(driver,false);
	assertEquals(addPostPage.getTitleText(),m,"Nije dobar title.");
	addPostPage.clickOnCancel();
	assertEquals(driver.getCurrentUrl(),URLConst.POST_LIST,"Url nije dobar.");
	assertEquals(listPostPage.countPostWithTitle(m),1,"Post nije u list.");
}
@Test        //p        TACKA  .NECE TAG ERROR DA PREPOZNA6
 void tc45() throws InterruptedException {
	String m = "This is post about Art and Music";
	ListPostPage listPostPage = new ListPostPage(driver);  
	listPostPage.clickOnUpdatePost(m);
	AddPostPage addPostPage = new AddPostPage(driver,false);
	assertEquals(addPostPage.getTitleText(),m,"Nije dobar title.");
	addPostPage.insertTitle("");
	addPostPage.insertPostDesc("");
	addPostPage.insertContent("");
	addPostPage.clickOnSave();
	assertEquals(addPostPage.isTitleErrorDisplayed(),true,"Nije prikazana poruka.");
	assertEquals(addPostPage.getTitleErrorText(),"This field is required.","");
    assertEquals(addPostPage.isDescriptionErrorDisplayed(),true,"Nije prikazana poruka.");
	assertEquals(addPostPage.getDescrErrorText(),"This field is required.","");
		
}                            // P MOZE UPDATE sa novim    
@Test
 void tc46() throws InterruptedException {                                        
	AddPostPage addPostPage = new AddPostPage(driver,true); 
	String x ="This is post about Art and Music";
	
	String z = Utils.getPostTitle2();
	String y = Utils.getPostDesc();
	     addPostPage.insertTitle(z);
		 addPostPage.insertPostDesc(y);
	     addPostPage.clickOnCheckBoxLabelTagname("TenSharpBeautiful");
	     addPostPage.insertContent("SOMENEWCOntent");
	     addPostPage.clickOnSave();
	ListPostPage listPostPage = new ListPostPage(driver);  
	listPostPage.clickOnUpdatePost(x);
	     assertEquals(addPostPage.getTitleText(),x,"Nije dobar title.");
	    addPostPage.insertTitle(z);
	    addPostPage.insertPostDesc(y);
	    addPostPage.clickOnCheckBoxLabelTagname("Default TAG NE BRISATI");
	    addPostPage.insertContent("SOMENEWCOntent");
	    addPostPage.clickOnSave();
	    assertEquals(listPostPage.countPostWithTitle(x),0,"Title je u listi.");
	    assertEquals(listPostPage.countPostWithTitle(z),1,"Title nije u listi");
}	
@Test      //  OK NA UPDATE,;            Zameni sliku 
 void tc47() throws InterruptedException { 
	
	String z =  Utils.getPostTitle2();           
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnUpdatePost(z);
	AddPostPage addPostPage = new AddPostPage(driver,false);
	assertEquals(addPostPage.getTitleText(),z,"Nije dobar title");
	addPostPage.clickOnDeletePhoto();
	addPostPage.uploadFile();
	addPostPage.clickOnSave();
	assertEquals(driver.getCurrentUrl(),URLConst.POST_LIST,"Url nije dobar.");
	assertEquals(listPostPage.countPostWithTitle(z),1,"Post nije u listi.");
	assertEquals(listPostPage.getDescriptionOfPhoto(z),"_Capture9.png","Opis los.");
	                                 
}

 
                                              //sort
@Test                          
void tc48() {
	ListPostPage listPostPage = new ListPostPage(driver);
	assertEquals(listPostPage.isAscOrderOfSerNumbers(),true,"Nije ascedent order.");
}
@Test                         
void tc49() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSortBySerNumber();
	assertEquals(listPostPage.isAscOrderOfSerNumbers(),false," ascedent order je.");
}                      
@Test
void tc50() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSortByTitle();
	assertEquals(listPostPage.isAlphabeticalOrderOfTitless(),true,"Nije alfabetical order.");
}
@Test                      
void tc51() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSortByTitle();
	listPostPage.clickOnSortByTitle();
	assertEquals(listPostPage.isAlphabeticalOrderOfTitless(),false," Alfabetical order.");
}
@Test
void tc52() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSortByAuthor();
	assertEquals(listPostPage.isAlphabeticalOrderOfAuthors(),true,"Nije alfabetical order.");
}
@Test                              
void tc53() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSortByAuthor();
	listPostPage.clickOnSortByAuthor();
	assertEquals(listPostPage.isAlphabeticalOrderOfAuthors(),false,"Alfabetical order.");
}

@Test
void tc54() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSortByCategory();
	assertEquals(listPostPage.isAlphabeticalOrderOfCategoriess(),true,"Nije alfab. order.");
}

@Test                  
void tc55() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSortByCategory();
	listPostPage.clickOnSortByCategory();
	assertEquals(listPostPage.isAlphabeticalOrderOfCategoriess(),false," Alfabetical order.");
}
@Test                                  
void tc56() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSortByDate();
	assertEquals(listPostPage.isHronollogicalOrderOfDates2(),true,"Nije chronoll.order.");
}
@Test                           
void tc57() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSortByDate();
	listPostPage.clickOnSortByDate();
	assertEquals(listPostPage.isHronollogicalOrderOfDates2(),false,"Chronoll. order.");
}

@Test                                          //ok status  4 
void tc58() throws InterruptedException {
	String z =  Utils.getPostTitle2();  
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnDisable(z);
	listPostPage.clickOnCancelfromDialogDisable();
	assertEquals(listPostPage.getStatusInTable(z),"enabled","Nije dobar status.");
	
}
@Test                                 
void tc59() throws InterruptedException {
	String z =  Utils.getPostTitle2();  
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnDisable(z);
	listPostPage.clickOnDisableFromDialogDisable();
	assertEquals(listPostPage.getStatusInTable(z),"disabled","Nije dobar status.");
	
}
@Test
void tc60() throws InterruptedException {
	String z =  Utils.getPostTitle2();  
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnEnable(z);
	listPostPage.clickOnCancelfromDialogEnable();
	assertEquals(listPostPage.getStatusInTable(z),"disabled","Nije dobar status.");
	
}
@Test
void tc61() throws InterruptedException {
	String z =  Utils.getPostTitle2();  
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnEnable(z);
	listPostPage.clickOnEnableFromDialogEnable();
	assertEquals(listPostPage.getStatusInTable(z),"enabled","Nije dobar status.");
	
}                                             // Important 4 
@Test
void tc62() throws InterruptedException {
	String z =  Utils.getPostTitle2();  
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSetAsImportantPost(z);
	listPostPage.clickOnCancelImporDialog();
	assertEquals(listPostPage.getImpInTable(z),"No","Nije dobar Important.");
	
	
}
@Test
void tc63() throws InterruptedException {
	String z =  Utils.getPostTitle2();  
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSetAsImportantPost(z);
	listPostPage.clickOnSetasImpFromDialog();
	assertEquals(listPostPage.getImpInTable(z),"Yes","Nije dobar Important.");
	
	
}

@Test
void tc64() throws InterruptedException {
	String z =  Utils.getPostTitle2();  
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSetAsUnimportantPost(z);
	listPostPage.clickOnCanceUnImportantDialog();
	assertEquals(listPostPage.getImpInTable(z),"Yes","Nije dobar Important.");
	
	
}
@Test
void tc65() throws InterruptedException {
	String z =  Utils.getPostTitle2();  
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnSetAsUnimportantPost(z);
	listPostPage.clickOnSetAsUnImpFromDialog();
	assertEquals(listPostPage.getImpInTable(z),"No","Nije dobar Important.");
	
	
}                                                    //search
@Test
void tc66() throws InterruptedException {
	 String z =  Utils.getPostTitle2();  
	 ListPostPage listPostPage = new ListPostPage(driver);
	 listPostPage.insertQueryForSearch(z);
	  assertEquals(listPostPage.isQuerySearchAmongTitles(z),true,"Naslov nije u listi.");
	  assertEquals(listPostPage.HowManyTitlesContainsQuery(z),1,"los broj.");
}
@Test                                    
void tc67() throws InterruptedException {
	String x ="58";
	ListPostPage listPostPage = new ListPostPage(driver);
	 listPostPage.insertQueryForSearch(x);
	 assertEquals(listPostPage.isQuerySearchAmongTitles(x),true,"Naslov nije u listi.");
	 assertEquals(listPostPage.HowManyTitlesContainsQuery(x),1,"Los broj.");
}

@Test//p    assert post po upitu is displayed 
void tc68() throws InterruptedException {                                                                                     
     ListPostPage listPostPage = new ListPostPage(driver);                                                 
     listPostPage.insertQueryForSearch("TenSharpBeautiful");;
     assertEquals(listPostPage.isTabmassDisplayed(),true,"Poruka nije prikazana.");
     assertEquals(listPostPage.getTabSearchText(),"No matching records found","Nije dobra poruka.");
}          

@Test
void tc70() {
	   String z =  Utils.getPostTitle2();  
       ListPostPage listPostPage = new ListPostPage(driver);
       listPostPage.insertTitle(z);
       listPostPage.clickOnChAuthor();
       listPostPage.clickOnOptionForAuthor("Polaznik Kursa");
       listPostPage.clickOnImportant();
       listPostPage.clickOnOptionForImportant("No");
       listPostPage.clickOnStatus();
       listPostPage.clickOnOptionForStatus("enabled");
       assertEquals(listPostPage.getSizeOfTable(),1,"Nije dobar size");
       assertEquals(listPostPage.isEnteredTitleInTable(z),true,"Nije prikazan title.");
}

                         ///DELETE POST    
@Test                   //  na DELETE pCANCEL;na listi si;tu je;                                          
void tc71() throws InterruptedException {
String z =  Utils.getPostTitle2();
ListPostPage listPostPage = new ListPostPage(driver);
listPostPage.clickOnDeletePost(z);
listPostPage.clickOnDeleteDialogCancel();
assertEquals(driver.getCurrentUrl(),URLConst.POST_LIST,"Url nije dobar.");
assertEquals(listPostPage.countPostWithTitle(z),1,"Post nije u listi.");
}

@Test     // p NA LISTI;KLIK na DELETE DELETE;na listi ;0 ;1 iz dial                                         
void tc72() throws InterruptedException {                                 
String z =  Utils.getPostTitle2();
ListPostPage listPostPage = new ListPostPage(driver);
listPostPage.clickOnDeletePost(z);                                                       	
listPostPage.clickOnDeleteDialogDelete();
assertEquals(driver.getCurrentUrl(),URLConst.POST_LIST,"Url nije dobar.");
assertEquals(listPostPage.countPostWithTitle(z),0,"Post nije u listi.");
}

@Test                        
void tc73() {
	
	ListPostPage listPostPage = new ListPostPage(driver);
    assertEquals(listPostPage.isFirstPageDisplayed(),true,"Nije prikazana.");
    assertEquals(listPostPage.isPreviousDisplayed(),true,"Nije displayed.");
}

@Test                         
void tc74() throws InterruptedException {
	
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnLastPage();
	assertEquals(listPostPage.isLastPageDisplayed(),true,"Nije prikazana.");
    assertEquals(listPostPage.isNextDisplayed(),true,"Nije displayed.");
}
@Test                        
void tc75() throws InterruptedException {
	ListPostPage listPostPage = new ListPostPage(driver);
	listPostPage.clickOnNext();
	
}	
	
    
}


